import XCTest

final class FlightUITests: XCTestCase {
    func testRealControlsFlightCollisionAndRestart() {
        let app = XCUIApplication()
        app.launch()
        XCTAssertTrue(app.buttons["mainAction"].waitForExistence(timeout: 10))
        XCTAssertEqual(app.staticTexts["stateTitle"].label, "Lumen Drift")
        app.buttons["mainAction"].tap()
        let field = app.buttons["flightArea"]
        XCTAssertTrue(field.exists)
        field.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.65)).tap()
        let telemetry = field.value as? String ?? ""
        XCTAssertTrue(telemetry.contains("phase=flying"), telemetry)
        let values = Dictionary(uniqueKeysWithValues: telemetry.split(separator: ";").compactMap { part -> (String, String)? in
            let pair = part.split(separator: "="); guard pair.count == 2 else { return nil }
            return (String(pair[0]), String(pair[1]))
        })
        XCTAssertGreaterThanOrEqual(Int(values["taps"] ?? "0") ?? 0, 2)
        XCTAssertGreaterThan(Int(values["y"] ?? "0") ?? 0, 390)
        let flying = XCTAttachment(screenshot: app.screenshot()); flying.name = "Flight after actual UI tap"; flying.lifetime = .keepAlways; add(flying)
        XCTAssertTrue(app.buttons["mainAction"].waitForExistence(timeout: 8))
        XCTAssertEqual(app.staticTexts["stateTitle"].label, "Flight complete")
        XCTAssertEqual(app.buttons["mainAction"].label, "Restart")
        let ended = XCTAttachment(screenshot: app.screenshot()); ended.name = "Collision ended flight"; ended.lifetime = .keepAlways; add(ended)
        app.buttons["mainAction"].tap()
        XCTAssertEqual(app.staticTexts["stateTitle"].label, "Lumen Drift")
        XCTAssertEqual(app.staticTexts["score"].label, "Score 0")
        XCTAssertTrue((field.value as? String ?? "").contains("phase=ready;y=390;velocity=0;score=0;taps=0"))
        app.buttons["mainAction"].tap()
        XCTAssertTrue((field.value as? String ?? "").contains("phase=flying"))
    }
    func testPauseAndResume() {
        let app = XCUIApplication(); app.launch()
        app.buttons["mainAction"].tap()
        app.buttons["pause"].tap()
        XCTAssertEqual(app.buttons["mainAction"].label, "Resume flight")
        let frozen = app.buttons["flightArea"].value as? String
        Thread.sleep(forTimeInterval: 1)
        XCTAssertEqual(app.buttons["flightArea"].value as? String, frozen)
        app.buttons["mainAction"].tap()
        XCTAssertTrue((app.buttons["flightArea"].value as? String ?? "").contains("paused=false"))
    }
}
