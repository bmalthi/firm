// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "LumenLogic", products: [.library(name: "LumenLogic", targets: ["LumenLogic"])], targets: [
    .target(name: "LumenLogic", path: "LumenDrift/Core"),
    .testTarget(name: "LumenLogicTests", dependencies: ["LumenLogic"], path: "CoreTests")
])
