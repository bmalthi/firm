import XCTest
@testable import LumenLogic

final class GameWorldTests: XCTestCase {
    func testReadyDoesNotMove() {
        var w = GameWorld(); let original = w
        w.advance(0.1); XCTAssertEqual(w, original)
    }
    func testTapStartsAndLifts() {
        var w = GameWorld(); w.tap(); w.advance(0.1)
        XCTAssertEqual(w.phase, .flying); XCTAssertGreaterThan(w.y, 390)
        XCTAssertGreaterThan(w.velocity, 0); XCTAssertEqual(w.tapCount, 1)
    }
    func testTapReplacesRatherThanStacksVelocity() {
        var w = GameWorld(); w.tap(); w.tap()
        XCTAssertEqual(w.velocity, GameWorld.impulse)
    }
    func testGravityAndFloorEndRun() {
        var w = GameWorld(); w.tap()
        for _ in 0..<40 { w.advance(0.1) }
        XCTAssertEqual(w.phase, .ended); XCTAssertLessThanOrEqual(w.y - GameWorld.radius, GameWorld.floor)
    }
    func testCeilingEndsRun() {
        var w = GameWorld(); w.tap(); w.y = GameWorld.ceiling - GameWorld.radius
        w.advance(GameWorld.tick); XCTAssertEqual(w.phase, .ended)
    }
    func testObstacleCollision() {
        var w = GameWorld(); w.tap(); w.y = 200
        w.gates = [Gate(id: 1, x: GameWorld.playerX, center: 390)]
        w.advance(GameWorld.tick); XCTAssertEqual(w.phase, .ended); XCTAssertEqual(w.score, 0)
    }
    func testSafeGapDoesNotCollide() {
        var w = GameWorld(); w.tap()
        w.gates = [Gate(id: 1, x: GameWorld.playerX, center: 390)]
        w.advance(GameWorld.tick); XCTAssertEqual(w.phase, .flying)
    }
    func testPointOnlyAfterWholeGatePassedAndOnlyOnce() {
        var w = GameWorld(); w.tap(); w.velocity = 0
        w.gates = [Gate(id: 1, x: 65, center: 390)]
        w.advance(GameWorld.tick); XCTAssertEqual(w.score, 0)
        for _ in 0..<4 { w.advance(GameWorld.tick) }
        XCTAssertEqual(w.score, 1)
        w.advance(0.1); XCTAssertEqual(w.score, 1)
    }
    func testDeathFreezesAndTapCannotRestart() {
        var w = GameWorld(); w.tap(); w.y = 80; w.advance(GameWorld.tick)
        let dead = w; w.tap(); w.advance(0.1)
        XCTAssertEqual(w, dead)
    }
    func testRestartResetsEverythingIncludingSeedAndScore() {
        var w = GameWorld(); w.tap(); w.gates = [Gate(id: 1, x: 50, center: 390)]
        w.advance(GameWorld.tick); XCTAssertEqual(w.score, 1)
        w.y = 80; w.advance(GameWorld.tick); XCTAssertEqual(w.phase, .ended)
        w.reset(); XCTAssertEqual(w, GameWorld())
        w.tap(); XCTAssertEqual(w.phase, .flying); XCTAssertEqual(w.score, 0)
    }
    func testSameInputsAreDeterministic() {
        var a = GameWorld(seed: 42); var b = GameWorld(seed: 42)
        for frame in 0..<600 {
            if frame % 40 == 0 { a.tap(); b.tap() }
            a.advance(1.0 / 60); b.advance(1.0 / 60)
        }
        XCTAssertEqual(a, b)
    }
    func testFramePartitionKeepsPhysicsEquivalent() {
        var a = GameWorld(); var b = GameWorld(); a.tap(); b.tap()
        for _ in 0..<30 { a.advance(1.0 / 60) }
        for _ in 0..<60 { b.advance(1.0 / 120) }
        XCTAssertEqual(a.y, b.y, accuracy: 1e-8)
        XCTAssertEqual(a.velocity, b.velocity, accuracy: 1e-8)
        XCTAssertEqual(a.gates, b.gates)
    }
    func testInvalidTimeIgnoredAndLongStallClamped() {
        var a = GameWorld(); a.tap(); let original = a
        a.advance(.nan); a.advance(-1); a.advance(.infinity)
        XCTAssertEqual(a, original)
        var b = original; a.advance(100); b.advance(0.1)
        XCTAssertEqual(a, b)
    }
}
