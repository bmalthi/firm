# Lumen Drift

A small, original native iPhone arcade game: guide a luminous geometric kite through coral gates. Swift + UIKit + SpriteKit; no third-party dependencies, downloaded assets, external services, or copied game branding/code.

## Play
- **Start flight** begins a run with an upward impulse.
- Tap anywhere in the playfield to rise. Release to fall. Avoid coral pillars and the two cyan boundary lines.
- Earn one point when a whole gate is behind the kite. The circular hit area is intentionally forgiving around the pointed artwork.
- **Restart** returns to a clean ready state with score zero; press **Start flight** for the next run.
- **Ⅱ** pauses; **Resume flight** continues. Leaving the app pauses an active run, with explicit resume on return.
- Best score is local to the device. The gate sequence repeats for fair practice.

## Build and run
Open `LumenDrift.xcodeproj`, choose the shared **LumenDrift** scheme and an installed iPhone simulator, then Run. No signing account is needed for a simulator. The checked-in Xcode project is ready to use; `generate_project.py` is only an optional, dependency-free regeneration aid.

Build **in local scratch**, not the shared drive (which does not support build-tool atomic renames). On the validated Mac:

```sh
# From a local copy of this directory:
xcodebuild -project LumenDrift.xcodeproj -scheme LumenDrift \
  -configuration Debug -sdk iphonesimulator \
  -destination 'platform=iOS Simulator,id=6254A4CD-FBFF-4266-8F15-AAB08F16DE55' \
  -derivedDataPath build CODE_SIGNING_ALLOWED=NO build
xcrun simctl boot 6254A4CD-FBFF-4266-8F15-AAB08F16DE55 # skip if already booted
xcrun simctl bootstatus 6254A4CD-FBFF-4266-8F15-AAB08F16DE55 -b
xcrun simctl install 6254A4CD-FBFF-4266-8F15-AAB08F16DE55 \
  build/Build/Products/Debug-iphonesimulator/LumenDrift.app
xcrun simctl launch 6254A4CD-FBFF-4266-8F15-AAB08F16DE55 org.lumendrift.game
```

Simulator UUIDs are station-specific and recreated after lease cleanup. Use `xcrun simctl list devices available` and substitute a currently available iPhone UUID. On Xcode 27, simulator display is in `/Applications/Xcode.app/Contents/Applications/DeviceHub.app`.

## Tests
```sh
swift test  # 13 deterministic XCTest tests of the platform-independent rules
xcodebuild -project LumenDrift.xcodeproj -scheme LumenDrift \
  -destination 'platform=iOS Simulator,id=YOUR-DEVICE-UUID' \
  -derivedDataPath build -resultBundlePath UITests.xcresult \
  -parallel-testing-enabled NO CODE_SIGNING_ALLOWED=NO test
```
Use a fresh result-bundle path per run. The UI suite operates real UIKit controls: starts, taps, checks flight telemetry, waits for collision, restarts, starts again, pauses and resumes. Its score-reset UI assertion is from a zero-score run; the deterministic suite separately verifies reset from a nonzero score. Manual nonzero-score evidence, when performed, is documented separately in `evidence/VALIDATION.md`.

## Structure and constraints
- `LumenDrift/Core/GameWorld.swift`: deterministic seeded gates, 120 Hz fixed-step integration, circle/rectangle collision, once-only scoring, restart. Elapsed frame time is capped at 100 ms to avoid post-stall teleportation.
- `LumenDrift/GameScene.swift`: original programmatic vector art; no SpriteKit physics randomness.
- `LumenDrift/App.swift`: native accessible buttons/HUD, lifecycle pause, local best score.
- `CoreTests/`, `UITests/`: runnable test suites.
- `evidence/`: exact machine details, build/test logs, screenshots and result bundle archives.
- `qa/`: independent tester's findings, maintained separately.

Target: portrait iPhone, iOS 17+. Tested environment and actual results are recorded in `evidence/VALIDATION.md`; a minimum deployment target is **not** a claim of testing every OS. No physical-device, App Store, performance profiling, full VoiceOver playability, or Dynamic Type certification. No audio or external analytics; icons/assets for App Store submission are out of scope.

**Validation caveat:** Engineer's final native UI run passed 2/2, but an independent cold-simulator run reported 2 tests/9 assertion failures. Real-time UI automation can race the short no-input flight; cause is not confirmed. Both outcomes are disclosed in `evidence/VALIDATION.md`. This does not replace the deterministic tests or manual score-1 → collision → restart-to-0 evidence.
