# Engineer validation — Lumen Drift

Performed by Rowan Vale on Firm station 2 during the 2026-11-05 work period. **Final source built, installed and launched successfully; 13 core tests and 2 UI tests passed on this station.** An independent cold-simulator UI test attempt failed (see caveat below); this is not an all-environments-clean claim.

## Exact environment
- macOS **27.0**, build **26A428**, arm64.
- Xcode **27.0**, build **27A266a**.
- **iPhone 17**, iOS **26.0**, runtime build **23A343**.
- Device UUID **6254A4CD-FBFF-4266-8F15-AAB08F16DE55**.
- Bundle ID **org.lumendrift.game**, Debug simulator configuration, signing disabled.
- Local build root: `/example-home/scratch/tap-to-fly` (not shared drive).
- Full runtime inventory is `environment.txt`. iOS 27 was available but not tested by the engineer.
- Host clocks differ: Mac logs say 2026-09-22 (local PDT), Firm records/capture filenames say 2026-11-05 UTC. These are preserved, not corrected or disguised.

## Automated checks actually executed
| Check | Result | Evidence |
|---|---|---|
| Initial `swift test` | 13 XCTest tests, 0 failures | `core-tests.log` |
| Final source `swift test` rerun | 13 XCTest tests, 0 failures, exit 0 | `final-core-tests.log` |
| Initial Xcode simulator build | BUILD SUCCEEDED | `build.log` |
| Final explicit Xcode simulator build | BUILD SUCCEEDED, exit 0 | `final-build.log` |
| Initial simulator boot/install/launch | boot completed; launch PID 3879 | `install-launch.log` |
| Final explicit install/launch | install exit 0; launch exit 0, PID 6695 | `final-install-launch.log` |
| Initial native UI test run | 2 tests, 0 failures, TEST SUCCEEDED | `ui-tests.log` |
| Final native UI test run after HUD polish | 2 tests, 0 failures, TEST SUCCEEDED; 26.675 seconds | `final-ui-tests.log`, `FinalUITests.xcresult.tar.gz` |

All engineer UI runs used `-parallel-testing-enabled NO`. Final explicit reinstall found no process to terminate (benign termination error is retained in log); the subsequent launch itself succeeded. Initial build emitted only an AppIntents metadata warning because no AppIntents framework is used.

The core suite covers idle/start/upward impulse, gravity/floor/ceiling, obstacle collision and safe gap, score threshold/exactly-once, death freeze and ignored taps, reset from a nonzero score, reproducible input runs, fixed-step frame partition, and invalid/long elapsed times. It is compiled against the same `GameWorld.swift` as the app, not a reimplementation.

The native UI suite operates actual controls. It asserts an extra flight-area tap increments the tap count, y rises above 390, a no-input run ends, Restart restores ready/y390/velocity0/score0/taps0, another Start works, and pause holds state before Resume. Its restart UI test starts from score zero; **nonzero-score restart was separately exercised manually** below. Read-only accessibility telemetry exposes the live game values; there is no test-only physics, auto-play, invincibility or scoring injection.

## Personally inspected simulator behavior
1. Launched the final app and inspected the ready screen and controls in Xcode Device Hub.
2. Posted a start tap and five playfield taps requested 730 ms apart, then Pause. Actual tool-posted offsets: **7, 751, 1468, 2198, 2972, 3713, 3972 ms**. These are input-posting times, not guaranteed app-receipt times. Inspected the paused simulator: **score 1** and kite/gates visible.
3. Clicked **Resume flight**, gave no further flight taps, then inspected **Flight complete**, **1 gate cleared**, **Best 1**.
4. Clicked **Restart**, then inspected ready state, **score 0**, **Best 1**, no gates, restored kite, and **Start flight** button. The immediate desktop capture caught the old button label during highlight transition; the settled `manual-restarted.png` correctly shows Start flight.
5. Inspected final UI-test running screenshot: kite visibly above its initial position, coral obstacles, score HUD and tap instructions visible. This screenshot is an actual simulator capture, not concept art.

Screenshots:
- `start.png`: final ready screen, initially Best 0.
- **`running.png`**: final app in flight after an actual UI-test tap, exported from final xcresult.
- `game-over.png`: final app's UI-test collision state.
- `manual-paused-score1.png`: manual tap-sequence run at score 1, paused. A timed screenshot intended to catch flight arrived after pause; it is deliberately labeled paused.
- `manual-game-over.png`: manual run ended at score 1.
- `manual-restarted.png`: settled ready state after resetting that nonzero run, score 0 / Best 1.
- `final-ui-attachments/manifest.json`: exported attachment provenance. `ui-attachments/` and `earlier-captures/` retain earlier images and are not the final hero image.

## Important independent failure / limitation
Founder reported a separate station-1 test on freshly created **iPhone 17 / iOS 26**, UUID **BFC6B282-5AF6-44E6-9E21-4FC9ADF8678F**, using the pre-HUD-polish snapshot. Compilation succeeded, but **2 UI tests / 9 assertions failed**: Pause expected Resume flight but saw Restart; subsequent taps observed ready state instead of flight, with cascading game-over/restart mismatches. Founder did not retain the full log/xcresult and canceled the shell after test output. A second founder run against the **final shared snapshot**, with `-parallel-testing-enabled NO` as the README prescribes, reproduced 2 tests / 9 failures; the full log is now retained at `founder-station1-ui-tests-failed.log`. This increases concern that the UI test discrepancy is reproducible beyond a parallel-runner artifact. This failed attempt is disclosed, not superseded or attributed to a proven cause.

The UI tests are timing-sensitive: an unassisted run ends in roughly 1.3 seconds, so slow XCTest event/quiescence overhead can outlast the flight and cause later coordinate taps to hit the now-visible Restart card. This is a **plausible diagnosis, not confirmed root cause**. The HUD-only change is not claimed to fix it. Final tests passed on station 2, and manual scoring/collision/nonzero restart were observed there. Independent tester results, when available, live in `../qa/` and should be read alongside this report.

## Source and artifacts
- `source-sha256.txt`: hashes produced from the actual Mac build checkout; all eight checked files verified against shared copies with `sha256sum -c`.
- `LumenDrift-simulator.zip`: compiled simulator app (not a device/App Store distribution).
- `FinalUITests.xcresult.tar.gz`: complete final native UI test result bundle.
- Project/source/instructions are at `shared/tap-to-fly/`; all listed evidence was copied to the shared drive before lease release.

No physical-device, App Store, exhaustive OS/device matrix, performance, full VoiceOver-playability or Dynamic Type testing was performed. The game intentionally has no audio, network or third-party assets. Release cleanup destroys the station's simulator UUID; substitute an available UUID when rerunning.

## Lease closure
Station 2 lease `cb394bdd5b17431e9581bf0dca75c1e7` was released after saving the project, artifacts and evidence. `mac_release` returned **Status ok, Clean True**, access revoked, work stopped, drive detached and desktop usable. No unfinished engineer build/test process was left running.

## Independent tester's final QA (Mira Chen)
Independent fresh-station run on iPhone 17 / iOS 26.0, Xcode 27.0: copied final source to scratch, ran 22 core tests (13 shipped + 9 edge tests) with 0 failures, built successfully, installed and launched (PID 9314). Manual actual-pointer simulator checks confirmed a tap caused upward motion; score reached 1, continued no-input flight ended at floor at score 2, Restart reset to score 0 and removed gates while retaining Best 2, and repeated Start/game-over/restart worked. Details, exact tap offsets, screenshots, and raw command results are in `../qa/REPORT.md`.

The independent tester also reproduced the UI-suite mismatch: pause/resume passed, flight/collision/restart failed with 8 assertions. `qa/ui-tests.log` is the raw record. Xcode stalled while finalizing and was interrupted; its `qa/IndependentUI.xcresult.tar.gz` is partial/unreadable, not a successful test result. The engineer's station-2 UI 2/2 pass and founder/tester station-1 failures conflict; UI automation reliability remains an open finding, not a verified gameplay defect or a proven timing root cause. The independent manual simulator behavior did pass.
