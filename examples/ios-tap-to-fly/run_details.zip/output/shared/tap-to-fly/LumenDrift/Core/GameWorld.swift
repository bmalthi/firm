// Original deterministic game rules; no rendering or platform dependencies.
public struct Gate: Equatable {
    public var id: Int
    public var x: Double
    public var center: Double
    public var scored = false
    public init(id: Int, x: Double, center: Double, scored: Bool = false) {
        self.id = id; self.x = x; self.center = center; self.scored = scored
    }
}

public struct GameWorld: Equatable {
    public enum Phase: String { case ready, flying, ended }
    public static let width = 390.0
    public static let height = 780.0
    public static let floor = 78.0
    public static let ceiling = 702.0
    public static let playerX = 108.0
    public static let radius = 13.0
    public static let gap = 224.0
    public static let gateWidth = 66.0
    public static let speed = 144.0
    public static let gravity = 850.0
    public static let impulse = 310.0
    public static let tick = 1.0 / 120.0
    public private(set) var phase: Phase = .ready
    public internal(set) var y = 390.0
    public internal(set) var velocity = 0.0
    public internal(set) var gates: [Gate] = []
    public private(set) var score = 0
    public private(set) var tapCount = 0
    private var random: UInt64
    private let seed: UInt64
    private var nextID = 1
    private var remainder = 0.0

    public init(seed: UInt64 = 0x1A2B3C) { self.seed = seed; random = seed }
    public mutating func reset() { self = GameWorld(seed: seed) }
    public mutating func tap() {
        guard phase != .ended else { return }
        if phase == .ready {
            phase = .flying
            gates = [Gate(id: 0, x: 470, center: 390)]
        }
        tapCount += 1
        velocity = Self.impulse
    }
    // Fixed steps keep normal frame-rate differences out of game rules. Drop excess
    // time after a stall, rather than teleporting the flyer through obstacles.
    public mutating func advance(_ seconds: Double) {
        guard phase == .flying, seconds.isFinite, seconds > 0 else { return }
        remainder += min(seconds, 0.1)
        while remainder + 1e-10 >= Self.tick && phase == .flying {
            remainder -= Self.tick
            step()
        }
    }
    private mutating func step() {
        velocity -= Self.gravity * Self.tick
        y += velocity * Self.tick
        for i in gates.indices { gates[i].x -= Self.speed * Self.tick }
        // Resolve collision before scoring so a fatal overlap cannot award a point.
        if y - Self.radius <= Self.floor || y + Self.radius >= Self.ceiling || gates.contains(where: hits) {
            phase = .ended
            return
        }
        for i in gates.indices where !gates[i].scored && gates[i].x + Self.gateWidth / 2 < Self.playerX - Self.radius {
            gates[i].scored = true
            score += 1
        }
        gates.removeAll { $0.x < -Self.gateWidth }
        if let last = gates.last, last.x <= 210 {
            random = random &* 6364136223846793005 &+ 1442695040888963407
            let center = 285.0 + Double((random >> 32) % 211)
            gates.append(Gate(id: nextID, x: last.x + 260, center: center))
            nextID += 1
        }
    }
    // Circle vs rectangle, including tangent contact. Geometry matches rendered caps.
    private func hits(_ gate: Gate) -> Bool {
        let left = gate.x - Self.gateWidth / 2
        let right = gate.x + Self.gateWidth / 2
        func circleHits(bottom: Double, top: Double) -> Bool {
            let dx = Self.playerX - min(max(Self.playerX, left), right)
            let dy = y - min(max(y, bottom), top)
            return dx * dx + dy * dy <= Self.radius * Self.radius
        }
        return circleHits(bottom: Self.floor, top: gate.center - Self.gap / 2)
            || circleHits(bottom: gate.center + Self.gap / 2, top: Self.ceiling)
    }
}
