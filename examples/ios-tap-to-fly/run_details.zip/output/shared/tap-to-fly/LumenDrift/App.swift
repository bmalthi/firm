import UIKit
import SpriteKit

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = GameViewController()
        window.makeKeyAndVisible(); self.window = window
        return true
    }
}

final class GameViewController: UIViewController {
    private let scene = GameScene(size: CGSize(width: 390, height: 780))
    private let skView = SKView()
    private let flight = UIButton(type: .custom)
    private let score = UILabel()
    private let bestLabel = UILabel()
    private let card = UIStackView()
    private let heading = UILabel()
    private let detail = UILabel()
    private let action = UIButton(type: .system)
    private let instruction = UILabel()
    private var previousPhase: GameWorld.Phase?
    private var best = UserDefaults.standard.integer(forKey: "lumenBest")
    private var inactive = false
    private var pausedByUser = false
    private let pauseButton = UIButton(type: .system)
    private let mint = UIColor(red: 0.37, green: 0.97, blue: 0.91, alpha: 1)

    override var prefersStatusBarHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .portrait }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.035, green: 0.065, blue: 0.14, alpha: 1)
        skView.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(skView)
        NSLayoutConstraint.activate([skView.leadingAnchor.constraint(equalTo: view.leadingAnchor), skView.trailingAnchor.constraint(equalTo: view.trailingAnchor), skView.topAnchor.constraint(equalTo: view.topAnchor), skView.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
        scene.scaleMode = .aspectFit; skView.preferredFramesPerSecond = 60; skView.presentScene(scene)
        flight.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(flight)
        NSLayoutConstraint.activate([flight.leadingAnchor.constraint(equalTo: view.leadingAnchor), flight.trailingAnchor.constraint(equalTo: view.trailingAnchor), flight.topAnchor.constraint(equalTo: view.topAnchor), flight.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
        flight.accessibilityIdentifier = "flightArea"; flight.accessibilityLabel = "Flight area"
        flight.accessibilityHint = "Tap to give the kite an upward impulse. Avoid the coral gates."
        flight.addTarget(self, action: #selector(flap), for: .touchDown)
        let brand = label("LUMEN / DRIFT", size: 12, weight: .heavy)
        brand.textColor = mint
        let hud = UIStackView(arrangedSubviews: [brand, score, bestLabel]); hud.axis = .horizontal; hud.alignment = .center; hud.spacing = 14
        score.font = .monospacedDigitSystemFont(ofSize: 34, weight: .light); score.textColor = .white
        score.accessibilityIdentifier = "score"
        bestLabel.font = .monospacedDigitSystemFont(ofSize: 11, weight: .medium); bestLabel.textColor = .lightGray
        hud.translatesAutoresizingMaskIntoConstraints = false; hud.isUserInteractionEnabled = false; view.addSubview(hud)
        NSLayoutConstraint.activate([hud.centerXAnchor.constraint(equalTo: view.centerXAnchor), hud.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 12)])
        pauseButton.setTitle("Ⅱ", for: .normal); pauseButton.tintColor = mint
        pauseButton.titleLabel?.font = .systemFont(ofSize: 22, weight: .bold)
        pauseButton.accessibilityLabel = "Pause"; pauseButton.accessibilityIdentifier = "pause"
        pauseButton.addTarget(self, action: #selector(togglePause), for: .touchUpInside)
        pauseButton.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(pauseButton)
        NSLayoutConstraint.activate([pauseButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -18), pauseButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 12), pauseButton.widthAnchor.constraint(equalToConstant: 44), pauseButton.heightAnchor.constraint(equalToConstant: 44)])
        card.axis = .vertical; card.alignment = .fill; card.spacing = 18
        card.isLayoutMarginsRelativeArrangement = true; card.layoutMargins = UIEdgeInsets(top: 30, left: 25, bottom: 28, right: 25)
        card.backgroundColor = UIColor(red: 0.055, green: 0.10, blue: 0.19, alpha: 0.97); card.layer.cornerRadius = 26
        card.layer.borderColor = mint.withAlphaComponent(0.3).cgColor; card.layer.borderWidth = 1
        heading.font = .systemFont(ofSize: 30, weight: .bold); heading.textColor = .white
        heading.textAlignment = .center; heading.numberOfLines = 0; heading.accessibilityIdentifier = "stateTitle"
        detail.font = .systemFont(ofSize: 15, weight: .regular); detail.textColor = UIColor(white: 0.78, alpha: 1)
        detail.numberOfLines = 0; detail.textAlignment = .center
        action.setTitleColor(UIColor(red: 0.025, green: 0.12, blue: 0.16, alpha: 1), for: .normal)
        action.backgroundColor = mint; action.layer.cornerRadius = 15
        action.titleLabel?.font = .systemFont(ofSize: 17, weight: .bold); action.heightAnchor.constraint(equalToConstant: 54).isActive = true
        action.accessibilityIdentifier = "mainAction"; action.addTarget(self, action: #selector(mainAction), for: .touchUpInside)
        for item in [heading, detail, action] { card.addArrangedSubview(item) }
        card.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(card)
        NSLayoutConstraint.activate([card.centerXAnchor.constraint(equalTo: view.centerXAnchor), card.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 45), card.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.83)])
        instruction.font = .systemFont(ofSize: 12, weight: .medium); instruction.textColor = UIColor(white: 0.7, alpha: 1); instruction.textAlignment = .center
        instruction.translatesAutoresizingMaskIntoConstraints = false; instruction.isUserInteractionEnabled = false; view.addSubview(instruction)
        NSLayoutConstraint.activate([instruction.centerXAnchor.constraint(equalTo: view.centerXAnchor), instruction.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16)])
        scene.onChange = { [weak self] world in self?.refresh(world) }
        NotificationCenter.default.addObserver(self, selector: #selector(deactivate), name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(activate), name: UIApplication.didBecomeActiveNotification, object: nil)
        refresh(scene.world)
    }
    private func label(_ text: String, size: CGFloat, weight: UIFont.Weight) -> UILabel {
        let label = UILabel(); label.text = text; label.font = .systemFont(ofSize: size, weight: weight); return label
    }
    @objc private func flap() {
        guard !inactive, !pausedByUser, scene.world.phase == .flying else { return }
        scene.flap()
    }
    @objc private func mainAction() {
        if pausedByUser { togglePause(); return }
        if scene.world.phase == .ended { scene.restart() }
        else if scene.world.phase == .ready { scene.flap() }
    }
    @objc private func togglePause() {
        guard scene.world.phase == .flying else { return }
        pausedByUser.toggle(); scene.isPaused = pausedByUser || inactive; scene.resetClock(); previousPhase = nil; refresh(scene.world)
    }
    @objc private func deactivate() {
        inactive = true
        if scene.world.phase == .flying { pausedByUser = true }
        scene.isPaused = true; previousPhase = nil; refresh(scene.world)
    }
    @objc private func activate() { inactive = false; scene.resetClock(); scene.isPaused = pausedByUser; refresh(scene.world) }
    private func refresh(_ world: GameWorld) {
        score.text = "\(world.score)"; score.accessibilityLabel = "Score \(world.score)"
        flight.accessibilityValue = "phase=\(world.phase.rawValue);y=\(Int(world.y));velocity=\(Int(world.velocity));score=\(world.score);taps=\(world.tapCount);paused=\(pausedByUser)"
        if world.phase == .ended && world.score > best { best = world.score; UserDefaults.standard.set(best, forKey: "lumenBest") }
        bestLabel.text = "BEST  \(best)"
        guard previousPhase != world.phase else { return }; previousPhase = world.phase
        card.isHidden = world.phase == .flying && !pausedByUser
        pauseButton.isHidden = world.phase != .flying || pausedByUser
        flight.isEnabled = world.phase == .flying && !pausedByUser
        instruction.text = world.phase == .flying ? "TAP TO RISE  ·  GLIDE THROUGH THE GAPS" : "ONE TAP. A LITTLE LIFT."
        if pausedByUser {
            heading.text = "Take a breath"; detail.text = "Your flight is paused.\nResume when you’re ready."; action.setTitle("Resume flight", for: .normal)
        } else if world.phase == .ready {
            heading.text = "Lumen Drift"; detail.text = "A tiny kite. An endless night.\n\nTap to rise. Slip between coral gates.\nEach gate cleared earns one point."; action.setTitle("Start flight", for: .normal)
        } else if world.phase == .ended {
            heading.text = "Flight complete"; detail.text = "\(world.score) \(world.score == 1 ? "gate" : "gates") cleared  ·  Best \(best)\n\nFind your rhythm. Try another flight."; action.setTitle("Restart", for: .normal)
        }
    }
}
