import SpriteKit

final class GameScene: SKScene {
    var world = GameWorld()
    var onChange: ((GameWorld) -> Void)?
    private let gateLayer = SKNode()
    private let flyer = SKNode()
    private let trail = SKShapeNode(circleOfRadius: 5)
    private var lastTime: TimeInterval = 0
    private var clock: TimeInterval = 0
    private var built = false
    private let ink = SKColor(red: 0.035, green: 0.065, blue: 0.14, alpha: 1)
    private let cyan = SKColor(red: 0.37, green: 0.97, blue: 0.91, alpha: 1)
    private let coral = SKColor(red: 1, green: 0.44, blue: 0.43, alpha: 1)

    override func didMove(to view: SKView) {
        guard !built else { return }; built = true
        backgroundColor = ink
        let halo = SKShapeNode(circleOfRadius: 235)
        halo.fillColor = SKColor(red: 0.05, green: 0.12, blue: 0.22, alpha: 1)
        halo.strokeColor = .clear; halo.position = CGPoint(x: 290, y: 440); addChild(halo)
        for i in 0..<43 {
            let dot = SKShapeNode(circleOfRadius: i % 5 == 0 ? 1.8 : 0.9)
            dot.position = CGPoint(x: (i * 97 + 31) % 390, y: 96 + (i * 137) % 592)
            dot.fillColor = SKColor(white: 0.8, alpha: i % 3 == 0 ? 0.4 : 0.17)
            dot.strokeColor = .clear; addChild(dot)
        }
        for y in [GameWorld.floor, GameWorld.ceiling] {
            let line = SKShapeNode(rectOf: CGSize(width: 390, height: 2))
            line.position = CGPoint(x: 195, y: y)
            line.fillColor = cyan.withAlphaComponent(0.45); line.strokeColor = .clear; addChild(line)
        }
        for i in 0..<10 {
            let p = CGMutablePath(); let x = CGFloat(i * 48)
            p.move(to: CGPoint(x: x, y: 0)); p.addLine(to: CGPoint(x: x + 34, y: 48))
            p.addLine(to: CGPoint(x: x + 64, y: 0)); p.closeSubpath()
            let mountain = SKShapeNode(path: p); mountain.fillColor = SKColor(red: 0.08, green: 0.16, blue: 0.24, alpha: 1)
            mountain.strokeColor = .clear; mountain.position.y = 30; addChild(mountain)
        }
        addChild(gateLayer)
        // A luminous four-point paper kite: only original vector geometry.
        let body = CGMutablePath()
        body.move(to: CGPoint(x: 20, y: 0)); body.addLine(to: CGPoint(x: -13, y: 14))
        body.addLine(to: CGPoint(x: -7, y: 0)); body.addLine(to: CGPoint(x: -13, y: -14)); body.closeSubpath()
        let shape = SKShapeNode(path: body); shape.fillColor = cyan; shape.strokeColor = .white; shape.lineWidth = 1.2
        flyer.addChild(shape)
        let core = SKShapeNode(circleOfRadius: 3); core.fillColor = ink; core.strokeColor = .clear
        core.position.x = 5; flyer.addChild(core)
        trail.fillColor = cyan.withAlphaComponent(0.25); trail.strokeColor = .clear; addChild(trail)
        addChild(flyer); render()
    }
    func flap() { world.tap(); render(); onChange?(world) }
    func restart() { world.reset(); lastTime = 0; clock = 0; render(); onChange?(world) }
    func resetClock() { lastTime = 0 }
    override func update(_ currentTime: TimeInterval) {
        let delta = lastTime == 0 ? 0 : currentTime - lastTime
        lastTime = currentTime; clock += min(delta, 0.1)
        world.advance(delta); render(); onChange?(world)
    }
    private func render() {
        let bob = world.phase == .ready ? sin(clock * 2.5) * 7 : 0
        flyer.position = CGPoint(x: GameWorld.playerX, y: world.y + bob)
        flyer.zRotation = world.phase == .ready ? 0 : max(-0.65, min(0.42, world.velocity / 800))
        trail.position = CGPoint(x: GameWorld.playerX - 30, y: world.y + bob)
        trail.alpha = world.phase == .ended ? 0 : 1
        gateLayer.removeAllChildren()
        for gate in world.gates {
            for (bottom, top) in [(GameWorld.floor, gate.center - GameWorld.gap / 2), (gate.center + GameWorld.gap / 2, GameWorld.ceiling)] {
                let pillar = SKShapeNode(rectOf: CGSize(width: GameWorld.gateWidth, height: top - bottom), cornerRadius: 5)
                pillar.position = CGPoint(x: gate.x, y: (top + bottom) / 2)
                pillar.fillColor = SKColor(red: 0.27, green: 0.15, blue: 0.25, alpha: 1)
                pillar.strokeColor = coral.withAlphaComponent(0.65); pillar.lineWidth = 1
                gateLayer.addChild(pillar)
                let innerEdge = bottom == GameWorld.floor ? top - 5 : bottom + 5
                let cap = SKShapeNode(rectOf: CGSize(width: GameWorld.gateWidth, height: 10), cornerRadius: 3)
                cap.position = CGPoint(x: gate.x, y: innerEdge); cap.fillColor = coral; cap.strokeColor = .clear
                gateLayer.addChild(cap)
                let stripe = SKShapeNode(rectOf: CGSize(width: 2, height: max(4, top - bottom - 30)))
                stripe.position = pillar.position; stripe.fillColor = coral.withAlphaComponent(0.20); stripe.strokeColor = .clear
                gateLayer.addChild(stripe)
            }
        }
    }
}
