#!/usr/bin/env python3
"""Dependency-free, deterministic Xcode project generator. The generated project is checked in."""
from pathlib import Path
objects = []
counter = 0
def oid():
    global counter
    counter += 1
    return f'{counter:024X}'
def add(kind, body, ident=None):
    ident = ident or oid(); objects.append(f'{ident} = {{isa = {kind}; {body}}};'); return ident
def refs(values): return '(' + ', '.join(values) + ', )' if values else '()'
def settings(values): return '{' + ' '.join(f'{k} = {v};' for k,v in values.items()) + '}'
project_id = oid()
app_id = oid(); ui_id = oid()
app_product = add('PBXFileReference', 'explicitFileType = wrapper.application; path = LumenDrift.app; sourceTree = BUILT_PRODUCTS_DIR;')
ui_product = add('PBXFileReference', 'explicitFileType = wrapper.cfbundle; path = LumenDriftUITests.xctest; sourceTree = BUILT_PRODUCTS_DIR;')
file_refs=[]
def sources(paths):
    build=[]
    for path in paths:
        r=add('PBXFileReference', f'lastKnownFileType = sourcecode.swift; path = "{path}"; sourceTree = "<group>";')
        file_refs.append(r); build.append(add('PBXBuildFile', f'fileRef = {r};'))
    return add('PBXSourcesBuildPhase', f'buildActionMask = 2147483647; files = {refs(build)}; runOnlyForDeploymentPostprocessing = 0;')
app_sources=sources(['LumenDrift/App.swift','LumenDrift/GameScene.swift','LumenDrift/Core/GameWorld.swift'])
ui_sources=sources(['UITests/FlightUITests.swift'])
products=add('PBXGroup',f'children = {refs([app_product,ui_product])}; name = Products; sourceTree = "<group>";')
root=add('PBXGroup',f'children = {refs(file_refs+[products])}; sourceTree = "<group>";')
def configs(base):
    ids=[]
    for name in ['Debug','Release']:
        opts=dict(base)
        opts['SWIFT_OPTIMIZATION_LEVEL']='"-Onone"' if name=='Debug' else '"-O"'
        if name=='Debug': opts['SWIFT_ACTIVE_COMPILATION_CONDITIONS']='DEBUG'
        ids.append(add('XCBuildConfiguration',f'buildSettings = {settings(opts)}; name = {name};'))
    return add('XCConfigurationList',f'buildConfigurations = {refs(ids)}; defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;')
common={'SDKROOT':'iphoneos','IPHONEOS_DEPLOYMENT_TARGET':'17.0','SWIFT_VERSION':'5.0','TARGETED_DEVICE_FAMILY':'1','CLANG_ENABLE_MODULES':'YES','CODE_SIGN_STYLE':'Automatic','GENERATE_INFOPLIST_FILE':'YES','PRODUCT_NAME':'"$(TARGET_NAME)"'}
app_opts=dict(common,PRODUCT_BUNDLE_IDENTIFIER='org.lumendrift.game',MARKETING_VERSION='1.0',CURRENT_PROJECT_VERSION='1',INFOPLIST_KEY_CFBundleDisplayName='"Lumen Drift"',INFOPLIST_KEY_LSRequiresIPhoneOS='YES',INFOPLIST_KEY_UILaunchScreen_Generation='YES',INFOPLIST_KEY_UISupportedInterfaceOrientations='UIInterfaceOrientationPortrait',INFOPLIST_KEY_UIStatusBarHidden='YES')
app_config=configs(app_opts)
ui_config=configs(dict(common,PRODUCT_BUNDLE_IDENTIFIER='org.lumendrift.game.uitests',TEST_TARGET_NAME='LumenDrift'))
project_config=configs({'ALWAYS_SEARCH_USER_PATHS':'NO','CLANG_ENABLE_MODULES':'YES','ENABLE_TESTABILITY':'YES'})
proxy=add('PBXContainerItemProxy',f'containerPortal = {project_id}; proxyType = 1; remoteGlobalIDString = {app_id}; remoteInfo = LumenDrift;')
dep=add('PBXTargetDependency',f'target = {app_id}; targetProxy = {proxy};')
for ident,name,product,phase,config,deps,ptype in [(app_id,'LumenDrift',app_product,app_sources,app_config,[],'com.apple.product-type.application'),(ui_id,'LumenDriftUITests',ui_product,ui_sources,ui_config,[dep],'com.apple.product-type.bundle.ui-testing')]:
    framework=add('PBXFrameworksBuildPhase','buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;')
    resource=add('PBXResourcesBuildPhase','buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;')
    add('PBXNativeTarget',f'buildConfigurationList = {config}; buildPhases = {refs([phase,framework,resource])}; buildRules = (); dependencies = {refs(deps)}; name = {name}; productName = {name}; productReference = {product}; productType = "{ptype}";',ident)
add('PBXProject',f'attributes = {{LastUpgradeCheck = 1600; TargetAttributes = {{{app_id} = {{CreatedOnToolsVersion = 16.0;}}; {ui_id} = {{CreatedOnToolsVersion = 16.0; TestTargetID = {app_id};}};}};}}; buildConfigurationList = {project_config}; compatibilityVersion = "Xcode 14.0"; developmentRegion = en; hasScannedForEncodings = 0; knownRegions = (en, Base); mainGroup = {root}; productRefGroup = {products}; projectDirPath = ""; projectRoot = ""; targets = {refs([app_id,ui_id])};',project_id)
Path('LumenDrift.xcodeproj/project.pbxproj').write_text('// !$*UTF8*$!\n{archiveVersion = 1; classes = {}; objectVersion = 56; objects = {\n'+'\n'.join(objects)+f'\n}}; rootObject = {project_id};}}\n')
def buildref(ident,name): return f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{ident}" BuildableName="{name}" BlueprintName="{name.split(".")[0]}" ReferencedContainer="container:LumenDrift.xcodeproj"/>'
a=buildref(app_id,'LumenDrift.app'); t=buildref(ui_id,'LumenDriftUITests.xctest')
Path('LumenDrift.xcodeproj/xcshareddata/xcschemes/LumenDrift.xcscheme').write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
<BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{a}</BuildActionEntry></BuildActionEntries></BuildAction>
<TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv="YES"><Testables><TestableReference skipped="NO">{t}</TestableReference></Testables></TestAction>
<LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0">{a}</BuildableProductRunnable></LaunchAction>
<ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0">{a}</BuildableProductRunnable></ProfileAction>
<AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>''')
