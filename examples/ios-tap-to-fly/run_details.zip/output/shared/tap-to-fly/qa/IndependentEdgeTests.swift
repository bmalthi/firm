import XCTest
@testable import LumenLogic
final class IndependentEdgeTests: XCTestCase {
    private func placed(y: Double, xAfterStep: Double = 108) -> GameWorld {
        var w = GameWorld(); w.tap(); w.y = y; w.velocity = GameWorld.gravity * GameWorld.tick
        w.gates = [Gate(id: 99, x: xAfterStep + GameWorld.speed * GameWorld.tick, center: 390)]
        return w
    }
    func testLowerGapTangentFatal() { var w = placed(y: 291); w.advance(GameWorld.tick); XCTAssertEqual(w.phase, .ended) }
    func testJustInsideLowerGapSafe() { var w = placed(y: 291.000001); w.advance(GameWorld.tick); XCTAssertEqual(w.phase, .flying) }
    func testUpperGapTangentFatal() { var w = placed(y: 489); w.advance(GameWorld.tick); XCTAssertEqual(w.phase, .ended) }
    func testJustInsideUpperGapSafe() { var w = placed(y: 488.999999); w.advance(GameWorld.tick); XCTAssertEqual(w.phase, .flying) }
    func testCornerTangentFatal() { var w = placed(y: 290, xAfterStep: 146); w.advance(GameWorld.tick); XCTAssertEqual(w.phase, .ended) }
    func testJustOutsideCornerSafe() { var w = placed(y: 290.000001, xAfterStep: 146); w.advance(GameWorld.tick); XCTAssertEqual(w.phase, .flying) }
    func testFatalFrameDoesNotScoreAlreadyPassedGate() { var w = placed(y: 91, xAfterStep: 50); w.y = 90; w.advance(GameWorld.tick); XCTAssertEqual(w.phase, .ended); XCTAssertEqual(w.score, 0) }
    func testTwoPassedGatesScoreExactlyTwice() {
        var w = placed(y: 390, xAfterStep: 50); w.gates.append(Gate(id:100, x:-10, center:390))
        w.advance(GameWorld.tick); XCTAssertEqual(w.score, 2); w.advance(GameWorld.tick); XCTAssertEqual(w.score, 2)
    }
    func testRepeatedResetRestoresExactInitialState() {
        var w = GameWorld(seed: 73)
        for _ in 0..<100 { w.tap(); w.advance(0.099); w.reset(); XCTAssertEqual(w, GameWorld(seed:73)) }
    }
}
