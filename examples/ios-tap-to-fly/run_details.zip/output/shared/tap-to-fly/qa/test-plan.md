# Independent QA plan — Mira Chen

Evidence states: automated = command actually executed; observed = simulator image/UI personally inspected; review = source inference only. Never substitute one for another.

## Logic checks
- Start is idle; tap starts and imparts upward velocity; idle time does not score or kill.
- Each obstacle scores exactly once when passed. Multiple steps and adjacent obstacles do not double count.
- Collision boundaries: obstacle sides/top/bottom, floor and ceiling; no collision within safe gap; collision stops scoring and movement.
- Restart resets score, flight position/velocity, obstacles, timers and phase, with no residual collision or old obstacle score; repeated restarts remain safe.
- Large delta-time, rapid taps, and score/collision same-frame ordering where implementation permits.

## Simulator exercise
Record source snapshot, Xcode/runtime/device, build/test/install/launch commands and exit status. Capture start/running/game-over/restarted screenshots when practical. Compare immediate flight change after tap; let run collide; restart after a nonzero score if possible, otherwise explicitly limit score reset claim. Repeat collision/restart. Keep failures separate from untested checks.

Source files are not modified by QA. Independent test harnesses, if needed, live outside the project.
