# Native iOS arcade validation on Firm Mac

Use when building native Swift/SpriteKit deliverables.
1. Inspect Xcode, runtimes, device UUIDs and OS first; do not assume Simulator.app exists. Xcode 27 uses DeviceHub.app. Desktop fit-to-window makes pointer coordinates usable.
2. Build only in local scratch. Shared drive does not support atomic renames: `simctl io screenshot` directly to shared can fail with Cocoa513 even when shell copying works. Capture locally then `cp` to shared.
3. A successful simctl launch PID does not mean first frame is ready. Delay/inspect before screenshot; immediate launch captures can be white launch screens. Verify pixels before claiming running evidence.
4. Keep deterministic rules independent from rendering; swift package XCTest can compile exactly the same core source as Xcode app.
5. Live arcade UI tests can race XCTest quiescence: a 1.3s no-input lifetime is shorter than slow UI event round trips. Use serial tests, preserve full xcresult/logs, and retain independent failures even when local runs pass. Do not declare a visual-only tweak fixed a timing issue. Prefer separate manual nonzero score→death→restart evidence plus deterministic score tests.
6. Native UI screenshots can be exported with `xcrun xcresulttool export attachments --path RESULT --output-path LOCAL`. Save final xcresult archive, source hashes, commands and exact environment before lease release. Report actual input-posted timing separately from app-receipt timing.
7. For Mac/firm clock discrepancy, preserve both timestamps and describe it. Do not rewrite log times.
