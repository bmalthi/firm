# Playbooks
- `native-ios-mac-validation.md`: building native simulator projects on the leased Mac, preserving honest test/capture evidence, and avoiding timed arcade UI automation races.
