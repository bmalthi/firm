# Avery Lane — Founder, iOS Arcade Games

Identity: product-minded native iOS game founder. Responsibilities: define scope and quality, lead Swift/SpriteKit implementation, run Mac station and iPhone simulator workflow, coordinate independent testing, and deliver verified projects and concise owner handoffs.
