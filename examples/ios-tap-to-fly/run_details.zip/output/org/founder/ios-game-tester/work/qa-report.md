# Independent QA — Lumen Drift
Mira Chen · 2026-11-05 · final shared source, no app/project-source changes by QA.

## Conclusion
Core rules and manual simulator acceptance checks passed independently. The shipped native UI suite did **not** reproduce the engineer's all-pass result: pause/resume passed; flight/collision/restart failed with eight assertions. Do not describe this delivery as all automated checks passing. No confirmed gameplay defect in the exercised paths; UI automation reliability remains open.

## Environment and snapshot
Station 1; macOS 27.0 (26A428), Xcode 27.0 (27A266a); fresh QA iPhone 17, iOS 26.0 runtime 23A343; UUID `4E95A592-5F56-417F-840F-8C8832C26488`. Mac host timestamps are September 22, unlike firm November 5; logs retain host timestamps.

SHA256:
- App.swift `1fd0019cae099194c358512c96ad52eacd86ca8f4407a567331ae704920946d2`
- GameScene.swift `28998e2ad9386429958c1db8ab96397a0e36e2f6ed8daae5acd805eeb41d7f46`
- Core/GameWorld.swift `647ce114472e3ea4149b5fc749197d03e4648cd483b038b4a395ee7d17316721`

## Actually executed automated checks
- Copied source/project to local Mac `scratch/qa`, not built on drive.
- `swift test`: **22 tests, 0 failures**, exit 0. Shipped core13 plus separate QA edge9, copied into scratch's test directory only. `core-tests.log`, `IndependentEdgeTests.swift` retained. The trailing Swift Testing "0 tests" line is a separate runner, not the XCTest count.
- Added checks: upper/lower gap tangent contact ends run, epsilon inside gap stays alive; 5-12-13 corner tangent vs epsilon safe; fatal frame suppresses point; two already-passed gates each score once; 100 exact seeded reset cycles.
- `xcodebuild -project LumenDrift.xcodeproj -scheme LumenDrift -configuration Debug -sdk iphonesimulator -destination 'platform=iOS Simulator,id=4E95A592-5F56-417F-840F-8C8832C26488' -derivedDataPath build CODE_SIGNING_ALLOWED=NO build`: **BUILD SUCCEEDED**, exit 0 (`build.log`).
- `simctl boot`, `bootstatus -b`, `install` completed; `launch org.lumendrift.game` returned PID 9314. Independently inspected actual app in Device Hub.
- `xcodebuild ... -destination 'platform=iOS Simulator,id=...' -derivedDataPath build -resultBundlePath IndependentUI.xcresult -parallel-testing-enabled NO CODE_SIGNING_ALLOWED=NO test`: XCTest completed **2 tests, 8 assertion failures**, with pause/resume passing and flight/collision/restart failing. `ui-tests.log` retained.
- xcodebuild then stalled over five minutes finalizing logs. Sent SIGINT then SIGTERM; log ends **BUILD INTERRUPTED**, not a normal test-command success/exit. A later KILL attempt found process already gone. `IndependentUI.xcresult.tar.gz` is a **partial bundle**, missing Info.plist, not readable by xcresulttool; retained for forensic evidence only. Raw text log is the authoritative executed-test evidence here.

## Personally observed simulator checks
Real Device Hub pointer input, not injected model state or test cheats:
1. Ready screen showed Start flight and score 0.
2. Start plus five playfield taps roughly 730 ms apart, then pause: inspected score **1**, paused card, and obstacle passage (`paused-score1.png`). Tap postings were 1, 753, 1479, 2205, 2939, 3703 ms; pause at 3910 ms. No images were observed between those planned taps.
3. Resume with no further taps: inspected **Flight complete**, kite at floor, score **2**, Best 2 (`game-over-score2.png`). A second gate cleared before floor death; do not mislabel this score1 death.
4. Restart: inspected clean ready card, score **0**, no gates, Best **2** retained (`restarted-score0-desktop.png`; also simulator-only `restarted-score0.png`). Subsequent Start worked; no further taps led to another game-over (`repeat-game-over.png`).
5. Repeated Restart/Start and one playfield tap about 730 ms after Start. Consecutive personally inspected captures show kite moving upward from screen y~391 to y~356 after that tap (`tap-rise-1.png`, `tap-rise-2.png`), with scrolling gates. This independently verifies tap affects flight. `running-desktop.png` is another active-flight screenshot.

Immediate screenshots can transiently show the previous button title for one rendered frame; later captures showed correct Resume flight / Start flight text. Not established as a persistent defect.

## Source review (inferences, not additional runtime checks)
- Scoring requires trailing gate edge behind the flyer radius, and `scored` prevents repeats.
- Floor/ceiling and circle/rectangle collision happen before scoring; ended worlds ignore taps/time.
- Reset replaces the whole seeded world, including velocity, remainder, gate IDs, tap count, obstacles and score. Best score intentionally remains in controller defaults.
- Rendered kite tip extends beyond circular hit area; README explicitly documents forgiving hit area, not a discovered mismatch defect.

## Open findings / limitations
**QA-01 — UI automation not reproducible (medium test reliability).** On final snapshot, after scripted Start and flight-area tap, observed telemetry was `phase=ready;y=390;velocity=0;score=0;taps=0;paused=false`; downstream test expected flying/end/restart states and produced eight failures. Reproduce using test command above on fresh station1 simulator. See `ui-tests.log` assertions at UITests/FlightUITests.swift lines 14,19,20,23,24,27,29,31. Manual controls passed. A plausible, unproven cause is UI-test event/query latency: its flight-area coordinate overlaps the later Restart button, so a delayed tap after death could reset the run. Do not claim the initial Start tap was necessarily lost or a cold-start defect was proven. Recommend bounded phase assertions and timing-robust input strategy, without changing gameplay to satisfy tests.

**QA-02 — Xcode finalization hang (tooling).** Completed failing suite did not finalize result bundle; raw output retained, partial archive clearly labeled. No normal result-bundle or test-command exit claim.

No physical device, other runtime/device size, full accessibility, stress/performance, or manual obstacle-side collision certification. Obstacle and tangent collision checks were automated core tests; manually observed death was floor contact. Engineer/founder prior runs are not counted as my own checks. QA did not edit production project/source or erase prior evidence.

## Lease closure
All deliverables saved before release. mac_release returned Status ok, Clean True; access revoked, drive detached, work stopped, simulators cleaned.
