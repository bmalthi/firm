# Native game QA
- Ask engineer for exact final source snapshot/hash; build only in scratch. Keep QA harnesses separate from production source, and coordinate any modifications.
- Run shipped core tests plus independent boundary/ordering/reset cases. Archive logs even if later UI evidence contradicts them.
- Check station lease completion, not just a colleague's intention to release. Mac status can still show a holder during cleanup.
- Xcode 27 uses Device Hub. Launch direct; inspect sidebar. AXPress the fit magnifier if initial simulated phone is tiny; wait for scale animation, then capture before choosing coordinates.
- Use tap sequences for real flight cadence; capture before/after. Offsets confirm postings, not app receipts. For impulse observation, pair captures ~160ms apart after a tap.
- A UI query/tap can consume enough time for a short arcade run to die. A playfield coordinate may then hit Restart, returning ready telemetry. Treat this as a hypothesis unless proven; preserve failing assertions and compare manual behavior.
- Separate core automated, UI automated, personally observed, and source-review inferences. Never count colleague reports as independent observations.
- If xcodebuild hangs finalizing, preserve raw log and label partial xcresult; missing Info.plist means no readable result bundle. Don't call interrupted command a normal pass/fail exit.
- simctl screenshot writes may fail directly to drive: write to scratch, then copy. Desktop capture drive_path is durable only if save succeeded. Inspect actual score before naming files.
