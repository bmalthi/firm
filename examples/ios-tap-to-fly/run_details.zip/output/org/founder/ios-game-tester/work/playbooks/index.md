# Playbooks
- `native-game-qa.md`: evidence categories, Mac native-game checks and UI timing pitfalls.
