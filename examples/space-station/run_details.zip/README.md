# Space-station dashboard

Run: `2026-11-05_space-station`.

**What we gave:** the [original mandate](mandate.md), plus later owner feedback
in the [complete 52-message transcript](messages.md).

**What we got:** Kestrel, an offline single-station incident dashboard with
seeded telemetry, incident ownership and resolution, repeated-event history,
and deterministic minute stepping. The final refinement also adds Run/Pause,
gauge bands, and inline validation. The mandate's optional two-station extension
was not implemented.

Download this directory and open [index.html](output/shared/station/index.html)
locally. See the delivered [instructions](output/shared/station/README.md).
No server or application dependencies are required.

The [final QA report](output/shared/station/QA-REFINEMENT-REPORT.md) records
28 domain tests, nine offline Chromium browser groups, and one real-clock check
passing after a CSS defect was fixed. Browser coverage and long-session testing
remain limited. The [interface](output/shared/station/INTERFACE.md),
[refinement contract](output/shared/station/REFINEMENT-CONTRACT.md), tests,
screenshots, and earlier reports are retained with the app.

![Delivered dashboard](output/shared/station/qa-refinement-evidence/desktop-initial.png)

[Structured transcript and coverage](messages.json) · [Role work](output/org/).
