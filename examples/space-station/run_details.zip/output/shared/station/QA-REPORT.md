> Historical v1 baseline. Current refined-app verification is in [QA-REFINEMENT-REPORT.md](QA-REFINEMENT-REPORT.md). The v1 off-screen validation finding was fixed and independently retested during refinement.

# Independent QA — Kestrel Station v1

**2026-11-05 · Rowan Ellis · Result: PASS, with one non-blocking usability observation.**

Reviewed the agreed `INTERFACE.md` before preparing tests and coordinated availability with implementation/founder. Tested a scratch copy of the published production files; no production/interface edits. SHA-256 fingerprints in `qa-evidence/production-sha256.txt` match the shared production files at verification time.

## Exact verification

Working directory: `/example-home/scratch/station-qa`; app copied to `app/`.

```sh
node --check app/src/simulation.js
node --check app/src/app.js
node --check app/tests/browser-smoke.cjs
node --test app/tests/*.test.cjs
```

Node **v24.21.0**: syntax checks exit 0; **15 tests passed, 0 failed, 0 skipped**, 65.6 ms. Saved output: `qa-evidence/node-tests.txt`.

Domain coverage: incident creation/linkage/shape; ownership and whitespace rejection; resolution and invalid/already-resolved ID rejection; repeated failure reuse plus 12 distinct timeline events; new failure after resolution; numeric/string same-seed replay; changed-seed sensor variation; delayed wall-clock-independent replay; separate-instance isolation; defensive snapshots; classic browser global export.

Browser tooling setup (QA-only, not application dependencies):

```sh
npm init -y
npm install --save-dev @playwright/test@1.64.1
npx playwright install chromium
docker pull mcr.microsoft.com/playwright:v1.64.1-noble
```

Native Chromium launch was unavailable because the host lacks `libatk-1.0.so.0`; the same checks ran successfully inside the rootless Docker image instead:

```sh
docker run --rm --network none -v "$PWD:/qa" -w /qa \
  mcr.microsoft.com/playwright:v1.64.1-noble node app/tests/browser-smoke.cjs
```

Chromium **156.0.8078.80**: exit 0, all **7 smoke groups passed**. Container networking disabled plus browser context offline before first navigation. Opened `file:///qa/app/index.html` directly; **zero HTTP(S) requests and zero browser/console errors**. Evidence: `qa-evidence/browser-tests.txt` and `browser-observations.json`.

Verified through actual UI controls:
- Cold offline render of four sensors, four equipment records, starter incident and event timeline.
- Failure injection updates response queue/critical condition; repeated injection retains one incident and adds timeline history.
- Whitespace-only ownership rejected with feedback; valid assignment persists. HTML-like owner stays inert text. Assignment/resolve focus restoration works.
- Resolution restores equipment and associated sensor; active/all/resolved filtering, empty state, and post-resolution reinjection work.
- Cancelled reset preserves state; accepted reset with same seed reproduces full lifecycle snapshots; changed seed changes readings.
- 390 px viewport lifecycle controls work; no page-wide horizontal overflow at 390 px or 320 px. Inspected desktop 1440 px and mobile 390 px screenshots: readable hierarchy, textual severity/status, controls not clipped.
- Observed 22 calls across the public factory/mutation methods, confirming the exercised UI flows use the domain API.

Screenshots: `qa-evidence/desktop-initial.png`, `qa-evidence/mobile-390.png`.

## Finding: off-screen validation feedback (low priority, non-blocking)

At 1440×1100, open the app, enter three spaces in the starter incident's owner field, and click **Assign**. Rejection is correct, but the feedback is at page bottom with top **1282.9 px**, below the viewport, and the page does not reveal it. A sighted operator may not understand why assignment did not occur unless they scroll. The existing `role="status"` live region does help assistive technology. Consider nearby inline error text or revealing the message in a later usability pass; no production change was made.

Exact observational command (same Docker invocation as above, replacing the script with `feedback-check.cjs`, copied in scratch) and output saved in `qa-evidence/feedback-check.cjs` and `feedback-check.json`.

## Scope limits

No functional defects found in the tested v1 scope. Not a full accessibility audit: no screen-reader, contrast-tool or keyboard-only end-to-end certification. Only Chromium tested, not Safari/Firefox or physical mobile devices. Very long-session performance and local HTTP launch were not exercised. Session-only state and action-driven (not continuous) telemetry are documented design limits, not defects. Two-station support was neither requested nor tested.
