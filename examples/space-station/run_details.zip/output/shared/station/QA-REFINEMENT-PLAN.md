# Refinement regression risks — pending additive contract

Rowan Ellis · 2026-11-05. Existing single-station v1 only. No implementation or test rewrites started; v1 results remain historical evidence, not verification of refinements.

## High-priority guards

1. **Deterministic progression:** same seed + same ordered actions/explicit simulation steps must reproduce readings, IDs, timestamps and history. Browser timer timing must not leak into domain timestamps/randomness. Specify the new progression API and whether ticks produce events; keep module DOM-free and Node-testable.
2. **Timer lifecycle:** pause really stops progression; resume does not multiply intervals; reset disposes the previous simulation/timer, clears counters/history as specified and starts exactly one intended loop. Reload/reset and background-tab behavior must not silently create catch-up storms or huge history.
3. **Input/focus stability during updates:** periodic render must not erase an unfinished owner name or seed, steal focus, reset selection/filter, jump scrolling, interrupt submission, or hide validation. Current full-card replacement makes this a likely regression when ticking is introduced.
4. **Incident lifecycle preserved:** failure creates exactly one unresolved incident per equipment; repeats append activity without duplicating/resetting owner or creation time; resolution is final; reinjection creates a fresh incident. Active count must exclude resolved records. Invalid/blank owner still rejects without mutating state.
5. **Threshold correctness:** contract must define each sensor's threshold values, units, inclusive/exclusive boundaries, precision/rounding, and relationship between numeric bands, equipment faults and sensor status. Test just below/at/above both boundaries where applicable. Do not show "nominal" for an out-of-band value unless explicitly explained.
6. **Failure versus natural variation:** failure effects must remain distinguishable while readings fluctuate. Resolution removes the failure effect but need not return to the initial numerical sample if progression has advanced; this must be explicit before updating the old exact-restoration browser assertion.
7. **Current/recent/repeated semantics:** distinguish unresolved incidents (current) from recent event history and repeat signals. Define recent window/count, ordering/tie handling and any counters. Ensure resolved records do not look current, repeats remain discoverable, new incidents are not hidden behind a stale resolved filter, and no history is falsely labelled empty when only filtered.
8. **Fast incident access:** navigation/shortcuts should reveal the intended incident section/card, with keyboard focus and mobile scroll position accounted for. Preserve meaningful active/all/resolved filters and the empty state. Verify new controls work with keyboard and do not obscure headings behind sticky elements.
9. **Visible feedback:** trigger whitespace rejection at desktop and 390/320px layouts; feedback must be visible near the action or revealed without losing the draft. Announcements should remain live-region accessible but not spam every tick. Success/error text must not be immediately replaced by periodic updates.
10. **Offline/backward compatibility:** cold file:// start with container networking disabled and browser offline; no fetch/external assets or runtime dependencies. Preserve CommonJS/browser exports, old API methods, defensive snapshots, instance isolation, escaped operator text, mobile layout and existing v1 lifecycle tests. Additive snapshot fields must not accidentally invalidate or leak old state.

## Contract decisions needed before test changes

- Explicit simulation stepping API; reset/pause/start defaults; deterministic relationship between steps, actions, clock and timeline.
- Sensor band/threshold and status rules, including resolution while progression is active.
- Exact fields/rules for current/recent/repeated activity, retention and ordering.
- User-visible feedback/navigation behavior sufficient to write stable checks without depending on incidental markup.

After agreement: retain old Node regression coverage, add progression/boundary/reset/repetition tests, then repeat actual offline browser lifecycle and timer/input/focus/visibility checks against a scratch copy. Capture exact commands, browser/version, production hashes and fresh evidence separately from v1.
