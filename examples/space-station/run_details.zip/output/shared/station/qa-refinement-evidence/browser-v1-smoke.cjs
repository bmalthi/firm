'use strict';
// Optional QA tooling only: see tests/README.md. Not an app dependency.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require('@playwright/test');
const appRoot = process.env.APP_ROOT || path.resolve(__dirname, '..');
const evidence = process.env.EVIDENCE_DIR || path.resolve('evidence');
fs.mkdirSync(evidence, { recursive: true });

(async () => {
  const browser = await chromium.launch({ headless: true });
  const errors = [], remote = [], calls = [];
  try {
    const context = await browser.newContext({ offline: true, viewport: { width: 1440, height: 1100 } });
    // Observe public API calls without changing production files or results.
    await context.addInitScript(() => {
      window.__qaCalls = [];
      let module;
      Object.defineProperty(window, 'StationSimulation', {
        configurable: true,
        get: () => module,
        set(value) {
          module = value;
          const original = value.createSimulation;
          value.createSimulation = function(seed) {
            const sim = original(seed);
            window.__qaCalls.push(['createSimulation', seed]);
            for (const name of ['injectFailure', 'assignIncident', 'resolveIncident']) {
              const method = sim[name];
              sim[name] = function(...args) {
                window.__qaCalls.push([name, ...args]);
                return method(...args);
              };
            }
            window.__qaSim = sim;
            return sim;
          };
        }
      });
    });
    const page = await context.newPage();
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
    page.on('request', req => { if (/^https?:/.test(req.url())) remote.push(req.url()); });
    const snapshot = () => page.evaluate(() => window.__qaSim.getSnapshot());
    const inject = () => page.locator('#failure-form button').click();
    const ownerForm = id => page.locator(`form[data-incident="${id}"]`);
    const reset = async (seed, accept) => {
      await page.locator('#seed').fill(seed);
      page.once('dialog', d => accept ? d.accept() : d.dismiss());
      await page.locator('#seed-form button').click();
    };
    await page.goto(pathToFileURL(path.join(appRoot, 'index.html')).href);
    await page.locator('.incident').waitFor();
    const initial = await snapshot();
    assert.equal(initial.incidents.length, 1);
    assert.equal(await page.locator('.sensor').count(), 4);
    assert.equal(await page.locator('#equipment li').count(), 4);
    assert.equal(await page.locator('#timeline li').count(), initial.events.length);
    await page.screenshot({ path: path.join(evidence, 'desktop-initial.png'), fullPage: true });
    console.log('PASS: direct file:// cold start with browser offline; telemetry/equipment/incident/timeline render');

    const target = initial.equipment.find(e => e.id === 'oxygen-scrubber');
    await page.locator('#failure-equipment').selectOption(target.id);
    await inject();
    let state = await snapshot();
    const incident = state.incidents.find(i => i.equipment === target.id);
    assert.equal(state.incidents.length, 2);
    assert.equal(await page.locator('.incident').count(), 2);
    assert.match(await page.locator('#station-condition').innerText(), /Critical/);
    const eventCount = state.events.length;
    await inject();
    state = await snapshot();
    assert.equal(state.incidents.length, 2);
    assert.equal(state.events.length, eventCount + 1);
    assert.match(await page.locator('#feedback').innerText(), /No duplicate/);
    assert.equal(await page.locator('#timeline li').count(), state.events.length);
    console.log('PASS: failure injection and repeated-event UI retain a single incident');

    const beforeInvalid = await snapshot();
    await ownerForm(incident.id).locator('input').fill('   ');
    await ownerForm(incident.id).locator('button').click();
    assert.deepEqual(await snapshot(), beforeInvalid);
    assert.match(await page.locator('#feedback').innerText(), /nonempty owner/);
    const owner = '<img src=x onerror="window.BAD=1"> Flight QA';
    await ownerForm(incident.id).locator('input').fill(owner);
    await ownerForm(incident.id).locator('button').click();
    assert.equal((await snapshot()).incidents.find(i => i.id === incident.id).owner, owner);
    assert.equal(await ownerForm(incident.id).locator('input').inputValue(), owner);
    assert.equal(await page.locator('.owner-display strong').first().innerText(), owner);
    assert.equal(await page.locator('#incidents img').count(), 0);
    assert.equal(await page.evaluate(() => window.BAD), undefined);
    assert.equal(await page.locator(`#owner-${incident.id}`).evaluate(el => el === document.activeElement), true);
    console.log('PASS: whitespace rejected with visible feedback; assignment persists and HTML-like owner remains text');

    await page.locator(`[data-resolve="${incident.id}"]`).click();
    state = await snapshot();
    assert.equal(state.incidents.find(i => i.id === incident.id).status, 'resolved');
    assert.equal(state.sensors.find(s => s.id === 'oxygen').value, initial.sensors.find(s => s.id === 'oxygen').value);
    assert.equal(state.equipment.find(e => e.id === target.id).status, 'nominal');
    assert.equal(await page.locator('.incident').count(), 1);
    assert.equal(await page.locator('#incidents-heading').evaluate(el => el === document.activeElement), true);
    await page.locator('#incident-filter').selectOption('resolved');
    assert.equal(await page.locator('.incident').count(), 1);
    assert.match(await page.locator('.incident').innerText(), /Equipment restored/);
    await page.locator('#incident-filter').selectOption('all');
    assert.equal(await page.locator('.incident').count(), 2);
    await page.locator(`[data-resolve="${initial.incidents[0].id}"]`).click();
    await page.locator('#incident-filter').selectOption('active');
    assert.equal(await page.locator('.incident').count(), 0);
    assert.match(await page.locator('#incidents').innerText(), /Nothing in the queue/);
    assert.equal(await page.locator('#station-condition').innerText(), 'All systems nominal');
    await inject();
    const reinjected = (await snapshot()).incidents.at(-1);
    assert.notEqual(reinjected.id, incident.id);
    assert.equal(await page.locator('.incident').count(), 1);
    console.log('PASS: resolution restores telemetry/equipment; active/all/resolved filters and reinjection work');

    const beforeCancel = await snapshot();
    await reset('QA offline 42', false);
    assert.deepEqual(await snapshot(), beforeCancel);
    await reset(initial.seed, true);
    assert.deepEqual(await snapshot(), initial);
    const replay = async () => {
      await page.locator('#failure-equipment').selectOption('oxygen-scrubber');
      await inject(); await inject();
      const id = (await snapshot()).incidents.at(-1).id;
      await ownerForm(id).locator('input').fill('Replay QA');
      await ownerForm(id).locator('button').click();
      await page.locator(`[data-resolve="${id}"]`).click();
      return snapshot();
    };
    const firstReplay = await replay();
    await reset(initial.seed, true);
    assert.deepEqual(await replay(), firstReplay);
    await reset('QA offline 42', true);
    assert.equal((await snapshot()).seed, 'QA offline 42');
    assert.notDeepEqual((await snapshot()).sensors, initial.sensors);
    console.log('PASS: reset cancel preserves state; reset same seed reproduces complete lifecycle; changed seed changes readings');

    await page.setViewportSize({ width: 390, height: 844 });
    await page.screenshot({ path: path.join(evidence, 'mobile-390.png'), fullPage: true });
    const narrowSizes = await page.evaluate(() => ({ client: document.documentElement.clientWidth, scroll: document.documentElement.scrollWidth }));
    assert.ok(narrowSizes.scroll <= narrowSizes.client, `390px overflow: ${JSON.stringify(narrowSizes)}`);
    await page.locator('#failure-equipment').selectOption('power-relay');
    await inject();
    const mobileId = (await snapshot()).incidents.at(-1).id;
    await ownerForm(mobileId).locator('input').fill('Mobile QA');
    await ownerForm(mobileId).locator('button').click();
    await page.locator(`[data-resolve="${mobileId}"]`).click();
    await page.setViewportSize({ width: 320, height: 800 });
    const smallSizes = await page.evaluate(() => ({ client: document.documentElement.clientWidth, scroll: document.documentElement.scrollWidth }));
    assert.ok(smallSizes.scroll <= smallSizes.client, `320px overflow: ${JSON.stringify(smallSizes)}`);
    console.log('PASS: 390px core lifecycle clickable; no page-wide overflow at 390px or 320px');
    calls.push(...await page.evaluate(() => window.__qaCalls));
    for (const method of ['injectFailure', 'assignIncident', 'resolveIncident', 'createSimulation']) {
      assert.ok(calls.some(c => c[0] === method), `UI called public API ${method}`);
    }
    assert.deepEqual(errors, []);
    assert.deepEqual(remote, []);
    console.log('PASS: no browser errors or HTTP(S) requests; UI mutations use public API');
    console.log(`Browser: Chromium ${browser.version()}; offline context; ${calls.length} observed API calls`);
    fs.writeFileSync(path.join(evidence, 'browser-observations.json'), JSON.stringify({browser:browser.version(), errors, remote, calls, narrowSizes, smallSizes}, null, 2));
    await context.close();
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
