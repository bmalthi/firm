(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  let simulation = StationSimulation.createSimulation($('seed').value);
  let timer = null;
  const cards = new Map();
  const escape = value => String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
  const time = at => at.slice(11, 19);
  const badge = (value, label = value) => '<span class="badge ' + escape(value) + '">' + escape(label) + '</span>';
  const say = (message, error = false) => {
    $('feedback').textContent = message;
    $('feedback').classList.toggle('error', error);
  };
  function numericStatus(sensor) {
    if (sensor.value < sensor.criticalThresholds.min || sensor.value > sensor.criticalThresholds.max) return 'critical';
    return sensor.value >= sensor.normalRange.min && sensor.value <= sensor.normalRange.max ? 'nominal' : 'warning';
  }
  function createCard(incident, equipment) {
    const card = document.createElement('article');
    card.className = 'incident';
    card.dataset.incident = incident.id;
    card.innerHTML = '<div class="incident-meta"><span class="mono">' + incident.id + '</span>' + badge(incident.severity) + '<span class="status-badge"></span></div><h3>' + escape(incident.title) + '</h3><p class="hint">' + escape(equipment.name) + ' · Opened ' + time(incident.createdAt) + ' UTC</p><p class="activity-count hint"></p><div class="owner-display">Owner <strong class="owner-name"></strong></div><div class="incident-actions"><form class="assignment-form" data-incident="' + incident.id + '"><div class="owner-field"><label class="sr-only" for="owner-' + incident.id + '">Owner for ' + incident.id + '</label><input id="owner-' + incident.id + '" name="owner" placeholder="Owner or team name" value="' + escape(incident.owner || '') + '" required aria-describedby="error-' + incident.id + '"><p class="inline-feedback" id="error-' + incident.id + '" role="status" aria-live="polite"></p></div><button type="submit" class="secondary">Assign</button></form><button type="button" class="resolve-button" data-resolve="' + incident.id + '">Resolve <span aria-hidden="true">↗</span></button></div><p class="resolution" hidden></p>';
    cards.set(incident.id, card);
    $('incidents').prepend(card);
    return card;
  }
  function renderIncidents(state) {
    const filter = $('incident-filter').value;
    let visibleCount = 0;
    state.incidents.forEach(incident => {
      const equipment = state.equipment.find(item => item.id === incident.equipment);
      const card = cards.get(incident.id) || createCard(incident, equipment);
      const done = incident.status === 'resolved';
      card.classList.toggle('is-resolved', done);
      card.querySelector('.status-badge').innerHTML = badge(incident.status);
      card.querySelector('.owner-name').textContent = incident.owner || 'Unassigned';
      const linked = state.events.filter(event => event.incidentId === incident.id);
      const repeats = linked.filter(event => event.type === 'failure.repeated').length;
      card.querySelector('.activity-count').textContent = linked.length + ' linked events' + (repeats ? ' · ' + repeats + ' repeat signal' + (repeats === 1 ? '' : 's') : ' · No repeat signals');
      card.querySelector('.incident-actions').hidden = done;
      const resolution = card.querySelector('.resolution');
      resolution.hidden = !done;
      if (done) resolution.textContent = '✓ Fault cleared · current baseline restored · Resolved ' + time(incident.resolvedAt) + ' UTC';
      card.hidden = !(filter === 'all' || (filter === 'resolved' ? done : !done));
      if (!card.hidden) visibleCount++;
    });
    let empty = $('empty-incidents');
    if (!empty) {
      empty = document.createElement('div'); empty.id = 'empty-incidents'; empty.className = 'empty-state'; $('incidents').append(empty);
    }
    empty.hidden = visibleCount > 0;
    if (!visibleCount) empty.innerHTML = '<span aria-hidden="true">✓</span><h3>' + (filter === 'resolved' ? 'No resolved incidents yet' : 'Nothing in the queue') + '</h3><p class="muted">' + (filter === 'resolved' ? 'Resolved incidents will appear here.' : 'Use the training tools to simulate an equipment failure.') + '</p>';
  }
  function render(updateIncidents = true) {
    const state = simulation.getSnapshot();
    const active = state.incidents.filter(incident => incident.status !== 'resolved');
    const critical = active.some(incident => incident.severity === 'critical');
    $('station-condition').textContent = critical ? 'Critical response' : active.length ? 'Attention required' : 'No active incidents';
    $('station-condition').className = critical ? 'critical-text' : active.length ? 'warning-text' : 'nominal-text';
    $('sim-time').textContent = time(state.events[state.events.length - 1].at) + ' LOG UTC';
    $('elapsed').textContent = 'Elapsed ' + state.simulationMinute + ' min';
    $('sensors').innerHTML = state.sensors.map((sensor, index) => {
      const span = sensor.scale.max - sensor.scale.min;
      const percent = value => Math.min(100, Math.max(0, (value - sensor.scale.min) / span * 100));
      const fault = active.find(incident => state.equipment.find(item => item.id === incident.equipment) && ({ 'coolant-pump': 'temperature', 'oxygen-scrubber': 'oxygen', 'power-relay': 'power', 'comms-array': 'signal' })[incident.equipment] === sensor.id);
      const cutoffs = [];
      if (sensor.criticalThresholds.min > sensor.scale.min) cutoffs.push('< ' + sensor.criticalThresholds.min);
      if (sensor.criticalThresholds.max < sensor.scale.max) cutoffs.push('> ' + sensor.criticalThresholds.max);
      return '<article class="sensor ' + sensor.status + '"><div class="sensor-top"><span class="sensor-index">0' + (index + 1) + '</span>' + badge(sensor.status) + '</div><h3>' + escape(sensor.name) + '</h3><p class="reading">' + sensor.value.toFixed(1) + '<span>' + escape(sensor.unit) + '</span></p><div class="sensor-track" role="meter" aria-label="' + escape(sensor.name) + '" aria-valuemin="' + sensor.scale.min + '" aria-valuemax="' + sensor.scale.max + '" aria-valuenow="' + sensor.value + '" aria-valuetext="' + sensor.value + ' ' + escape(sensor.unit) + ', ' + sensor.status + '"><span class="healthy-band" style="left:' + percent(sensor.normalRange.min) + '%;width:' + (percent(sensor.normalRange.max) - percent(sensor.normalRange.min)) + '%"></span><span class="gauge-fill" style="width:' + percent(sensor.value) + '%"></span><i class="gauge-marker" style="left:' + percent(sensor.value) + '%"></i></div><div class="scale-labels"><span>' + sensor.scale.min + ' ' + escape(sensor.unit) + '</span><span>' + sensor.scale.max + ' ' + escape(sensor.unit) + '</span></div><p class="hint">Healthy: ' + sensor.normalRange.min + '–' + sensor.normalRange.max + ' ' + escape(sensor.unit) + '<br>Critical: ' + cutoffs.join(' or ') + ' ' + escape(sensor.unit) + '</p><p class="sensor-context hint">' + (fault ? 'Fault override · ' + numericStatus(sensor) + ' by range' : 'Range status · ' + numericStatus(sensor)) + '</p></article>';
    }).join('');
    $('incident-count').textContent = active.length + ' active';
    if (updateIncidents) renderIncidents(state);
    $('equipment').innerHTML = state.equipment.map(item => '<li><span><span class="equipment-icon" aria-hidden="true">◇</span>' + escape(item.name) + '</span>' + badge(item.status) + '</li>').join('');
    if (!$('failure-equipment').options.length) $('failure-equipment').innerHTML = state.equipment.map(item => '<option value="' + item.id + '">' + escape(item.name) + '</option>').join('');
    $('event-count').textContent = state.events.length + ' total';
    $('older-events').textContent = Math.max(0, state.events.length - 25) + ' older events not shown · full log retained';
    const scroll = $('timeline').scrollTop;
    $('timeline').innerHTML = state.events.slice(-25).reverse().map(event => '<li class="event-' + event.type.replace('.', '-') + '"><div class="event-time"><time datetime="' + event.at + '">' + time(event.at) + '</time><span>' + escape(event.type.replaceAll('.', ' / ')) + '</span></div><p>' + escape(event.message) + '</p></li>').join('');
    $('timeline').scrollTop = scroll;
  }
  function perform(action, message, focusId) {
    try {
      action(); render(); say(message);
      if (focusId) $(focusId).focus({ preventScroll: true });
    } catch (error) { say(error.message, true); }
  }
  function step(announce) {
    try {
      simulation.advanceTime(1); render(false);
      if (announce) say('Advanced 1 simulated minute. Telemetry updated.');
    } catch (error) { stop(); say(error.message, true); }
  }
  function updateRunControls() {
    $('run-state').textContent = timer === null ? 'Paused' : 'Running';
    $('run-toggle').textContent = timer === null ? 'Run' : 'Pause';
    $('run-toggle').setAttribute('aria-pressed', String(timer !== null));
  }
  function stop() {
    if (timer !== null) window.clearInterval(timer);
    timer = null; updateRunControls();
  }
  $('advance-time').addEventListener('click', () => step(true));
  $('run-toggle').addEventListener('click', () => {
    if (timer !== null) { stop(); say('Simulation paused. Advance manually or resume Run.'); }
    else { timer = window.setInterval(() => step(false), 5000); updateRunControls(); say('Simulation running: one simulated minute every 5 seconds.'); }
  });
  $('failure-form').addEventListener('submit', event => {
    event.preventDefault();
    const target = $('failure-equipment').value;
    const existing = simulation.getSnapshot().incidents.find(incident => incident.equipment === target && incident.status !== 'resolved');
    perform(() => { simulation.injectFailure(target); $('incident-filter').value = 'active'; }, existing ? 'Repeated failure recorded for ' + existing.id + '. No duplicate incident created.' : 'Failure injected. New incident added to the active response queue.');
  });
  $('incidents').addEventListener('submit', event => {
    const form = event.target.closest('.assignment-form');
    if (!form) return;
    event.preventDefault();
    const input = form.elements.owner;
    const owner = input.value.trim();
    const feedback = $('error-' + form.dataset.incident);
    try {
      simulation.assignIncident(form.dataset.incident, owner);
      input.value = owner; input.removeAttribute('aria-invalid'); feedback.textContent = '';
      render(); say(form.dataset.incident + ' assigned to ' + owner + '.');
    } catch (error) {
      input.setAttribute('aria-invalid', 'true'); feedback.textContent = error.message;
      input.focus({ preventScroll: true });
    }
  });
  $('incidents').addEventListener('click', event => {
    const button = event.target.closest('[data-resolve]');
    if (!button) return;
    perform(() => simulation.resolveIncident(button.dataset.resolve), button.dataset.resolve + ' resolved. Equipment restored; telemetry reflects current baseline.', 'incidents-heading');
  });
  $('incident-filter').addEventListener('change', () => renderIncidents(simulation.getSnapshot()));
  $('seed-form').addEventListener('submit', event => {
    event.preventDefault();
    if (!window.confirm('Reset the simulation? All incident assignments and events in this session will be cleared.')) return;
    perform(() => {
      stop(); simulation = StationSimulation.createSimulation($('seed').value);
      cards.clear(); $('incidents').replaceChildren(); $('incident-filter').value = 'active';
    }, 'Simulation reset and paused. Seed: ' + $('seed').value + '.');
  });
  render(); updateRunControls();
}());
