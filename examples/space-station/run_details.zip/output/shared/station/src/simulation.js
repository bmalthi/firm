/* Kestrel Station: deterministic, DOM-free simulation. No wall-clock or I/O. */
(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.StationSimulation = factory();
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const copy = value => JSON.parse(JSON.stringify(value));
  const definitions = [
    { id: 'coolant-pump', name: 'Coolant pump C-04', severity: 'warning', title: 'Coolant circulation below target', sensor: 'temperature', delta: 9 },
    { id: 'oxygen-scrubber', name: 'Oxygen scrubber A-02', severity: 'critical', title: 'Atmosphere processing interrupted', sensor: 'oxygen', delta: -3.2 },
    { id: 'power-relay', name: 'Power relay P-07', severity: 'critical', title: 'Primary power relay offline', sensor: 'power', delta: -24 },
    { id: 'comms-array', name: 'Communications array R-01', severity: 'warning', title: 'Downlink signal degraded', sensor: 'signal', delta: -30 }
  ];

  function createSimulation(seed = 'KESTREL-01') {
    if (typeof seed !== 'string' && (typeof seed !== 'number' || !Number.isFinite(seed))) {
      throw new TypeError('Seed must be a string or finite number.');
    }
    // FNV-1a seed hashing followed by a 32-bit LCG: stable in browser and Node.
    let randomState = 2166136261;
    for (const character of typeof seed + ':' + String(seed)) {
      randomState = Math.imul(randomState ^ character.codePointAt(0), 16777619) >>> 0;
    }
    const random = () => {
      randomState = (Math.imul(1664525, randomState) + 1013904223) >>> 0;
      return randomState / 4294967296;
    };
    const round = value => Math.round(value * 10) / 10;
    const clamp = (value, scale) => round(Math.max(scale.min, Math.min(scale.max, value)));
    const metadata = {
      oxygen: { scale: {min:0,max:25}, normalRange: {min:19.5,max:21.5}, criticalThresholds: {min:17.5,max:23.5}, drift: 0.6 },
      temperature: { scale: {min:0,max:40}, normalRange: {min:18,max:26}, criticalThresholds: {min:10,max:32}, drift: 1.6 },
      power: { scale: {min:0,max:100}, normalRange: {min:70,max:100}, criticalThresholds: {min:40,max:100}, drift: 4 },
      signal: { scale: {min:0,max:100}, normalRange: {min:75,max:100}, criticalThresholds: {min:35,max:100}, drift: 5 }
    };
    function numericStatus(value, sensor) {
      if (value < sensor.criticalThresholds.min || value > sensor.criticalThresholds.max) return 'critical';
      return value >= sensor.normalRange.min && value <= sensor.normalRange.max ? 'nominal' : 'warning';
    }
    const base = [
      { id: 'oxygen', name: 'Cabin oxygen', value: round(20.7 + random() * 0.4), unit: '%' },
      { id: 'temperature', name: 'Core temperature', value: round(21 + random() * 2), unit: '°C' },
      { id: 'power', name: 'Power reserve', value: round(92 + random() * 5), unit: '%' },
      { id: 'signal', name: 'Downlink integrity', value: round(95 + random() * 4), unit: '%' }
    ];
    const state = {
      seed, simulationMinute: 0, sensors: [], incidents: [], events: [],
      equipment: definitions.map(({ id, name }) => ({ id, name, status: 'nominal' }))
    };
    let tick = 0;
    const epoch = Date.UTC(2186, 3, 12, 8, 0, 0);
    function event(type, message, incidentId = null) {
      const at = new Date(epoch + tick++ * 60000).toISOString();
      state.events.push({ id: 'EVT-' + String(tick).padStart(4, '0'), type, message, at, incidentId });
      return at;
    }
    function refreshTelemetry() {
      state.sensors = base.map(sensor => {
        const failure = definitions.find(definition => definition.sensor === sensor.id && state.incidents.some(incident => incident.equipment === definition.id && incident.status !== 'resolved'));
        const { scale, normalRange, criticalThresholds } = metadata[sensor.id];
        const value = clamp(sensor.value + (failure ? failure.delta : 0), scale);
        return { ...sensor, scale, normalRange, criticalThresholds, value, status: failure ? failure.severity : numericStatus(value, metadata[sensor.id]) };
      });
      state.equipment.forEach(equipment => {
        const active = state.incidents.find(incident => incident.equipment === equipment.id && incident.status !== 'resolved');
        equipment.status = active ? (active.severity === 'critical' ? 'failed' : 'degraded') : 'nominal';
      });
    }
    function activeIncident(id) {
      const incident = state.incidents.find(item => item.id === id);
      if (!incident) throw new Error('Unknown incident.');
      if (incident.status === 'resolved') throw new Error('Incident is already resolved.');
      return incident;
    }
    function injectFailure(equipmentId) {
      const definition = definitions.find(item => item.id === equipmentId);
      if (!definition) throw new Error('Unknown equipment.');
      const existing = state.incidents.find(item => item.equipment === equipmentId && item.status !== 'resolved');
      if (existing) {
        event('failure.repeated', 'Repeated failure signal: ' + definition.name + ' · existing incident ' + existing.id, existing.id);
        return copy(existing);
      }
      const id = 'INC-' + String(state.incidents.length + 1).padStart(3, '0');
      const incident = {
        id, title: definition.title, equipment: equipmentId, severity: definition.severity,
        status: 'open', owner: null,
        createdAt: event('incident.created', definition.title + ' · ' + id, id), resolvedAt: null
      };
      state.incidents.push(incident);
      refreshTelemetry();
      return copy(incident);
    }
    function assignIncident(incidentId, owner) {
      const incident = activeIncident(incidentId);
      if (typeof owner !== 'string' || !owner.trim()) throw new Error('Enter a nonempty owner name.');
      incident.owner = owner.trim();
      event('incident.assigned', incident.id + ' assigned to ' + incident.owner, incident.id);
      return copy(incident);
    }
    function resolveIncident(incidentId) {
      const incident = activeIncident(incidentId);
      incident.status = 'resolved';
      incident.resolvedAt = event('incident.resolved', incident.id + ' resolved · equipment restored', incident.id);
      refreshTelemetry();
      return copy(incident);
    }
    function advanceTime(minutes = 1) {
      if (!Number.isInteger(minutes) || minutes < 1 || minutes > 60) throw new RangeError('Advance must be an integer from 1 to 60 minutes.');
      for (let minute = 0; minute < minutes; minute++) {
        base.forEach(sensor => {
          const settings = metadata[sensor.id];
          sensor.value = clamp(sensor.value + (random() * 2 - 1) * settings.drift, settings.scale);
        });
        state.simulationMinute++;
        refreshTelemetry();
        event('simulation.minute', 'Telemetry advanced · elapsed ' + state.simulationMinute + ' minute' + (state.simulationMinute === 1 ? '' : 's'));
      }
      return copy(state);
    }
    event('simulation.started', 'Kestrel Station simulation initialized. Synthetic telemetry online.');
    refreshTelemetry();
    injectFailure('coolant-pump');
    return { getSnapshot: () => copy(state), injectFailure, assignIncident, resolveIncident, advanceTime };
  }
  return { createSimulation };
}));
