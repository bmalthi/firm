const {chromium}=require('@playwright/test');
(async()=>{
const browser=await chromium.launch();
const page=await browser.newPage({viewport:{width:1440,height:1100},offline:true});
await page.goto('file:///qa/app/index.html');
await page.locator('.assignment-form input').fill('   ');
await page.locator('.assignment-form button').click();
console.log(JSON.stringify(await page.locator('#feedback').evaluate(el=>({text:el.textContent,top:el.getBoundingClientRect().top,bottom:el.getBoundingClientRect().bottom,viewport:innerHeight,role:el.getAttribute('role')})),null,2));
await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
