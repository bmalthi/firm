# Focused single-station refinement contract (phase 2)

Additive to `INTERFACE.md`. Keep exactly one simulation instance and preserve all existing mutation semantics. No multiple stations, persistence, network calls, or domain dependencies. Natural telemetry variation does **not** create incidents; only explicit failure injection does.

## Domain API and simulation clock

- Add `advanceTime(minutes = 1)`, accepting only integer values 1–60; invalid values throw without state mutation. Each minute advances all four baseline sensor readings using the instance's seeded PRNG, clamps values to the declared scale, updates statuses, increments `simulationMinute`, and appends one `simulation.minute` event. Returns a defensive snapshot.
- Same seed + same ordered API calls/arguments yields identical complete snapshots (values, event IDs/timestamps and history). Domain state never reads wall-clock time. Existing event timestamps remain deterministic logical UTC, +1 minute per event; `simulationMinute` counts only explicit advancement.
- Add `simulationMinute` to snapshot. Add `scale:{min,max}` and `normalRange:{min,max}` and `criticalThresholds:{min,max}` to each sensor. Values are rounded to one decimal before status evaluation; scale endpoints and normalRange endpoints are inclusive.
- Thresholds/status (all current units):
  - oxygen scale 0–25%, normal 19.5–21.5%, criticalThresholds `{min:17.5,max:23.5}` (critical strictly below 17.5% or above 23.5%);
  - core temperature scale 0–40 °C, normal 18–26 °C, criticalThresholds `{min:10,max:32}` (critical strictly below 10 °C or above 32 °C);
  - power reserve scale 0–100%, normal 70–100%, criticalThresholds `{min:40,max:100}` (critical strictly below 40%);
  - downlink integrity scale 0–100%, normal 75–100%, criticalThresholds `{min:35,max:100}` (critical strictly below 35%).
  The two `criticalThresholds` give cutoffs: status is critical strictly below `min` or strictly above `max`; nominal inside the inclusive `normalRange`; otherwise warning. For sensors with one-sided thresholds, use the scale endpoint as the unused cutoff. Exact normal and critical cutoffs are non-critical (nominal at normal bounds; warning at critical cutoffs). In an active equipment fault, the mapped sensor's status is the incident severity (warning/critical), taking precedence over numeric-band status; actual gauge value still shows the failure effect. Resolution removes the fault delta and recalculates status from the current, drifted baseline—not the initial sample.
- Existing injection, assign, resolve API remains compatible. Existing events remain complete; each repeat is a `failure.repeated` event linked to the existing active incident. Repeat count is the total such events for that incident over its lifetime; do not reset owner, createdAt, or count on repeat. Resolved incidents are not current; reinject creates a new incident.

## UI behavior

1. Provide **Advance 1 minute** plus **Run/Pause**. Run invokes the same one-minute API every 5 seconds; stopped/paused by default. No catch-up after delays/backgrounding: each delivered interval callback advances at most one step. Reset confirmation cancel leaves state, drafts, focus, and run/pause state unchanged. Accepted reset stops the timer, creates a fresh instance from the entered seed, resets elapsed minutes/history, and leaves it paused. Same seed/action/step sequence replays exactly; wall-clock run duration is not promised reproducible. `simulationMinute` changes only via `advanceTime`; event timestamps retain the v1 logical UTC rule (+1 minute per recorded event), distinct from elapsed minutes.
2. Put the active incident response queue and actions before telemetry in document/page order; reduce masthead/intro footprint. Keep equipment, telemetry and activity reachable.
3. Gauge shows numeric value/unit, scale endpoints, labeled healthy range and threshold-derived textual status; bar is mapped to declared scale (not raw `value%` unless applicable).
4. Show active count; each incident indicates repeat count when >0. Newest-first timeline shows newest 25 events from the full log plus an older-event count. Unique event IDs resolve same-time ordering; status/filter labels distinguish current incidents from history.
5. Invalid owner feedback appears beside the assignment control, remains visible without scrolling, and is announced accessibly. Global success/error feedback stays visible near the top-level controls; timer renders must not erase drafts, move focus/scroll, or replace feedback on every tick.
6. Preserve `file://` offline use and browser/CommonJS API compatibility. QA retains prior regression coverage and adds deterministic advancement, invalid steps, thresholds/boundaries, run/pause/reset, timer/input/focus, repeat counts, filters, feedback visibility and mobile/offline checks.

## Coordination

QA's risk plan is `QA-REFINEMENT-PLAN.md`. QA owns tests and independent findings, not production. Implementation owns production. Both must explicitly accept this contract before edits. Founder adjudicates any interface change. Scope stays single-station.
