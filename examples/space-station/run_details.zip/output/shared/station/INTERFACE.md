# v1 implementation contract (agreed before parallel work)

Product: offline, vanilla HTML/CSS/JS dashboard; no network requests or dependencies. Run by opening `index.html` (and optionally `python3 -m http.server` locally).

`src/simulation.js` is the canonical domain module and must also load in Node without a DOM. CommonJS export `createSimulation(seed)` (browser global `StationSimulation.createSimulation`). Deterministic PRNG from numeric/string seed. Returned object API:
- `getSnapshot()` -> `{seed, sensors:[{id,name,value,unit,status}], incidents:[{id,title,equipment,severity,status,owner,createdAt,resolvedAt}], events:[{id,type,message,at,incidentId}], equipment:[{id,name,status}]}`; return defensive copies.
- `injectFailure(equipmentId)` -> incident; repeated injection for same equipment with an unresolved incident returns that same incident and does not duplicate it, but records repeated event in timeline.
- `assignIncident(incidentId, owner)` updates owner and timeline; owner must be nonempty.
- `resolveIncident(incidentId)` updates status/resolvedAt and timeline; invalid/unknown/already resolved IDs throw.

Starter data and all IDs/timestamps deterministic for a seed. UI owns rendering and controls; all state transitions go through the API. QA owns tests and independent review, not production code. Implementation owns app and contract-conforming domain code. QA will add tests under `tests/` and report findings; coordinate any changes to this contract before implementation.
