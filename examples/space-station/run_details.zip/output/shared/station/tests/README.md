# Independent contract tests

From the app root, with Node.js installed:

```sh
node --test tests/*.test.cjs
```

No package installation, DOM, network, or test framework is needed. These tests target the agreed v1 public API in `../INTERFACE.md`; run only after `src/simulation.js` is delivered. Browser/UI checks are recorded separately in QA findings. Assertions deliberately do not require a specific seed algorithm, event message wording, or non-resolved status label.

## Optional browser smoke suite

`browser-smoke.cjs` uses QA-only Playwright tooling; it is intentionally excluded from `*.test.cjs` so the normal domain suite stays dependency-free. Copy the app into a scratch directory (here `station-qa/app`), then in `station-qa`:

```sh
npm init -y
npm install --save-dev @playwright/test@1.64.1
docker pull mcr.microsoft.com/playwright:v1.64.1-noble
docker run --rm --network none -v "$PWD:/qa" -w /qa \
  mcr.microsoft.com/playwright:v1.64.1-noble node app/tests/browser-smoke.cjs
```

Requires rootless Docker. With a working local Chromium installation instead, run `npx playwright install chromium`, then `node app/tests/browser-smoke.cjs`. Defaults: app root is the script's parent directory; artifacts go to `./evidence`. Override with `APP_ROOT` / `EVIDENCE_DIR` if needed. It opens a cold `file://` page with browser offline, observes public API calls, tests lifecycle/repetition/reset/filtering and narrow layouts, and fails on HTTP(S) requests or browser errors. Runtime app dependencies remain zero.

## Focused single-station refinements

`refinement.test.cjs` is additive coverage for `REFINEMENT-CONTRACT.md`: deterministic minute advancement and batching, atomic invalid inputs, separate elapsed/logical clocks, metadata/status/rounding/scale properties across seeded trajectories, fault precedence, current-baseline restoration, repetition/full history, and isolation. Existing v1 tests remain. Boundary diagnostics record exact cutoffs actually observed; no public value-setting API is available, so unobserved exact cutoffs are not claimed covered. The independent refinement report records results once the refined app is published.

The current `browser-smoke.cjs` covers the refined single-station UI (9 grouped checks), including virtual-clock Run/Pause/no-catch-up/reset, draft/focus/selection/scroll stability, inline validation, scale-mapped gauges and healthy-band color invariance, repeats/full-log counts, mobile full lifecycle, and offline cold start. Clock behavior is controlled with Playwright's installed clock API to test interval boundaries precisely.

For a separate uninstrumented browser run using real time (about 11 seconds), use the same container command with `node app/tests/browser-real-clock.cjs`. This checks Run's first interval, Pause across the next interval, and manual Step. See `QA-REFINEMENT-REPORT.md` for current results; `QA-REPORT.md`/`qa-evidence` retain historical v1 results.
