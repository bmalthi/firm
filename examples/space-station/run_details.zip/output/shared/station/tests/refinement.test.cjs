'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {createSimulation} = require('../src/simulation.js');
const fresh = (seed='qa-refinement') => createSimulation(seed);
const clearFaults = sim => {
  for (const i of sim.getSnapshot().incidents) if (i.status !== 'resolved') sim.resolveIncident(i.id);
};
const classify = s => s.value < s.criticalThresholds.min || s.value > s.criticalThresholds.max ? 'critical'
  : s.value >= s.normalRange.min && s.value <= s.normalRange.max ? 'nominal' : 'warning';
const specs = {
  oxygen: {scale:{min:0,max:25},normalRange:{min:19.5,max:21.5},criticalThresholds:{min:17.5,max:23.5}},
  temperature: {scale:{min:0,max:40},normalRange:{min:18,max:26},criticalThresholds:{min:10,max:32}},
  power: {scale:{min:0,max:100},normalRange:{min:70,max:100},criticalThresholds:{min:40,max:100}},
  signal: {scale:{min:0,max:100},normalRange:{min:75,max:100},criticalThresholds:{min:35,max:100}}
};

test('refinement: elapsed time starts at zero and exposes exact gauge/threshold metadata', () => {
  const s=fresh().getSnapshot();
  assert.equal(s.simulationMinute,0);
  assert.equal(s.sensors.length,4);
  assert.deepEqual(s.sensors.map(v=>v.id).sort(),Object.keys(specs).sort());
  for (const sensor of s.sensors) {
    assert.ok(specs[sensor.id],sensor.id);
    for (const k of ['scale','normalRange','criticalThresholds']) assert.deepEqual(sensor[k],specs[sensor.id][k]);
  }
});

test('refinement: default one-minute advance and maximum batch produce one event per minute', () => {
  const sim=fresh(), before=sim.getSnapshot();
  assert.equal(typeof sim.advanceTime,'function');
  const first=sim.advanceTime();
  assert.deepEqual(first,sim.getSnapshot());
  assert.equal(first.simulationMinute,1);
  assert.equal(first.events.length,before.events.length+1);
  assert.equal(first.events.at(-1).type,'simulation.minute');
  const next=sim.advanceTime(60);
  assert.equal(next.simulationMinute,61);
  assert.equal(next.events.length,before.events.length+61);
  assert.ok(next.events.slice(before.events.length).every(e=>e.type==='simulation.minute'));
  assert.notDeepEqual(next.sensors.map(s=>s.value),before.sensors.map(s=>s.value));
});

test('refinement: invalid advances reject atomically, including no PRNG consumption', () => {
  const a=fresh(), b=fresh();
  for (const bad of [0,-1,61,1.5,NaN,Infinity,-Infinity,null,'1',true,{},[],[1]]) {
    const before=a.getSnapshot();
    assert.throws(()=>a.advanceTime(bad),`invalid ${String(bad)}`);
    assert.deepEqual(a.getSnapshot(),before);
  }
  a.advanceTime(60); b.advanceTime(60);
  assert.deepEqual(a.getSnapshot(),b.getSnapshot(),'invalid calls do not alter future PRNG output');
});

test('refinement: batch advance equals repeated individual steps for numeric/string seeds', () => {
  for (const seed of [0,12345,'qa-step','🌌']) {
    const a=fresh(seed), b=fresh(seed);
    a.advanceTime(60);
    for(let i=0;i<60;i++) b.advanceTime(1);
    assert.deepEqual(a.getSnapshot(),b.getSnapshot());
  }
});

test('refinement: ordered action/step replay remains fully deterministic', () => {
  for(const seed of [0,1,'interleaved-steps']) {
    const run=()=>{
      const sim=fresh(seed);
      sim.advanceTime(3);
      const i=sim.injectFailure('oxygen-scrubber');
      sim.advanceTime(7);
      sim.assignIncident(i.id,'QA Drift');
      sim.injectFailure('oxygen-scrubber');
      sim.advanceTime(10);
      sim.resolveIncident(i.id);
      sim.advanceTime(60);
      sim.injectFailure('oxygen-scrubber');
      return sim.getSnapshot();
    };
    assert.deepEqual(run(),run());
  }
});

test('refinement: mutations do not advance elapsed minute but all events keep +1 minute logical time',()=>{
  const sim=fresh();
  const incident=sim.injectFailure('oxygen-scrubber');
  sim.assignIncident(incident.id,'QA');
  sim.injectFailure('oxygen-scrubber');
  assert.equal(sim.getSnapshot().simulationMinute,0);
  sim.advanceTime(3);
  sim.resolveIncident(incident.id);
  const s=sim.getSnapshot();
  assert.equal(s.simulationMinute,3);
  for(let n=1;n<s.events.length;n++) assert.equal(Date.parse(s.events[n].at)-Date.parse(s.events[n-1].at),60000);
  assert.equal(new Set(s.events.map(e=>e.id)).size,s.events.length);
});

test('refinement: seeded drift does not create incidents or mutate incident lifecycle data',()=>{
  const sim=fresh();
  const before=sim.getSnapshot().incidents;
  for(let i=0;i<10;i++) sim.advanceTime(60);
  assert.deepEqual(sim.getSnapshot().incidents,before);
});

test('refinement: threshold status agrees with rounded values across seeded trajectories',(t)=>{
  const seen=new Set();
  const coverage=Object.fromEntries(Object.keys(specs).map(id=>[id,{min:Infinity,max:-Infinity,statuses:{},exact:{},neighbors:{}}]));
  for(const seed of [0,1,2,3,'drift-a','drift-b','drift-c','drift-d']) {
    const sim=fresh(seed); clearFaults(sim);
    for(let i=0;i<1200;i++) {
      const s=sim.advanceTime(1);
      for(const sensor of s.sensors) {
        assert.ok(sensor.value>=sensor.scale.min && sensor.value<=sensor.scale.max,`${sensor.id} scale`);
        assert.ok(Math.abs(sensor.value*10-Math.round(sensor.value*10))<1e-8,'one decimal');
        assert.equal(sensor.status,classify(sensor),`${sensor.id}=${sensor.value}`);
        seen.add(sensor.status);
        const c=coverage[sensor.id];
        c.min=Math.min(c.min,sensor.value); c.max=Math.max(c.max,sensor.value);
        c.statuses[sensor.status]=(c.statuses[sensor.status]||0)+1;
        for(const value of new Set([...Object.values(sensor.normalRange),...Object.values(sensor.criticalThresholds)])) {
          if(sensor.value===value) c.exact[value]=(c.exact[value]||0)+1;
          for(const delta of [-0.1,0.1]) {
            const neighbor=Math.round((value+delta)*10)/10;
            if(neighbor>=sensor.scale.min && neighbor<=sensor.scale.max && sensor.value===neighbor) c.neighbors[neighbor]=(c.neighbors[neighbor]||0)+1;
          }
        }
      }
    }
  }
  assert.ok(seen.has('nominal'));
  t.diagnostic('Seeded threshold coverage (9600 minute samples per sensor): '+JSON.stringify(coverage));
  // No requirement that a particular finite seed trajectory hits every boundary.
});

test('refinement: active fault severity overrides numeric bands across steps',()=>{
  const equipmentToSensor={'coolant-pump':'temperature','oxygen-scrubber':'oxygen','power-relay':'power','comms-array':'signal'};
  const sim=fresh(); clearFaults(sim);
  for(const [equipment,sensorId] of Object.entries(equipmentToSensor)) {
    const incident=sim.injectFailure(equipment);
    for(let i=0;i<5;i++) {
      const s=sim.advanceTime(1);
      assert.equal(s.sensors.find(v=>v.id===sensorId).status,incident.severity);
    }
    sim.resolveIncident(incident.id);
    const restored=sim.getSnapshot().sensors.find(v=>v.id===sensorId);
    assert.equal(restored.status,classify(restored));
  }
});

test('refinement: resolution restores current drift baseline, not initial sample',()=>{
  const a=fresh(),b=fresh(); clearFaults(a); clearFaults(b);
  const initial=a.getSnapshot().sensors;
  const incident=a.injectFailure('oxygen-scrubber');
  a.advanceTime(60);b.advanceTime(60);
  a.resolveIncident(incident.id);
  assert.deepEqual(a.getSnapshot().sensors,b.getSnapshot().sensors);
  assert.notDeepEqual(a.getSnapshot().sensors,initial,'baseline has actually evolved');
});

test('refinement: repeated incidents preserve owner/creation across steps; history remains complete',()=>{
  const sim=fresh(); clearFaults(sim);
  const first=sim.injectFailure('oxygen-scrubber');
  sim.assignIncident(first.id,'Lifetime Operator');
  for(let i=0;i<30;i++) {sim.advanceTime(1);sim.injectFailure('oxygen-scrubber');}
  const s=sim.getSnapshot(),current=s.incidents.find(i=>i.id===first.id);
  assert.equal(current.owner,'Lifetime Operator');
  assert.equal(current.createdAt,first.createdAt);
  assert.equal(s.incidents.filter(i=>i.equipment==='oxygen-scrubber'&&i.status!=='resolved').length,1);
  assert.equal(s.events.filter(e=>e.incidentId===first.id&&e.type==='failure.repeated').length,30);
  assert.ok(s.events.length>25);
  sim.resolveIncident(first.id);
  const next=sim.injectFailure('oxygen-scrubber');
  assert.notEqual(next.id,first.id);
  assert.equal(sim.getSnapshot().events.filter(e=>e.incidentId===next.id&&e.type==='failure.repeated').length,0);
});

test('refinement: advancement snapshots and nested threshold metadata are defensive',()=>{
  const sim=fresh(),other=fresh();
  const untouched=other.getSnapshot();
  const returned=sim.advanceTime(1),before=sim.getSnapshot();
  returned.simulationMinute=123456;
  for(const sensor of returned.sensors) {
    sensor.value=-999;
    sensor.scale.min=-999;
    sensor.normalRange.max=-999;
    sensor.criticalThresholds.min=-999;
  }
  returned.events.at(-1).message='tampered';
  assert.deepEqual(sim.getSnapshot(),before);
  assert.deepEqual(other.getSnapshot(),untouched);
});


test('refinement: advancement replay is independent of wall-clock delays',async()=>{
  const a=fresh('delayed-advance'),b=fresh('delayed-advance');
  a.advanceTime(5);
  await new Promise(resolve=>setTimeout(resolve,35));
  b.advanceTime(5);
  assert.deepEqual(a.getSnapshot(),b.getSnapshot());
});
