'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createSimulation } = require('../src/simulation.js');

const fresh = (seed = 'qa-station-v1') => createSimulation(seed);
const pickEquipment = sim => {
  const s = sim.getSnapshot();
  assert.ok(s.equipment.length, 'at least one equipment failure target is required');
  const target = s.equipment.find(e => !s.incidents.some(i => i.equipment === e.id && i.status !== 'resolved'));
  if (target) return target;
  // All equipment may have starter failures: close those before creation assertions.
  for (const i of s.incidents.filter(i => i.status !== 'resolved')) sim.resolveIncident(i.id);
  return s.equipment[0];
};
const newIncident = sim => sim.injectFailure(pickEquipment(sim).id);
const incidentById = (sim, id) => sim.getSnapshot().incidents.find(i => i.id === id);

// These tests intentionally exercise the agreed public API, not production internals.
test('module has a DOM-free CommonJS factory and complete snapshot shape', () => {
  assert.equal(typeof createSimulation, 'function');
  const s = fresh().getSnapshot();
  assert.ok(Object.hasOwn(s, 'seed'));
  for (const k of ['sensors', 'incidents', 'events', 'equipment']) assert.ok(Array.isArray(s[k]), k);
  assert.ok(s.sensors.length, 'dashboard has simulated sensor readings');
  for (const sensor of s.sensors) {
    for (const k of ['id', 'name', 'value', 'unit', 'status']) assert.ok(Object.hasOwn(sensor, k), `sensor.${k}`);
    assert.ok(Number.isFinite(sensor.value));
  }
  for (const e of s.equipment) for (const k of ['id', 'name', 'status']) assert.ok(Object.hasOwn(e, k), `equipment.${k}`);
});

test('injecting a failure creates a complete persisted incident and timeline event', () => {
  const sim = fresh();
  const equipment = pickEquipment(sim);
  const before = sim.getSnapshot();
  const incident = sim.injectFailure(equipment.id);
  for (const k of ['id', 'title', 'equipment', 'severity', 'status', 'owner', 'createdAt', 'resolvedAt']) {
    assert.ok(Object.hasOwn(incident, k), `incident.${k}`);
  }
  assert.ok(incident.id);
  assert.ok(incident.title);
  assert.ok(incident.severity);
  assert.equal(incident.equipment, equipment.id);
  assert.notEqual(incident.status, 'resolved');
  assert.equal(incident.resolvedAt, null);
  assert.deepEqual(incidentById(sim, incident.id), incident);
  const after = sim.getSnapshot();
  assert.equal(after.incidents.length, before.incidents.length + 1);
  assert.equal(after.events.length, before.events.length + 1);
  const event = after.events.at(-1);
  for (const k of ['id', 'type', 'message', 'at', 'incidentId']) assert.ok(Object.hasOwn(event, k), `event.${k}`);
  assert.equal(event.incidentId, incident.id);
});

test('assignment persists nonempty ownership and records the linked event', () => {
  const sim = fresh();
  const { id } = newIncident(sim);
  const before = sim.getSnapshot().events.length;
  sim.assignIncident(id, 'QA Flight Controller');
  assert.equal(incidentById(sim, id).owner, 'QA Flight Controller');
  assert.equal(sim.getSnapshot().events.length, before + 1);
  assert.equal(sim.getSnapshot().events.at(-1).incidentId, id);
});

test('empty and whitespace-only owners are rejected without mutation', () => {
  const sim = fresh();
  const { id } = newIncident(sim);
  for (const owner of ['', ' ', '\t\n']) {
    const before = sim.getSnapshot();
    assert.throws(() => sim.assignIncident(id, owner));
    assert.deepEqual(sim.getSnapshot(), before);
  }
});

test('resolution closes the incident, timestamps it, and adds a linked event', () => {
  const sim = fresh();
  const { id } = newIncident(sim);
  sim.assignIncident(id, 'QA');
  const before = sim.getSnapshot().events.length;
  sim.resolveIncident(id);
  const resolved = incidentById(sim, id);
  assert.equal(resolved.status, 'resolved');
  assert.ok(resolved.resolvedAt !== null && resolved.resolvedAt !== undefined);
  assert.equal(resolved.owner, 'QA');
  assert.equal(sim.getSnapshot().events.length, before + 1);
  assert.equal(sim.getSnapshot().events.at(-1).incidentId, id);
});

test('invalid, unknown, and already resolved IDs throw without mutation', () => {
  const sim = fresh();
  for (const id of [undefined, null, '', 'qa-id-that-does-not-exist']) {
    const before = sim.getSnapshot();
    assert.throws(() => sim.resolveIncident(id));
    assert.deepEqual(sim.getSnapshot(), before);
  }
  const { id } = newIncident(sim);
  sim.resolveIncident(id);
  const before = sim.getSnapshot();
  assert.throws(() => sim.resolveIncident(id));
  assert.deepEqual(sim.getSnapshot(), before);
});

test('repeated failure reuses unresolved incident but logs every occurrence', () => {
  const sim = fresh();
  const equipment = pickEquipment(sim);
  const first = sim.injectFailure(equipment.id);
  sim.assignIncident(first.id, 'Repeat Operator');
  const before = sim.getSnapshot();
  for (let i = 1; i <= 12; i++) {
    const repeated = sim.injectFailure(equipment.id);
    assert.equal(repeated.id, first.id);
    assert.equal(repeated.owner, 'Repeat Operator');
    const after = sim.getSnapshot();
    assert.equal(after.incidents.length, before.incidents.length);
    assert.equal(after.events.length, before.events.length + i);
    assert.equal(after.events.at(-1).incidentId, first.id);
  }
  const ids = sim.getSnapshot().events.map(e => e.id);
  assert.equal(new Set(ids).size, ids.length, 'repeat timeline events have unique IDs');
});

test('failure after resolution creates a distinct active incident', () => {
  const sim = fresh();
  const equipment = pickEquipment(sim);
  const first = sim.injectFailure(equipment.id);
  sim.resolveIncident(first.id);
  const before = sim.getSnapshot().incidents.length;
  const next = sim.injectFailure(equipment.id);
  assert.notEqual(next.id, first.id);
  assert.notEqual(next.status, 'resolved');
  assert.equal(incidentById(sim, first.id).status, 'resolved');
  assert.equal(sim.getSnapshot().incidents.length, before + 1);
});

test('numeric/string seeds reproduce complete starter data and lifecycle replay', () => {
  for (const seed of [0, 1, 12345, 'qa-seed', 'another-seed']) {
    const a = fresh(seed), b = fresh(seed);
    assert.deepEqual(a.getSnapshot(), b.getSnapshot());
    const equipment = pickEquipment(a);
    const ai = a.injectFailure(equipment.id), bi = b.injectFailure(equipment.id);
    assert.deepEqual(ai, bi);
    for (const sim of [a, b]) {
      sim.injectFailure(equipment.id);
      sim.assignIncident(ai.id, 'Deterministic Operator');
      sim.resolveIncident(ai.id);
      sim.injectFailure(equipment.id);
    }
    assert.deepEqual(a.getSnapshot(), b.getSnapshot(), `seed ${seed}: IDs, timestamps, readings, events`);
  }
});

test('simulation instances do not share mutable state', () => {
  const a = fresh(), b = fresh();
  const before = b.getSnapshot();
  newIncident(a);
  assert.deepEqual(b.getSnapshot(), before);
});

test('snapshots are defensive at array and nested record levels', () => {
  const sim = fresh();
  newIncident(sim);
  const before = sim.getSnapshot();
  const snapshot = sim.getSnapshot();
  for (const key of ['sensors', 'incidents', 'events', 'equipment']) {
    assert.ok(snapshot[key].length, `${key} populated for copy test`);
    snapshot[key][0].id = 'tampered';
    for (const k of Object.keys(snapshot[key][0])) snapshot[key][0][k] = 'tampered';
    snapshot[key].push({ id: 'fake' });
  }
  snapshot.seed = 'tampered';
  assert.deepEqual(sim.getSnapshot(), before);
});

// Seed-sensitive readings are required by the deterministic seeded simulation,
// without pinning any PRNG implementation or exact sample values.
test('different seeds influence simulated sensor readings', () => {
  const readings = [0, 1, 12345, 'qa-seed'].map(seed =>
    JSON.stringify(fresh(seed).getSnapshot().sensors.map(s => s.value)));
  assert.ok(new Set(readings).size > 1, 'seed must not be ignored');
});

test('seed replay does not depend on wall-clock time', async () => {
  const before = fresh('delayed-replay');
  const first = newIncident(before);
  before.assignIncident(first.id, 'QA');
  before.resolveIncident(first.id);
  await new Promise(resolve => setTimeout(resolve, 30));
  const after = fresh('delayed-replay');
  const next = newIncident(after);
  after.assignIncident(next.id, 'QA');
  after.resolveIncident(next.id);
  assert.deepEqual(after.getSnapshot(), before.getSnapshot());
});

test('classic browser script exports the same deterministic factory without CommonJS', () => {
  const fs = require('node:fs');
  const vm = require('node:vm');
  const context = vm.createContext({});
  vm.runInContext(fs.readFileSync(require.resolve('../src/simulation.js'), 'utf8'), context);
  assert.equal(typeof context.StationSimulation?.createSimulation, 'function');
  const browser = context.StationSimulation.createSimulation('browser-seed');
  assert.deepEqual(JSON.parse(JSON.stringify(browser.getSnapshot())), fresh('browser-seed').getSnapshot());
});

test('all starter and lifecycle records keep required snapshot fields', () => {
  const sim = fresh();
  const verify = () => {
    const s = sim.getSnapshot();
    for (const incident of s.incidents) {
      for (const k of ['id', 'title', 'equipment', 'severity', 'status', 'owner', 'createdAt', 'resolvedAt']) {
        assert.ok(Object.hasOwn(incident, k), `incident.${k}`);
      }
    }
    for (const event of s.events) {
      for (const k of ['id', 'type', 'message', 'at', 'incidentId']) assert.ok(Object.hasOwn(event, k), `event.${k}`);
    }
  };
  verify();
  const target = pickEquipment(sim);
  const { id } = sim.injectFailure(target.id);
  sim.injectFailure(target.id);
  sim.assignIncident(id, 'QA');
  sim.resolveIncident(id);
  verify();
});
