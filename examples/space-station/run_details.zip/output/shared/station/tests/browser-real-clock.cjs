const assert=require('node:assert/strict');
const {chromium}=require('@playwright/test');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const root=process.env.APP_ROOT||path.resolve(__dirname,'..');
(async()=>{
 const browser=await chromium.launch();
 try{
  const context=await browser.newContext({offline:true,viewport:{width:1440,height:1100}});
  const page=await context.newPage();const errors=[],requests=[];
  page.on('pageerror',e=>errors.push(e.message));
  page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url());});
  await page.goto(pathToFileURL(path.join(root,'index.html')).href);
  assert.equal(await page.locator('#elapsed').textContent(),'Elapsed 0 min');
  await page.locator('#run-toggle').click();
  await page.waitForFunction(()=>document.querySelector('#elapsed').textContent==='Elapsed 1 min',{},{timeout:8000});
  await page.locator('#run-toggle').click();
  const elapsed=await page.locator('#elapsed').textContent();
  await page.waitForTimeout(5500);
  assert.equal(await page.locator('#elapsed').textContent(),elapsed);
  await page.locator('#advance-time').click();
  assert.equal(await page.locator('#elapsed').textContent(),'Elapsed 2 min');
  assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
  console.log('PASS: uninstrumented offline file:// real-clock Run advances at first 5-second callback; Pause holds across next interval; manual Step advances');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
