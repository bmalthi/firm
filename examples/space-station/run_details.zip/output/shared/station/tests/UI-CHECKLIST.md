# v1 independent browser checks

Run against a scratch copy, not a live shared working tree. Record actual outcomes in QA-REPORT.md; this checklist alone is not verification.

- Open index.html directly via file://, with browser networking disabled; no external fonts/scripts/styles/API requests, missing assets, or uncaught JS errors.
- Sensor readings, equipment, incidents with severity/ownership, and chronological event timeline are visible.
- Inject a failure, assign an owner, resolve the incident; verify rendered state and timeline agree with domain API.
- Repeated injection for the same unresolved equipment retains one incident and appends a repeated event. Resolve then reinject to get a new incident.
- Empty/whitespace assignment does not silently persist; feedback is visible.
- Reset the same seed and repeat a flow: IDs, readings, timestamps, and timeline reproduce. Test numeric/string seed control where applicable.
- Narrow and desktop viewports: no page-wide clipping, essential controls reachable, labels/focus visible, severity conveyed by text as well as color.
- With a freshly opened file and networking blocked from the start, perform the core lifecycle; online caching must not be necessary.
