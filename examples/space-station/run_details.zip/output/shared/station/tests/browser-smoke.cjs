'use strict';
// Optional QA tooling, never loaded by the dashboard. See tests/README.md.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {chromium}=require('@playwright/test');
const root=process.env.APP_ROOT||path.resolve(__dirname,'..');
const evidence=process.env.EVIDENCE_DIR||path.resolve('evidence');
fs.mkdirSync(evidence,{recursive:true});
(async()=>{
 const browser=await chromium.launch({headless:true});
 const errors=[],requests=[],notes=[];
 let passes=0;
 const pass=label=>{passes++;console.log('PASS: '+label);};
 try {
  const context=await browser.newContext({offline:true,viewport:{width:1440,height:1100}});
  await context.addInitScript(()=>{
   window.__qaCalls=[];
   let module;
   Object.defineProperty(window,'StationSimulation',{configurable:true,get:()=>module,set(value){
    module=value;
    const original=value.createSimulation;
    value.createSimulation=function(seed){
     const sim=original(seed);window.__qaCalls.push(['createSimulation',seed]);
     for(const name of ['injectFailure','assignIncident','resolveIncident','advanceTime']) {
      const method=sim[name];
      sim[name]=function(...args){window.__qaCalls.push([name,...args]);return method(...args);};
     }
     window.__qaSim=sim;return sim;
    };
   }});
  });
  const page=await context.newPage();
  page.on('pageerror',e=>errors.push(e.message));
  page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url());});
  await page.clock.install({time:new Date('2026-11-05T12:00:00Z')});
  await page.goto(pathToFileURL(path.join(root,'index.html')).href);
  await page.locator('.incident').first().waitFor();
  await page.clock.pauseAt(new Date('2026-11-05T12:00:01Z'));
  const snapshot=()=>page.evaluate(()=>window.__qaSim.getSnapshot());
  const card=id=>page.locator(`article[data-incident="${id}"]`);
  const owner=id=>page.locator(`#owner-${id}`);
  const inject=()=>page.locator('#failure-form button').click();
  const step=()=>page.locator('#advance-time').click();
  const run=()=>page.locator('#run-toggle').click();
  const reset=async(seed,accept)=>{
   await page.locator('#seed').fill(seed);
   page.once('dialog',d=>accept?d.accept():d.dismiss());
   await page.locator('#seed-form button').click();
  };
  const initial=await snapshot();
  assert.equal(initial.simulationMinute,0);
  assert.equal(await page.locator('#run-state').textContent(),'Paused');
  assert.equal(await page.locator('#sensors .sensor').count(),4);
  assert.equal(await page.locator('#equipment li').count(),4);
  assert.equal(await page.locator('.incident:visible').count(),1);
  const order=await page.evaluate(()=>{
   const q=document.querySelector('.incidents-panel'),t=document.querySelector('.telemetry');
   return !!(q.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_FOLLOWING);
  });
  assert.ok(order,'queue before telemetry in DOM');
  await page.clock.runFor(15000);
  assert.deepEqual(await snapshot(),initial,'paused default has no progression');
  await page.screenshot({path:path.join(evidence,'desktop-initial.png'),fullPage:true});
  pass('cold offline file:// startup, paused default, incident-first DOM and all dashboard regions');

  for(let i=0;i<initial.sensors.length;i++) {
   const sensor=initial.sensors[i],el=page.locator('.sensor').nth(i),meter=el.getByRole('meter');
   assert.equal(Number(await meter.getAttribute('aria-valuenow')),sensor.value);
   assert.equal(Number(await meter.getAttribute('aria-valuemin')),sensor.scale.min);
   assert.equal(Number(await meter.getAttribute('aria-valuemax')),sensor.scale.max);
   const width=await el.locator('.gauge-fill').evaluate(n=>parseFloat(n.style.width));
   assert.ok(Math.abs(width-(sensor.value-sensor.scale.min)/(sensor.scale.max-sensor.scale.min)*100)<.0001);
   const band=await el.locator('.healthy-band').evaluate(n=>({left:parseFloat(n.style.left),width:parseFloat(n.style.width),color:getComputedStyle(n).backgroundColor}));
   assert.ok(Math.abs(band.left-(sensor.normalRange.min-sensor.scale.min)/(sensor.scale.max-sensor.scale.min)*100)<.0001);
   assert.ok(Math.abs(band.width-(sensor.normalRange.max-sensor.normalRange.min)/(sensor.scale.max-sensor.scale.min)*100)<.0001);
   assert.match(await el.innerText(),/Healthy:/);
   assert.match(await el.innerText(),/Critical:/);
   notes.push({sensor:sensor.id,status:sensor.status,healthyBand:band});
  }
  assert.equal(notes[1].healthyBand.color,notes[0].healthyBand.color,'healthy-band color must not change with warning status');
  await step();
  assert.equal((await snapshot()).simulationMinute,1);
  assert.notDeepEqual((await snapshot()).sensors.map(s=>s.value),initial.sensors.map(s=>s.value));
  pass('numeric gauges map to declared scale; healthy/critical labels and explicit deterministic stepping');

  const starter=initial.incidents[0].id;
  await owner(starter).fill('   ');
  await card(starter).locator('form button').click();
  assert.equal(await owner(starter).getAttribute('aria-invalid'),'true');
  const inline=page.locator(`#error-${starter}`);
  assert.match(await inline.innerText(),/nonempty owner/);
  const errorRect=await inline.evaluate(n=>({top:n.getBoundingClientRect().top,bottom:n.getBoundingClientRect().bottom,h:innerHeight}));
  assert.ok(errorRect.top>=0&&errorRect.bottom<=errorRect.h,'inline validation is in viewport');
  assert.equal(await inline.getAttribute('role'),'status');
  notes.push({viewport:'desktop',errorRect});
  await page.screenshot({path:path.join(evidence,'desktop-inline-error.png'),fullPage:true});
  assert.equal(await owner(starter).evaluate(n=>n===document.activeElement),true);
  const globalFeedback=await page.locator('#feedback').innerText();
  await run();
  const runningFeedback=await page.locator('#feedback').innerText();
  const beforeTick=await snapshot();
  await page.clock.runFor(4999);
  assert.equal((await snapshot()).simulationMinute,beforeTick.simulationMinute);
  await page.clock.runFor(1);
  assert.equal((await snapshot()).simulationMinute,beforeTick.simulationMinute+1);
  assert.equal(await inline.innerText(),'Enter a nonempty owner name.');
  assert.equal(await page.locator('#feedback').innerText(),runningFeedback,'tick does not replace feedback');
  assert.equal(await owner(starter).inputValue(),'   ');
  pass('whitespace error is adjacent/in-viewport/live; timer keeps validation and success messages intact');

  await owner(starter).fill('Unsubmitted Flight Draft');
  await owner(starter).evaluate(n=>{n.focus();n.setSelectionRange(3,8);});
  await page.locator('#seed').evaluate(n=>{n.value='Unsubmitted Seed Draft';});
  await page.evaluate(()=>window.scrollTo(0,100));
  const beforeFocus=await page.evaluate(()=>({focus:document.activeElement.id,scroll:scrollY,start:document.activeElement.selectionStart,end:document.activeElement.selectionEnd}));
  const minuteBefore=(await snapshot()).simulationMinute;
  await page.clock.runFor(10000);
  const afterFocus=await page.evaluate(()=>({focus:document.activeElement.id,scroll:scrollY,start:document.activeElement.selectionStart,end:document.activeElement.selectionEnd}));
  assert.deepEqual(afterFocus,beforeFocus);
  assert.equal((await snapshot()).simulationMinute,minuteBefore+2);
  assert.equal(await owner(starter).inputValue(),'Unsubmitted Flight Draft');
  assert.equal(await page.locator('#seed').inputValue(),'Unsubmitted Seed Draft');
  await page.clock.fastForward(60000);
  assert.equal((await snapshot()).simulationMinute,minuteBefore+3,'delayed callback advances once, not catch-up');
  await run();
  const paused=await snapshot();
  await page.clock.runFor(15000);
  assert.deepEqual(await snapshot(),paused);
  for(let i=0;i<3;i++){await run();await run();}
  await run();
  const restart=(await snapshot()).simulationMinute;
  await page.clock.runFor(5000);
  assert.equal((await snapshot()).simulationMinute,restart+1,'no duplicated intervals');
  pass('5-second run/pause, no catch-up, repeated toggles, owner/seed drafts, selection/focus and scroll stability');

  const beforeCancel=await snapshot();
  await reset('Cancelled Seed',false);
  assert.deepEqual(await snapshot(),beforeCancel);
  assert.equal(await page.locator('#run-state').textContent(),'Running');
  assert.equal(await owner(starter).inputValue(),'Unsubmitted Flight Draft');
  await page.clock.runFor(5000);
  assert.equal((await snapshot()).simulationMinute,beforeCancel.simulationMinute+1);
  await reset(initial.seed,true);
  assert.deepEqual(await snapshot(),initial);
  assert.equal(await page.locator('#run-state').textContent(),'Paused');
  await page.clock.runFor(20000);
  assert.deepEqual(await snapshot(),initial);
  pass('reset cancel retains running state/drafts; confirmed reset stops timer and restores fresh paused seed');

  await page.locator('#failure-equipment').selectOption('oxygen-scrubber');
  await inject();
  let state=await snapshot();
  const incident=state.incidents.at(-1),count=state.incidents.length;
  assert.match(await page.locator('#station-condition').innerText(),/Critical/);
  assert.equal(await page.locator('.sensor').first().locator('.healthy-band').evaluate(n=>getComputedStyle(n).backgroundColor),notes[0].healthyBand.color,'critical fault must not recolor healthy band');
  const evil='<img src=x onerror="window.BAD=1"> Flight QA';
  await owner(incident.id).fill(evil);
  await card(incident.id).locator('form button').click();
  assert.equal(await card(incident.id).locator('.owner-name').innerText(),evil);
  assert.equal(await page.locator('#incidents img').count(),0);
  assert.equal(await page.evaluate(()=>window.BAD),undefined);
  for(let i=0;i<3;i++){await step();await inject();}
  state=await snapshot();
  assert.equal(state.incidents.length,count);
  assert.equal(state.incidents.at(-1).owner,evil);
  assert.equal(state.incidents.at(-1).createdAt,incident.createdAt);
  assert.match(await card(incident.id).locator('.activity-count').innerText(),/3 repeat signals/);
  const linked=state.events.filter(e=>e.incidentId===incident.id).length;
  assert.match(await card(incident.id).locator('.activity-count').innerText(),new RegExp(`${linked} linked events`));
  await card(incident.id).locator('[data-resolve]').click();
  assert.equal((await snapshot()).incidents.at(-1).status,'resolved');
  assert.equal(await card(incident.id).isVisible(),false);
  await page.locator('#incident-filter').selectOption('resolved');
  assert.equal(await card(incident.id).isVisible(),true);
  assert.match(await card(incident.id).locator('.activity-count').innerText(),/3 repeat signals/);
  assert.equal(await card(incident.id).locator('.incident-actions').isVisible(),false);
  await inject();
  const next=(await snapshot()).incidents.at(-1);
  assert.notEqual(next.id,incident.id);
  assert.equal(await page.locator('#incident-filter').inputValue(),'active','inject reveals active queue');
  assert.match(await card(next.id).locator('.activity-count').innerText(),/No repeat signals/);
  await page.locator('#incident-filter').selectOption('all');
  assert.equal(await page.locator('.incident:visible').count(),3);
  pass('assignment escaping, repeats/linked counts across steps, resolved/history filters and new-incident count reset');

  for(let i=0;i<30;i++)await step();
  state=await snapshot();
  assert.equal(await page.locator('#timeline li').count(),25);
  assert.equal(await page.locator('#event-count').innerText(),`${state.events.length} total`);
  assert.equal(await page.locator('#older-events').innerText(),`${state.events.length-25} older events not shown · full log retained`);
  assert.deepEqual(await page.locator('#timeline time').evaluateAll(nodes=>nodes.map(n=>n.getAttribute('datetime'))),state.events.slice(-25).reverse().map(e=>e.at));
  const replayState=await snapshot();
  await reset(initial.seed,true);
  await page.locator('#failure-equipment').selectOption('oxygen-scrubber');
  await inject();
  const replayId=(await snapshot()).incidents.at(-1).id;
  await owner(replayId).fill(evil);await card(replayId).locator('form button').click();
  for(let i=0;i<3;i++){await step();await inject();}
  await card(replayId).locator('[data-resolve]').click();await inject();
  for(let i=0;i<30;i++)await step();
  assert.deepEqual(await snapshot(),replayState);
  pass('newest-25 timeline/full older count; same seed plus complete stepped lifecycle replay is identical');

  for(const width of [390,320]) {
   await page.setViewportSize({width,height:844});
   await reset(`Mobile QA ${width}`,true);
   await owner(starter).fill('   ');
   await card(starter).locator('form button').click();
   const rect=await page.locator(`#error-${starter}`).evaluate(n=>({top:n.getBoundingClientRect().top,bottom:n.getBoundingClientRect().bottom,height:innerHeight}));
   assert.ok(rect.top>=0&&rect.bottom<=rect.height,`${width}px inline error in viewport`);
   if(width===390)await page.screenshot({path:path.join(evidence,'mobile-inline-error.png'),fullPage:true});
   const widths=await page.evaluate(()=>({client:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth}));
   assert.ok(widths.scroll<=widths.client,`${width}px overflow: ${JSON.stringify(widths)}`);
   await owner(starter).fill(`Mobile ${width}`);await card(starter).locator('form button').click();
   await step();
   await page.screenshot({path:path.join(evidence,`mobile-${width}.png`),fullPage:true});
   await card(starter).locator('[data-resolve]').click();
   assert.equal(await page.locator('.incident:visible').count(),0);
   await page.locator('#failure-equipment').selectOption('oxygen-scrubber');
   await inject();
   const mobileId=(await snapshot()).incidents.at(-1).id;
   await owner(mobileId).fill(`Flight ${width}`);await card(mobileId).locator('form button').click();
   await card(mobileId).locator('[data-resolve]').click();
   assert.equal(await page.locator('.incident:visible').count(),0);
   notes.push({width,errorRect:rect,widths});
  }
  await page.setViewportSize({width:1440,height:1100});
  await page.locator('nav[aria-label="Dashboard sections"] a[href="#telemetry-heading"]').click();
  const heading=await page.locator('#telemetry-heading').boundingBox();
  const deck=await page.locator('.control-deck').boundingBox();
  assert.ok(heading.y>=deck.y+deck.height,'navigation heading not obscured by sticky deck');
  await page.locator('nav[aria-label="Dashboard sections"] a[href="#incidents-heading"]').click();
  assert.equal(await page.locator('#incidents-heading').evaluate(n=>n===document.activeElement),true);
  pass('390/320px layout and inline error visibility; mobile full lifecycle/step; desktop incident/telemetry navigation');

  const calls=await page.evaluate(()=>window.__qaCalls);
  for(const name of ['createSimulation','injectFailure','assignIncident','resolveIncident','advanceTime'])assert.ok(calls.some(c=>c[0]===name));
  assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
  pass('no browser/console errors or HTTP(S) requests; public API observed for every exercised mutation');
  fs.writeFileSync(path.join(evidence,'browser-observations.json'),JSON.stringify({browser:browser.version(),passes,errors,requests,calls,notes,globalFeedback},null,2));
  console.log(`RESULT: ${passes} groups passed; Chromium ${browser.version()}`);
  await context.close();
 } finally {await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
