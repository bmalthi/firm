# Independent QA — single-station refinement

**2026-11-05 · Rowan Ellis · PASS after one CSS defect was fixed and retested.**

Scope: `INTERFACE.md` plus the explicitly accepted `REFINEMENT-CONTRACT.md`. Risks were sent before edits (`QA-REFINEMENT-PLAN.md`); no tests/implementation began until both roles accepted the final contract. QA changed only tests/reports/evidence. Implementation changed production, including the coordinated CSS fix below. No multi-station scope or public testing API was added.

## Final results and exact commands

Copied published app into `/example-home/scratch/station-refinement/app`. Used Node **v24.21.0**, Playwright **1.64.1**, and rootless Docker image `mcr.microsoft.com/playwright:v1.64.1-noble` (Chromium **156.0.8078.80**). Scratch working directory was `station-refinement`.

```sh
node --check app/src/simulation.js
node --check app/src/app.js
node --check app/tests/browser-smoke.cjs
node --check app/tests/browser-real-clock.cjs
node --test app/tests/*.test.cjs
```

Syntax checks exit 0. **28 domain tests passed, 0 failed/skipped**, **1.834 s**: 15 retained baseline tests plus 13 additive refinement tests. Final output: `qa-refinement-evidence/node-tests-final.txt`.

QA-only setup: `npm init -y`, `npm install --save-dev @playwright/test@1.64.1`. The tagged Docker image was retained from v1; app remains dependency-free. Native host browser libraries were not installed.

```sh
docker run --rm --network none -v "$PWD:/qa" -w /qa \
  mcr.microsoft.com/playwright:v1.64.1-noble node app/tests/browser-smoke.cjs

docker run --rm --network none -v "$PWD:/qa" -w /qa \
  mcr.microsoft.com/playwright:v1.64.1-noble node app/tests/browser-real-clock.cjs
```

**9/9 grouped browser smoke checks passed**, exit 0. Separately, **1/1 uninstrumented real-clock browser check passed**, exit 0. Both use a cold direct `file://` page with browser offline and container network disabled. **Zero HTTP(S) requests, page errors, or console errors in the full suite.** Output: `browser-tests-final.txt`, `real-clock-check.txt`; details: `browser-observations.json` in `qa-refinement-evidence/`.

Final production hashes were compared with the currently published files; `diff -u` exited 0. Recorded in `qa-refinement-evidence/production-sha256.txt` and `shared-production-sha256.txt`. Patched CSS hash: `d2a78ee8a935c004994ce98aff7a172899655b2724d94656468a1acd77438bda`.

## What was verified

### Domain

- Original creation, assignment, invalid ownership/IDs, resolution, repeated injection, post-resolution reinjection, seeded replay, browser/CommonJS exports, instance isolation and defensive-copy regressions remain passing.
- `advanceTime()` defaults to one; integer 1–60 batches add exactly one `simulation.minute` event per minute. Batch/single-step snapshots match for numeric/string seeds. Invalid inputs reject without visible mutation or consuming future PRNG state.
- Ordered interleaved step/lifecycle replay is deterministic, including after a wall-clock delay. Only advancement changes `simulationMinute`; all events retain separate +1-minute logical UTC timestamps.
- Drift does not create or mutate incidents. Sensor values are rounded to tenths and stay inside their declared scale. Metadata matches all declared bands/cutoffs.
- Fault severity takes precedence over numeric status across steps. Resolution restores the current drifting baseline rather than rewinding to initial readings.
- Owners/creation times survive repeated failures across steps; full lifetime repeat history remains in domain even beyond 25 events; new incidents start with no repeats.

**Observed numeric boundaries:** eight seeds × 1,200 explicit minutes = **9,600 samples per sensor**, without faults. All three statuses occurred for every sensor. All **14 unique per-sensor normal/critical cutoffs** were actually reached, as were their neighboring tenths where inside scale. Status matched strict critical comparisons and inclusive normal ranges on every sample. Exact-hit counts:

| Sensor | Cutoff: hit count |
|---|---|
| Oxygen | 17.5: 85; 19.5: 111; 21.5: 78; 23.5: 76 |
| Core temperature | 10: 43; 18: 15; 26: 20; 32: 26 |
| Power | 40: 7; 70: 7; 100: 227 |
| Downlink | 35: 4; 75: 8; 100: 307 |

Full status/neighbor counts are in Node diagnostics. Strict/inclusive classifier comparisons and round-before-classify order were independently inspected in the domain source. No public setter/helper was needed. These are finite natural trajectories, not exhaustive verification of every possible seed/value.

### Actual offline UI

- Default paused state remains unchanged through virtual time. Response queue precedes telemetry in DOM; compact initial desktop view puts incident controls before sensor cards.
- Step changes visible telemetry; Run uses a 5-second boundary and one step per callback. Pause holds; repeated toggles do not multiply intervals; a delayed callback does not catch up. A separate real-clock run, without factory wrappers or fake timers, verifies first Run interval, Pause through the next interval, then manual Step.
- Ticks preserve unfinished owner/seed drafts, owner selection/caret, focus and document scroll, inline error text and global feedback. Cancelled reset retains state/drafts/run state; confirmed reset restores the original seed snapshot, clears history/elapsed time and stops the timer.
- Gauges expose meter values/units/endpoints, map fill and healthy band to declared scale, label healthy/critical ranges, and retain textual status. Healthy-band color remains translucent green on nominal, warning and critical cards after the patch.
- Assignment persists and HTML-like owner text remains inert. Repeats across steps do not duplicate incidents or lose owner/creation time; linked/repeat counts remain correct. Resolved/current/all filters and reinjection from a history filter behave correctly.
- Timeline shows precisely newest 25 in reverse event order with an exact older-event count; full stepped UI lifecycle replay after same-seed reset produces identical snapshots.
- Whitespace-owner feedback is adjacent, live-announced and in viewport on desktop, **390px and 320px**. Mobile assignment/injection/resolution/Step work; neither width has page-wide horizontal overflow. Desktop section links reveal headings without sticky-deck occlusion and focus the incident heading.
- Screenshots visually inspected: `desktop-initial.png`, `mobile-390.png`, `mobile-320.png`. Inline-error screenshots are also retained.

## Defect found, fixed, and regression-tested

**Healthy gauge band changed color with fault status.** Initial refined CSS inherited `.sensor.warning/.critical .sensor-track span`, which outranked `.sensor-track .healthy-band`. Default temperature's healthy 18–26°C zone became opaque amber (`rgb(255,196,120)`) instead of translucent green; critical cards likewise recolored the healthy zone red. Numeric bounds/position remained correct, but the visual meaning was misleading.

QA reproduced it in computed styles and added a failing regression (`healthy-band-regression-before-fix.txt`). Founder authorized a minimal patch; implementation removed obsolete status selectors while retaining severity coloring for `.gauge-fill`. Fresh-copy retest now passes warning and critical invariance assertions and visually shows the correct healthy band. No interface change.

**Historical v1 feedback issue:** fixed. The old off-screen whitespace rejection is now beside the owner input and stays visible through timer updates and on both mobile widths.

## Remaining limits

No remaining confirmed functional defect in the exercised scope. Chromium only; no Safari/Firefox, physical-device, screen-reader, or full contrast/accessibility audit. Timer-delay behavior uses Playwright virtual time plus a normal real-time interval check, not a real background-tab/laptop suspend exercise. Very long-session performance, exhaustive seeds, and local HTTP launch were not tested. State remains session-only; natural numeric alerts intentionally do not create incidents; simulated event time and elapsed minutes intentionally differ. Full timeline history is retained in memory while only newest 25 entries are visible.
