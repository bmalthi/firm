# Kestrel Station incident dashboard

A fictional, offline-first single-station incident-response simulation. Readings, incidents, ownership, and timestamps are synthetic and session-only; the app uses no network service or external runtime dependency.

## Run

1. Open `index.html` directly in a current browser, or serve this directory locally:
   ```sh
   python3 -m http.server 8000
   ```
   Then open `http://localhost:8000`.
2. The starting seed is `KESTREL-01`. The simulation starts **paused**. Select **Advance 1 minute** for a deterministic step, or **Run** to advance once every five seconds; pause at any time. Telemetry drifts deterministically with steps. Reset confirms before discarding, stops the run, and leaves the new simulation paused.
3. Use **Inject failure** to create an incident. Repeating a failure on equipment with an unresolved incident adds a repeat event and increments its lifetime repeat count, without creating a duplicate or changing its owner. Assign an owner/team and resolve incidents from the response queue.

Same seed + same ordered actions and explicit steps reproduces the same data. Wall-clock duration in Run mode is not a reproducible input. A resolved fault removes the equipment effect and recalculates telemetry from the current drifted baseline (not the initial reading). Natural drift does not create incidents. Gauge cards show scale, healthy band, critical cutoffs, numeric value/unit and textual status. The activity panel shows the newest 25 entries and how many older events remain in the full in-memory history.

`Elapsed N min` advances only when the simulation is stepped. Timeline UTC is a separate synthetic logical clock that advances one minute per recorded event. Data is not persisted after reset or page close.

## Tests

Requires Node.js; no packages are needed:

```sh
node --check src/simulation.js
node --check src/app.js
node --test tests/*.test.cjs tests/refinement.test.cjs
```

The 28 dependency-free contract tests cover initial and refined behavior, including creation, ownership, resolution, repeated failures, deterministic stepping, thresholds/status properties, and state isolation. `tests/UI-CHECKLIST.md` and `tests/browser-smoke.cjs` support browser checks; see `QA-REPORT.md` for v1 evidence and the refinement QA report when available.

## Files

- `index.html`, `styles.css`: offline interface and responsive styling
- `src/simulation.js`: deterministic domain simulation (CommonJS and browser global)
- `src/app.js`: UI and interaction handlers
- `tests/`: contract tests and browser-check assets
