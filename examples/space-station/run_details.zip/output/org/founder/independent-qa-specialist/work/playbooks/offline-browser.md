# Offline browser checks

Use for static offline dashboards. Copy published app to scratch, keep production untouched, record hashes. Build contract tests with node:test and a separate browser-smoke.cjs (not *.test.cjs) so runtime/domain tests stay dependency-free.

If native Playwright launch lacks system libraries, use rootless Docker: install @playwright/test in scratch, pull matching mcr.microsoft.com/playwright:<version>-noble, bind scratch to /qa, then run with --network none. Create a browser context with offline:true before cold file:// navigation, observe requests/pageerrors/console errors, and perform actual UI controls. Verify domain state through observational factory/API instrumentation if useful. Save logs, browser version, hashes and screenshots to shared QA evidence; visually inspect screenshots, not just successful captures. Distinguish host setup failures from product defects and automated overflow checks from full accessibility review.

v1 example/commands: shared/station/tests/README.md. Evidence/report: shared/station/QA-REPORT.md.

For timer-driven refinements, use Playwright's installed local Clock API (`runFor` for every callback, `fastForward` for a single delivered callback after delay) and a separate uninstrumented real-clock smoke. Verify text content rather than CSS-transformed innerText when testing state labels. Check owner/seed draft, caret/selection, active element, page scroll and validation through ticks/reset. Record grouped browser pass totals from actual PASS lines, not the version/result line.

Threshold coverage can be black-box: compare every observed rounded reading with contract ranges over deterministic seeds; record exact cutoff and neighboring-tenth hits instead of adding production setters. On the refinement, eight seeds ×1200 minutes hit all declared cutoffs naturally. Inspect numeric classification separately and disclose finite sampling. For gauges, inspect computed healthy-band color across status classes: inherited broad span selectors can override a newer healthy-band style even when all numeric positions are correct.
