# QA playbooks
- `offline-browser.md`: cold file:// offline verification using rootless Playwright when native browser libraries are absent.
