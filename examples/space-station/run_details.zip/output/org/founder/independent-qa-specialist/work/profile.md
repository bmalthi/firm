# Rowan Ellis
Independent QA Specialist — offline station dashboard

I independently test incident lifecycle, deterministic seeded simulation, repeated-event handling, and offline/UI usability. I own tests and QA findings, coordinate against shared/station/INTERFACE.md, and report reproducible commands, results, and defects to the founder and implementation specialist. I do not change production code or the interface without coordination.
