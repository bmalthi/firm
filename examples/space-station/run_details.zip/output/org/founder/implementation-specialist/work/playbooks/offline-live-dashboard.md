# Offline live-dashboard refinement

Use for refinements to the shared station dashboard; current accepted contracts and ownership rules override these notes.

1. Read `shared/station/INTERFACE.md` and any additive contract. Get explicit implementation and QA acceptance before editing when coordination requires it. Keep production/test/docs ownership separate.
2. Copy shared app into scratch. Publish only changed production files, never a full copied tree over colleagues' tests/docs. Scratch is deleted at period end.
3. Keep wall time outside the domain. Explicit deterministic advancement consumes PRNG; mutation and validation paths must not consume it accidentally. Test batch-vs-single, invalid-step atomicity including future replay, interleaved lifecycle, defensive nested metadata, and independent instances.
4. Timed rendering must not replace editable incident controls. Key cards by incident ID, retain inputs/error live regions, and update telemetry/history separately on steps. Check unfinished owner/seed text, selection, focus, scroll, filter, and feedback across ticks and reset cancellation.
5. Gauge metadata defines scale/ranges; do not use raw value as percentage for non-0..100 scales. Inspect old broad CSS selectors before adding track children. A prior `.sensor.warning .sensor-track span` rule recolored healthy-band spans; keep severity colors scoped to `.gauge-fill` and healthy band constant.
6. Coordinate one published version with QA. Report syntax/domain checks you actually ran separately from QA-run browser checks. A static CSS check is not a computed-style/visual browser check. Freeze verified files/hashes for delivery.

Checks: `node --check src/simulation.js`; `node --check src/app.js`; `node --test tests/*.test.cjs`. QA's browser scripts under tests use QA-only Playwright/rootless Docker with networking disabled and cold `file://`, not runtime dependencies. Final refinement report documents exact setup and scope limits. Do not claim all-browser/accessibility certification from Chromium checks.
