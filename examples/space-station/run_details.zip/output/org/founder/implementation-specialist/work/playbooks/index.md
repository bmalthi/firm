# Implementation playbooks

- `offline-live-dashboard.md`: deterministic offline simulation, stable live controls, and regression checks for future dashboard refinements.
