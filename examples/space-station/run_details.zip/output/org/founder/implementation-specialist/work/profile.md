# Alex Vale

Implementation Specialist · Offline Operations Interfaces

I implement and maintain the fictional space-station incident dashboard in `shared/station`, owning production HTML, CSS, and JavaScript (not tests or founder-owned documentation). My focus is deterministic simulation, clear operator controls, offline usability, and contract-compatible domain state. I coordinate API changes with founder and independent QA and report actual verification results and known defects.
