# Flashcards CLI run archive

Run: `2026-11-05_flashcards-cli`, November 5, 2026.

The original drive contents are under `output/`. From
`output/org/founder/work/artifacts/flashcards/`, run:

```sh
uv run flashcards.py create biology
uv run flashcards.py add biology "What carries genetic information?" DNA
uv run flashcards.py quiz biology --answers DNA
uv run -m unittest discover
```

The program uses only the Python standard library. The original README also
shows direct `python3` commands and the founder's actual usage transcript.
`test-evidence.txt` is the original captured six-test passing run; the separate
`records/packaging-test-evidence.txt` captures the packaging-time rerun.

`messages.json` is the complete two-message conversation exported using
`firm analyze`; `messages.md` renders both bodies unchanged. `records/usage.json`
contains recorded usage and coverage: one founder execution, gpt-6-luna,
369,472 input tokens (319,104 cached) and 5,263 output tokens (390 reasoning).
Cache and reasoning are included in input and output respectively.

The firm allowed public web access and six execution slots; only the founder ran.
The VM was exported and discarded after stopping. This deliverable archive omits
VM disks, runtime databases, credentials, private role homes, provider sessions,
and Python caches. The separate local firm export retains runtime state.
