import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

import flashcards


class FlashcardsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.directory = self.tmp.name
        flashcards.main(["--directory", self.directory, "create", "demo"])
        flashcards.main(["--directory", self.directory, "add", "demo", "Capital of France?", "Paris"])
        flashcards.main(["--directory", self.directory, "add", "demo", "2 + 2?", "4"])

    def tearDown(self):
        self.tmp.cleanup()

    def run_cli(self, *args):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = flashcards.main(["--directory", self.directory, *args])
        return code, output.getvalue()

    def deck(self):
        return json.loads((Path(self.directory) / "demo.json").read_text())

    def test_create_and_add_json(self):
        deck = self.deck()
        self.assertEqual(deck["name"], "demo")
        self.assertEqual([c["id"] for c in deck["cards"]], [1, 2])
        self.assertEqual(deck["cards"][0]["correct"], 0)

    def test_scripted_quiz_tracks_success_and_misses(self):
        code, output = self.run_cli("quiz", "demo", "--answers", "Paris", "wrong")
        self.assertEqual(code, 0)
        self.assertIn("Score: 1/2", output)
        cards = self.deck()["cards"]
        self.assertEqual((cards[0]["correct"], cards[0]["incorrect"]), (1, 0))
        self.assertEqual((cards[1]["correct"], cards[1]["incorrect"]), (0, 1))

    def test_most_missed_card_is_asked_first_next_session(self):
        self.run_cli("quiz", "demo", "--answers", "Paris", "wrong")
        _, output = self.run_cli("quiz", "demo", "--limit", "1", "--answers", "4")
        self.assertIn("Q1: 2 + 2?", output)
        cards = self.deck()["cards"]
        self.assertEqual(cards[1]["correct"], 1)

    def test_interactive_stdin_quiz(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(io.StringIO()), contextlib.ExitStack() as stack:
            import unittest.mock
            stack.enter_context(unittest.mock.patch("builtins.input", side_effect=["Paris", "4"]))
            code = flashcards.main(["--directory", self.directory, "quiz", "demo"])
        self.assertEqual(code, 0)
        self.assertIn("Score: 2/2", output.getvalue())

    def test_missing_script_answer_is_clean_error(self):
        code, _ = self.run_cli("quiz", "demo", "--answers", "Paris")
        self.assertEqual(code, 2)

    def test_invalid_deck_name(self):
        code = flashcards.main(["--directory", self.directory, "create", "../escape"])
        self.assertEqual(code, 2)


if __name__ == "__main__":
    unittest.main()
