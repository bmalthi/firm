"""A small, dependency-free command-line flashcard study tool."""
import argparse
import json
import re
import sys
from pathlib import Path


class DeckError(Exception):
    """Invalid or unavailable deck operation."""


def deck_path(directory, name):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", name):
        raise DeckError("Deck name must be 1-64 letters, digits, underscores, or hyphens, and start with a letter or digit.")
    return Path(directory) / (name + ".json")


def load_deck(directory, name):
    path = deck_path(directory, name)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise DeckError(f"Deck '{name}' does not exist. Create it with 'create'.") from None
    except (json.JSONDecodeError, OSError) as exc:
        raise DeckError(f"Cannot read deck '{name}': {exc}") from None
    if not isinstance(data, dict) or data.get("name") != name or not isinstance(data.get("cards"), list):
        raise DeckError(f"Deck '{name}' has an invalid format.")
    return path, data


def save_deck(path, deck):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(deck, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def cmd_create(args):
    path = deck_path(args.directory, args.name)
    if path.exists() and not args.force:
        raise DeckError(f"Deck '{args.name}' already exists (use --force to replace it).")
    save_deck(path, {"name": args.name, "cards": []})
    print(f"Created deck '{args.name}'.")


def cmd_add(args):
    path, deck = load_deck(args.directory, args.name)
    if not args.question.strip() or not args.answer.strip():
        raise DeckError("Question and answer must not be empty.")
    card_id = max((c.get("id", 0) for c in deck["cards"]), default=0) + 1
    deck["cards"].append({"id": card_id, "question": args.question, "answer": args.answer,
                          "correct": 0, "incorrect": 0})
    save_deck(path, deck)
    print(f"Added card {card_id} to '{args.name}'.")


def priority(card):
    attempts = card["correct"] + card["incorrect"]
    return (0, -(card["incorrect"] / attempts), card["id"]) if attempts else (1, 0, card["id"])


def cmd_quiz(args):
    path, deck = load_deck(args.directory, args.name)
    cards = sorted(deck["cards"], key=priority)
    if args.limit is not None:
        cards = cards[:args.limit]
    if not cards:
        print("No cards to quiz.")
        return
    answers = iter(args.answers) if args.answers is not None else None
    correct_count = 0
    for index, card in enumerate(cards, 1):
        print(f"Q{index}: {card['question']}")
        try:
            response = next(answers) if answers is not None else input("Your answer: ")
        except StopIteration:
            raise DeckError("Not enough --answers supplied for this quiz.") from None
        except EOFError:
            raise DeckError("Input ended before the quiz was complete.") from None
        is_correct = response.strip().casefold() == card["answer"].strip().casefold()
        if is_correct:
            card["correct"] += 1
            correct_count += 1
            print("Correct!")
        else:
            card["incorrect"] += 1
            print(f"Incorrect. Answer: {card['answer']}")
    save_deck(path, deck)
    print(f"Score: {correct_count}/{len(cards)}")


def cmd_list(args):
    _, deck = load_deck(args.directory, args.name)
    print(f"Deck '{args.name}': {len(deck['cards'])} card(s)")
    for card in deck["cards"]:
        attempts = card["correct"] + card["incorrect"]
        rate = f"{card['correct'] / attempts:.0%}" if attempts else "not yet tested"
        print(f"{card['id']}. {card['question']} — success: {rate} ({attempts} attempt(s))")


def parser():
    result = argparse.ArgumentParser(description="Create, manage, and study JSON flashcard decks.")
    result.add_argument("--directory", default="decks", help="directory containing deck JSON files (default: decks)")
    commands = result.add_subparsers(dest="command", required=True)
    create = commands.add_parser("create", help="create a named deck")
    create.add_argument("name"); create.add_argument("--force", action="store_true", help="replace an existing deck")
    create.set_defaults(func=cmd_create)
    add = commands.add_parser("add", help="add a question/answer card")
    add.add_argument("name"); add.add_argument("question"); add.add_argument("answer"); add.set_defaults(func=cmd_add)
    quiz = commands.add_parser("quiz", help="quiz a deck; --answers enables scripted mode")
    quiz.add_argument("name"); quiz.add_argument("--answers", nargs="*", help="answers in quiz order; no stdin prompts")
    quiz.add_argument("--limit", type=int, help="maximum cards this session")
    quiz.set_defaults(func=cmd_quiz)
    listing = commands.add_parser("list", help="show cards and success rates")
    listing.add_argument("name"); listing.set_defaults(func=cmd_list)
    return result


def main(argv=None):
    args = parser().parse_args(argv)
    if getattr(args, "limit", 1) is not None and getattr(args, "limit", 1) < 1:
        parser().error("--limit must be at least 1")
    try:
        args.func(args)
    except DeckError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
