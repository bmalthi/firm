# Flashcards CLI

A dependency-free Python 3 command-line tool for building named JSON decks, studying interactively or with scripted answers, and tracking card success across sessions. Cards are ranked by miss rate (incorrect / attempts), highest first; untested cards follow tested cards, with card ID providing a stable tie-breaker.

## Requirements

Python 3 and its standard library only. No installation is needed.

## Usage

From this directory, the default deck directory is `decks/`:

```sh
python3 flashcards.py create biology
python3 flashcards.py add biology "What is the powerhouse of the cell?" Mitochondrion
python3 flashcards.py quiz biology
python3 flashcards.py list biology
```

Quiz mode asks questions and reads each answer from stdin. Comparison ignores case and leading/trailing whitespace. For automation, provide answers in quiz order with `--answers`; this mode never prompts. `--limit N` quizzes at most N cards.

`--directory DIR` selects a storage directory. Below is a real run using a temporary directory (shown as `DECKS` in the command transcript); outputs are from running the commands in order:

```text
$ python3 flashcards.py --directory DECKS create biology
Created deck 'biology'.
$ python3 flashcards.py --directory DECKS add biology "What is the powerhouse of the cell?" Mitochondrion
Added card 1 to 'biology'.
$ python3 flashcards.py --directory DECKS add biology "What molecule carries genetic information?" DNA
Added card 2 to 'biology'.
$ python3 flashcards.py --directory DECKS quiz biology --answers wrong DNA
Q1: What is the powerhouse of the cell?
Incorrect. Answer: Mitochondrion
Q2: What molecule carries genetic information?
Correct!
Score: 1/2
$ python3 flashcards.py --directory DECKS quiz biology --limit 1 --answers Mitochondrion
Q1: What is the powerhouse of the cell?
Correct!
Score: 1/1
$ python3 flashcards.py --directory DECKS list biology
Deck 'biology': 2 card(s)
1. What is the powerhouse of the cell? — success: 50% (2 attempt(s))
2. What molecule carries genetic information? — success: 100% (1 attempt(s))
```

The first quiz's miss makes that card appear first in the next quiz. Deck JSON files contain the deck name and cards, including each card's integer `correct` and `incorrect` totals; this persists performance across runs. Deck names accept 1–64 letters, digits, underscores, or hyphens and must begin with a letter or digit. Existing decks are not overwritten unless `create NAME --force` is explicit.

## Tests

Run the full unittest suite from this directory:

```sh
python3 -m unittest discover
```

`test-evidence.txt` contains the captured verbose output of the passing suite.
