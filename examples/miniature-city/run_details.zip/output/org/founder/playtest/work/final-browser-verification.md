# Final independent QA — Little City

**Result: PASS in exercised scope; no blocking functional defects found.** Implementation files were not changed.

**App:** `shared/city/index.html`, 18,215 bytes; SHA256 `4cba1b1569557a788ea86a6537c034d52cacb034a88f04ed9cc501c8a2480a51`.

## Actual browser checks

Used real headless **Chromium136.0.7103.25**, Playwright1.52.0/build1169, in rootless Docker **Ubuntu24.04.5 LTS aarch64**. Loaded the self-contained app from a read-only file mount.

- Desktop1440×1000 and375×812 responsive/mobile-touch emulation: build all four types, clear occupied tiles, Clear/Reset, all three presets, Step/Pause/Play and speed choices pass.
- Real Slow/Normal/Fast timers each advance treasury, then remain stopped after Pause. Step changes treasury by displayed monthly net. Exact wall-clock timing/jitter was not asserted.
- Enter builds/clears a keyboard-focused tile; focused map position survives a running simulation tick.
- Eight browser commute scenarios pass: no-road isolation; adding/removing home-side dead-end road; workplace-side dead-end; one home touching two job networks; one workplace touching two home networks; isolated extra household; separate mismatched networks; capacity splitting. Expected employed counts:0,8,8,8,10,8,18,16.
- CSS commuter-marker transform actually changes while Running and stays fixed while Paused. Emulated reduced-motion sets animation:none.
- No page JavaScript errors or HTTP(S) requests on monitored desktop and touch pages.
- Screenshots inspected at320,375,768,1024 and1440px widths. Body width equals viewport in each; narrow maps scroll inside their map container rather than expanding the page. Controls remain readable. At320px the footer legend/instruction is cramped but usable.

## Additional deterministic simulation checks

Latest build also passes11 targeted DOM commute regressions,30 seeded random maps against an independent per-resident/job matching oracle, budget/park-income arithmetic, focus/state wiring and core controls. No JS errors.

Preset residents / employed / monthly net: Meadowview24/0/−$1; Harbor32/16/+$26; Hilltop32/10/+$22.

## Remaining limitations

- Commute visuals are per-road pulses, **not individual agents traveling along full routes**. Congestion is aggregate, not route-specific bottleneck modeling.
- Default Meadowview starts disconnected with zero employed. Placement is free, parks have global effects and negative balances are allowed.
- Chromium only; mobile is emulation, not physical-device/Safari/Firefox testing. No full screen-reader audit or precise timer-performance measurement.

## Setup workaround and evidence

The official `mcr.microsoft.com/playwright:v1.52.0-noble` manifest was reachable, but layer downloads were blocked at `westus.data.mcr.microsoft.com` (access request q6 pending when tested). **Tests did not use that official image.** Instead, the already-pulled `ubuntu:24.04` image installed browser dependencies using Playwright1.52's `install-deps chromium`; cached Chromium136 was mounted read-only. Local image tag: `city-qa:pw152-noble`. Ubuntu base digest: `sha256:fe81560990fae86dc4743202b2cb4d3df98d0bcf949173cecef15ce1127ef852`.

Raw results and screenshots: `browser-artifacts/`. Repeatable test sources/dependency lockfile: `tests/browser.cjs`, `tests/responsive.cjs`, `tests/current-dom.cjs`, `tests/random-oracle.cjs`, `tests/visuals-state.cjs`. Tested fixture: `tests/tested-4cba1b15.html`.
