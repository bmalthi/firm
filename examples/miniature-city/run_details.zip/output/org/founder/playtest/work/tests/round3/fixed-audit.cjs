'use strict';
const fs=require('fs'),assert=require('assert'),crypto=require('crypto');
const {JSDOM}=require('/example-home/scratch/node_modules/jsdom');
const path=require('path'),root=path.resolve(__dirname,'../..'),file=path.join(__dirname,'round3-fixed-78cdca75.html');
const original=fs.readFileSync(file,'utf8'),sha=crypto.createHash('sha256').update(original).digest('hex');
assert.equal(sha,'78cdca75bf6dd2f7a6ffaaf996429fbb711c7e180da4e7d6818da69472093ee7');
let lines=['FIXED AUDIT '+sha,'Actual jsdom DOM clicks; timers disabled. In-memory read-only stats getter added, no implementation file changes. Coordinates zero-based. Money includes construction/salvage.'];
const log=(s)=>{lines.push(s);console.log(s)};
const dom=new JSDOM(original.replace('function step(){','window.__stats=stats;function step(){'),{runScripts:'dangerously',beforeParse(w){w.setInterval=()=>1;w.clearInterval=()=>{}}});
const w=dom.window,d=w.document,q=s=>d.querySelector(s),click=s=>q(s).click(),cell=(x,y)=>q('#grid').children[y*12+x].click();
function place(t,cs){click(`[data-tool=${t}]`);for(const [x,y]of cs)cell(x,y)}
function fresh(city='meadow',empty=false){click(`[data-city=${city}]`);if(empty)click('#clear')}
function snapshot(){const s=w.__stats();return {month:+q('#month').textContent,res:s.res,employed:s.employed,jobs:s.jobs,happy:s.happiness,traffic:s.congestion,active:s.commutingRoads.size,net:s.net,cash:q('#cash').textContent,homes:s.homeIds.map((id,j)=>({xy:[id%12,Math.floor(id/12)],n:s.homeCaps[j],e:s.homeEmployed[j],happy:s.homeLocalHappiness[j],access:s.homeJobAccess[j],open:s.homeOpenJobs[j]}))}}
function step(n){let externalIn=0,externalOut=0,local=0;for(let k=0;k<n;k++){const a=w.__stats();click('#step');const b=w.__stats();assert.equal(b.homeEmployed.reduce((a,b)=>a+b,0),b.employed);assert(b.employed<=b.jobs&&b.employed<=b.res);b.homeCaps.forEach((v,j)=>{assert(v>=0&&v<=8);assert(b.homeEmployed[j]<=v);if(v>(a.homeCaps[j]||0))assert(a.homeJobAccess[j])});const diff=b.res-a.res;if(diff>0)externalIn+=diff;if(diff<0)externalOut-=diff;if(diff===0&&b.homeCaps.some((v,j)=>v!==a.homeCaps[j])){assert.equal(b.homeCaps.reduce((s,v,j)=>s+Math.abs(v-a.homeCaps[j]),0),2);local++}}return {externalIn,externalOut,local}}
function run(name,city,actions){fresh(city);for(const [t,cs] of actions)place(t,cs);log(name+' actions '+JSON.stringify(actions));log('start '+JSON.stringify(snapshot()));const a=step(24);log('24 '+JSON.stringify({stats:snapshot(),migration:a}));const b=step(76);log('100 '+JSON.stringify({stats:snapshot(),migrationSince24:b}));}
const mr=[[5,2],[3,3],[2,1],[3,1],[4,1]],hr=[[1,1],[2,1],[3,1],[1,4],[2,4],[3,4]],ir=[[2,0],[3,0],[4,0],[2,3],[3,3],[8,5]];
run('Meadow requested','meadow',[['road',[[5,2]]],['road',mr],['park',[[1,2]]]]);
run('Meadow reduction omit lower-home road3,3','meadow',[['road',[[5,2]]],['road',mr.filter(([x,y])=>x!==3||y!==3)],['park',[[1,2]]]]);
run('Harbor requested','harbor',[['road',hr],['park',[[0,2],[2,4]]]]);
run('Harbor single cover2,1 roads via y0 (not full cover)','harbor',[['road',[[1,1],[1,0],[2,0],[3,0],[3,1],[1,4],[2,4],[3,4]]],['park',[[2,1]]]]);
run('Hill requested','hill',[['road',ir],['park',[[2,3]]]]);
run('Hill salvage remote parks','hill',[['road',ir],['park',[[2,3]]],['road',[[5,1],[5,2],[6,2]]]]);
// Explicit replacement requires two clicks; park-on-road alone only bulldozes.
run('Harbor intended park replacement plus bottom bypass','harbor',[['road',hr],['park',[[0,2],[2,4],[2,4]]],['road',[[1,5],[2,5],[3,5]]]]);
run('Harbor cheaper nonconflicting full cover','harbor',[['road',hr],['park',[[0,2],[2,5]]]]);
run('Hill intended park replacement plus left access','hill',[['road',ir],['park',[[2,3],[2,3]]],['road',[[1,0],[1,1],[1,2]]]]);
run('Hill cheaper preserve lower road park1,2','hill',[['road',ir],['park',[[1,2]]]]);
run('Meadow salvage remote park5,3','meadow',[['road',[[5,2]]],['road',mr],['park',[[1,2]]],['road',[[5,3]]]]);
run('Harbor full cover salvage remote parks unlock third work','harbor',[['road',hr],['park',[[0,2],[2,5]]],['road',[[5,5],[6,5],[9,3],[9,4],[8,4],[7,4]]]]);
run('Hill safe salvage park6,2','hill',[['road',ir],['park',[[1,2]]],['road',[[6,2]]]]);
fresh('meadow',true);place('home',[[0,0]]);step(12);log('Empty isolated home '+JSON.stringify(snapshot()));place('road',[[1,0]]);place('work',[[2,0]]);place('park',[[0,1]]);step(12);log('Empty repaired home +12 '+JSON.stringify(snapshot()));assert(w.__stats().res>0);
fresh('meadow',true);place('home',[[0,0],[0,2],[0,4],[11,9]]);place('road',[[1,0],[1,1],[1,2],[1,3],[1,4]]);place('work',[[2,0],[2,2],[2,4]]);place('park',[[0,1],[0,3]]);log('Migration start '+JSON.stringify(snapshot()));log('Migration24 '+JSON.stringify({migration:step(24),stats:snapshot()}));
fresh('meadow',true);place('home',[[0,0]]);place('road',[[1,0]]);place('work',[[2,0]]);place('park',[[0,1]]);const base=snapshot();place('road',[[1,1],[1,2],[1,3]]);const branch=snapshot();place('work',[[2,3]]);const extra=snapshot();place('park',[[0,2],[11,9]]);log('Branch / spare work / redundant parks '+JSON.stringify({base,branch,extra,parks:snapshot()}));assert.equal(base.traffic,branch.traffic);assert.equal(base.active,branch.active);assert.equal(base.traffic,extra.traffic);assert.equal(extra.happy,snapshot().happy);
// Equal-access job shortage: deterministic source/home scan order gives later homes the leftovers.
fresh('meadow',true);place('home',[[0,0],[0,2],[0,4]]);place('road',[[1,0],[1,1],[1,2],[1,3],[1,4]]);place('work',[[2,2]]);place('park',[[0,1],[0,3]]);log('Order bias start '+JSON.stringify(snapshot()));log('Order bias24 '+JSON.stringify({migration:step(24),stats:snapshot()}));log('Order bias100 '+JSON.stringify({migrationSince24:step(76),stats:snapshot()}));
log('Code review: max flow conserves component supply/demand; traffic pairs shortest paths sorted by length, greedily allocating positive flow, not global min-cost assignment. Equal ties inherit row-major home/work order and neighbor BFS order. homeOpenJobs checks direct residual workplace capacity, not augmenting-path capacity. Both are potential order effects; no global optimality claim.');
log('SUMMARY: Literal requested Harbor/Hill park clicks hit existing roads: one click clears, does not replace. Intended replacement requires second click and disconnects a home unless bypassed. Harbor park2,5 and Hill park1,2 avoid collision. All successful nonconflicting repairs connect every home. Harbor 30 nominal jobs initially include an inaccessible workplace at9,2; only20 are reachable.');
log('VERIFIED residual issue: row-major job allocation starves later homes: three equally connected six-person homes / one workplace receive6,4,0 jobs. Third home empties by24 despite positive $11/month; population18->12 and stays12 through100. This is unfair allocation, not population nonconservation. No disconnected arrivals, duplicated local migration, road-branch traffic dilution, redundant-park bonus, or permanently empty repaired home reproduced.');
log('All assertions passed.');dom.window.close();fs.writeFileSync(path.join(root,'round3-artifacts/fixed-audit.txt'),lines.join('\n')+'\n');
