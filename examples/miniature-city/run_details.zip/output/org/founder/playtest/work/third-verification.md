# Third-build retest

Build SHA256 `505eefd5541a8ee68c3497c31cdf558534cbae7cd12a762f232f32c05dd9d62d` (16,011 bytes).

**High: duplicate households across disconnected road components.** Clear; home(1,1); roads(0,1),(2,1); workplaces(0,0),(2,0), zero-based. Actual: 8 residents but16 employed and +$17/month. One home is counted once per bordering component. The same approach also permits duplicate workplace capacities when one workplace borders multiple components.

Reproduced with `tests/third-dom.cjs` in jsdom. No browser verification; implementation untouched.
