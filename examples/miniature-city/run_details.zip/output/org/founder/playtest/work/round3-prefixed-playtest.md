# Round 3 independent playtest — PRE-FIX

**Candidate:** `shared/city/index.html`, SHA256 `33124800651c73981b717fc6b9b9109b2dbbb8dbe19f6e154cbef3171e12b090`. No implementation edits. Results below do **not** certify the founder’s forthcoming fix.

**Verdict:** polished, functional browser sandbox; simulation trust/growth blockers remain. Short repair → fill homes → accumulate money is pleasant but shallow. Cosmetic milestones do not yet create a compelling ongoing planning loop.

## Reproduced findings

Coordinates are **0-based (x,y)**. Start each reproduction by selecting Meadowview → Clear, unless specified.

1. **High — serviced empty homes cannot recover.** Build home(0,0); Step12 empties it. Add road(1,0), work(2,0), park(0,1); Step12 more: **0 residents, 90 happiness, jobs available, $416**. The global employment/resident gate is zero, so arrivals never start. Demolish/rebuild costs $25 net, instantly restores6 residents, and reaches8 after4 months. Reset also works. Confirmed DOM and Chromium.
2. **High — citywide migration contradicts neighborhood-local promise.** Homes(0,0),(0,2),(0,4),(11,9); roads(1,0..4); works(2,0),(2,2),(2,4); parks(0,1),(0,3). Initially24 residents/18 employed/happiness68. Step8: **isolated home(11,9) grows6→7**, with no park, road or job access. Confirmed DOM and Chromium. Preset repair trajectories below also fill disconnected housing.
3. **Medium — unused workplaces manufacture traffic capacity.** Home(0,0), road(1,0), work(2,0):6 employed, traffic26%,1 active tile. Add road branch(1,1..3): unchanged traffic26% (good). Add unneeded work(2,3): **same6 employed, traffic7%,4 active tiles**, happiness58→64, net+$8→+$5. Code unions shortest routes to *all* reachable workplaces from an employed home, not actual assigned workplace flows. This is not free economically, but the traffic explanation is misleading. Confirmed DOM and Chromium.
4. **Medium — isolated road counts as a “connected home” happiness benefit.** Hill: roads(2,3),(3,3),(8,5) produce18 employed/happiness65 and no growth through100 months. Add isolated road(2,0), touching an otherwise unserved home: happiness70, then full32 residents at month16; happiness66 at month100. Road(2,0) does not connect to the job network. DOM UI-confirmed; `served` checks road adjacency rather than a job path. This is distinct from active-route branch padding.
5. **Low/design — placement farms population milestones.** Seven isolated homes at(0..6,0) → Step:42 residents,0 employed,happiness23, Best42/next48. Clear retains Best42. No cash reward, so **not** an infinite-money exploit, but the “thoughtful” growth signal rewards housing spam rather than sustainable community health. DOM-confirmed.

## Cheapest sustainable growth found

Bounded search, **not a proven global minimum**. Retained existing homes/workplaces; no bulk Clear, new housing/jobs, recovery aid, waiting for income, or demolition of homes/jobs. Costs = construction minus salvage; redundant park/road liquidation is explicit. All final paths replayed through actual UI click events under JSDOM for100 months. Positive net and growing population until existing homes fill; thereafter population stable and treasury rises.

| Preset | Net cost (gross − salvage) | Repaired: residents / employed / happy / monthly net | Month24: residents / funds | Month100: residents / funds |
|---|---:|---|---|---|
| Meadow | $13 ($69−$56) | 18 / 12 / 73 / +$14 | 24 / $1,015 | 24 / $2,991 |
| Harbor | $19 ($81−$62) | 24 / 18 / 71 / +$22 | 32 / $1,135 | 32 / $3,263 |
| Hill | $15 ($81−$66) | 24 / 18 / 71 / +$24 | 32 / $1,175 | 32 / $3,455 |

Exact action order:
- **Meadow:** clear park(5,2); road(3,3); clear park(5,3); road(5,3); park(2,1); clear roads(4,2),(6,2).
- **Harbor:** clear parks(5,5),(6,5); roads(1,1),(2,1),(3,1); park(0,2); clear roads(4,2),(5,2),(6,2).
- **Hill:** clear parks(5,1),(5,2),(6,2); roads(2,3),(3,3),(8,5); park(2,0).

Full at months12/16/16; thresholds maintained through100, no grant. Without optional liquidation: Meadow $47 (necessary park removal), Harbor $81, Hill $48; Hill’s cheap alternative uses the isolated-road quirk above. Demolition-free Meadow $93. Search limits and every action/trajectory are in `round3-artifacts/cost-paths.txt`; 182,489 analytical screens +4,928 road-removal screens, **25 DOM-event trajectories ×100 months**. Search extracts the snapshot’s unchanged stats function; finalists use the complete unchanged HTML.

## Thresholds, tradeoffs and cheap loops

- **Employment gate stalls, did not oscillate:** five homes at(0,0/2/4/6/8), roads(1,0..8), works(2,0),(2,2), parks(0,1),(0,5),(0,9). 30 residents/20 jobs grows to33 by month6, then remains33 through month112: happy74, net+$27, funds$3,116. Ratio20/33 falls below.62 but is above departure threshold.32; no explanation tells the player why vacant homes stop filling.
- Happiness65 Hill control stays24 residents through100 months; happiness66 alternative sustains32 at capacity. No tested threshold oscillation; this is stagnation, not instability.
- Parks affect nearby coverage once: overlapping/remote extras do not stack happiness and do add upkeep. Yet one optimally placed park replaces several preset parks cheaply; useful short optimization, limited continuing decision depth.
- Full-home demolition/rebuild costs$25 and reduces8→6; not profitable. Depleted-home rebuild resets occupants to6: a recovery workaround, not natural migration.
- Clear twice gives no second salvage. Recovery aid happens once; subsequent debt can become deeply negative. No infinite cash loop found in these checks.
- No-action24 months: Meadow18→6 residents, treasury−$52/net−$23; Harbor24 residents/$572/net+$3; Hill24 residents/$524/net+$1. Harbor/Hill do not develop by themselves.

## Browser and player evidence

**Actually executed:** Chromium136.0.7103.25, Playwright1.52, real headless Linux browser; desktop1440×1000 and emulated touch375×812. Preset switching, paused start, build/occupied-tile clearing/salvage, Step, all3 real timer speeds, Pause, Clear/Reset, keyboard Enter and focus across re-render, commuter animation run/pause/reduced-motion, far-right mobile touch construction, connected employment and step all passed. No page errors or external HTTP requests. Not a physical handset test or comprehensive accessibility audit.

**Layout:** mobile body width375 (no body overflow), map scroll512/client321. Horizontal map scrolling works. Desktop simulation controls are below the initial1000px viewport; on mobile metrics/tools/controls are well below the map. Repeated tool→map→metrics scrolling interrupts experimentation. Notes explaining outcomes are even farther down; no selected-home diagnosis.

**Timed specialist session, not a naïve-user study:** I drove a scripted exploratory browser sequence and inspected actual output/screenshots. At10s a road-tool click on the blocking park only demolished it; second click built the bridge. Two repaired road tiles:12 employed, happy49, net+$12. At22s nearby park:happy73/net+$11, start Fast. At40s/month39 all3 homes were full24, only16 employed, $1,254/net+$23—including the unconnected home. At48s connecting that last household raised employment20/net+$32. **Founder requested a pause during the run; I stopped it after the48s checkpoint. A full120-second session was not completed on this hash.** Saved script contains unexecuted later phases; do not treat those as results.

**Why I would stop around two minutes (assessment, not measured retention):** repairing the road/park puzzle is satisfying and visual feedback is clear. Once housing fills, money rises with no new pressure; the next move is repeat homes/jobs/park rather than solve a new city problem. Milestones are easy to buy and generic. Hidden migration conditions and misleading local/traffic feedback make a plateau harder to diagnose than interesting to solve. Prefer honest district/household diagnostics and a small repeatable planning challenge over additional reward widgets.

## Evidence and scope

- Tests: `tests/round3/{round3-dom,round3-browser,round3-threshold,round3-session,cost-paths}.cjs`; exact `round3-snapshot.html`.
- Raw logs/screenshots: `round3-artifacts/` (desktop, mobile initial/built, isolated growth,40s session).
- Tests stopped on founder’s pre-fix freeze/pause request. No claims here about the forthcoming candidate. Recheck local arrivals/departures, empty-home recovery, assigned-route traffic and the isolated-road shortcut before accepting that revision.
