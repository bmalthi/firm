# Browser test setup used

All setup/builds were in role-local scratch; delivered HTML was read-only. Tests use the `playwright-legacy` npm alias pinned to1.52.0. A current Chromium download was initially blocked on a Google storage redirect; the older fallback download succeeded via approved cdn.playwright.dev.

1. Copy `tests/` into scratch and `npm ci`.
2. Install browser into private cache:
   `PLAYWRIGHT_HOST_PLATFORM_OVERRIDE=ubuntu24.04-arm64 node node_modules/playwright-legacy/cli.js install chromium`
   (Old Ubuntu26.04 detection requires this override; expected Chromium136/build1169.)
3. `docker pull ubuntu:24.04`.
4. Start a named Ubuntu container with `/usr/local/bin/node` mounted read-only and scratch mounted `/work`, working directory `/work`; run `node node_modules/playwright-legacy/cli.js install-deps chromium` as container root. No host sudo was used.
5. Commit that dependency container as `city-qa:pw152-noble`.
6. Run a disposable container from this image with node mounted read-only, scratch as `/work`, cached browsers as `/ms-playwright:ro`, and delivered index.html as `/app/index.html:ro`. Set `PLAYWRIGHT_BROWSERS_PATH=/ms-playwright`, working directory `/work`, and `--ipc=host`.
7. Invoke `node browser.cjs /app/index.html /work/browser-artifacts`, then `node responsive.cjs`.

Actual tested image was a locally prepared Ubuntu image, **not** official Playwright image: the official manifest's layer-host redirect remained blocked. Host-library launch had failed before dependencies were isolated in Docker. No Mac or external service was used.
