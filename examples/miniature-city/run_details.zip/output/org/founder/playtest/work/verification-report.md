# Independent verification — current Little City build

**Status:** simulation and DOM checks pass; real-browser/rendering verification pending Chromium download access.

Tested `shared/city/index.html`, SHA256 `ecf50f8a81c77c1c9f172ca581d86e8859f5b2fcbcfafbdbaddfe6af0b8b7cbc` (17,329 bytes). Implementation was not modified.

## Executed and passing

- 120 map tiles, all four build tools and occupied-tile demolition, Clear, Reset, three presets.
- Pause/Play/Step, all three speed interval configurations, no duplicate interval on repeated Play, and paused speed changes.
- Controlled timer callback advances treasury by the displayed monthly net; Step remains paused.
- Map-cell keyboard focus preserved across re-render (jsdom focus only).
- Eleven deterministic commute scenarios: no-road isolation; valid connection; isolated extra home; one home touching two job networks; shared workplace capacity; home/workplace dead-end roads; separate mismatched networks; diagonal separation; broken road; and capacity split between networks.
- Thirty seeded mixed random layouts compared against an independent per-resident/per-job matching oracle, using BFS for road reachability. All employment counts match; happiness and traffic remain within bounds.
- No JavaScript errors in the harness. Source inspection finds no external assets or service calls.

## Observed preset values

| Preset | Residents | Employed / jobs | Happy | Traffic | Monthly net |
|---|---:|---:|---:|---:|---:|
| Meadowview |24|0 /20|34%|35%|-$25|
| Harbor |32|16 /30|56%|6%|-$6|
| Hilltop |32|10 /20|58%|5%|-$10|

## Remaining findings and limitations

- **Core requirement gap:** no visible moving residents/commuters exist. The current delivered file shows static glyphs and numeric commute/employment statistics only. No path/vehicle animation is implemented.
- Congestion is an aggregate employed-residents / roads-in-used-components formula, not route-specific bottleneck simulation; it reports35% when residents exist but nobody can commute. This is a simplified rule, not actual observed traffic movement.
- Default Meadowview has no complete home-to-work road connection, so starts with zero employment and negative finances. All presets currently lose treasury monthly. This is an observed demonstration/design concern, not an arithmetic failure.
- Buildings are free; parks add income and happiness globally; treasury can become negative. These are current source rules, not independently specified requirements.
- jsdom is not a rendering engine. Browser scheduling, pointer behavior, mobile layout, visual polish and real keyboard interaction are **not yet verified**.

## Browser setup blocker

Playwright installed via npm. `npx playwright install chromium` initially required `cdn.playwright.dev` (owner approved), then redirected to blocked `storage.googleapis.com`. Request `q2` for the redirect host is pending. `tests/browser.cjs` is prepared for actual desktop/mobile tests after download succeeds.

## Reproduction artifacts

`tests/current-dom.cjs`, `tests/random-oracle.cjs`, their raw results, dependency lockfile, and immutable-by-convention tested HTML fixture `tests/tested-ecf50f8a.html` are saved. Copy tests into scratch, `npm ci`, then run the commands in `tests/README.md`. Earlier reports record now-fixed employment/focus regressions and their build hashes.
