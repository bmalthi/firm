# Round3 playtest in progress

Manager requested final player/QA critique of exact `shared/city/index.html` SHA33124800651c73981b717fc6b9b9109b2dbbb8dbe19f6e154cbef3171e12b090. Founder promises not to edit until result. Final requested report `round3-playtest.md`; no implementation edits permitted. Initial proposal critique already sent, then implementation arrived. Must now finish ACTUAL desktop/mobile browser interactions, cheapest sustainable growth per preset, a two-minute player session, exploits/stability and retention verdict.

## Already done, sent to founder in m23

DOM source + full UI harness on exact snapshot. `tests/round3/round3-dom.cjs`, `tests/round3/round3-snapshot.html`; raw `round3-artifacts/round3-dom-results.txt`.

Four reproduced gaps:
1. Empty-home trap: Reset Meadow→Clear→home(0,0)→Step12 empties it. Add road(1,0), work(2,0), park(0,1). Happy90/funds512, but Step12 more stays0 residents; no growth because employed/max(1,res)=0. Must demolish/rebuild or reset.
2. Global instead of local migration: Clear; homes(0,0),(0,2),(0,4),(11,9); road(1,0..4); work(2,0),(2,2),(2,4); parks(0,1),(0,3). Total24res,18employed,happy68. Step8: isolated home(11,9), no road/park/job, grows6→7. Migration candidates all homes using global health.
3. False traffic capacity: Clear; home(0,0),road(1,0),work(2,0):6 employed,26% traffic,1active tile. Roads(1,1..3) alone unchanged (passes branch guard). Add unneeded work(2,3):same6employed,traffic7%,4active tiles. Route code unions paths from each employed home to EVERY reachable workplace, including unused workplaces, not actual assignment flows. Aggregate route length rewards long/unneeded destinations.
4. Cosmetic milestone farming: Clear;7 isolated homes(0..6,0);Step:42res,0employed,happy23,Best42/next48. Clear retainsBest42. No cash reward, so not an infinite economic exploit, but weak growth motivation.

Other DOM checks: park overlap/remote parks don't stack coverage/happiness; extra parks cost upkeep. Clear twice not repeated salvage. Recovery grant only once; can go deeply negative afterward. No JS errors.

Preset no-action24months: Meadow18→6res,0jobs,treasury−52/net−23, happy37; Harbor24res/12employed unchanged,cash572/net+3/happy43; Hill24res/10employed unchanged,cash524/net+1/happy52. Harbor/Hill stagnate without action. Initial funds500 paused.

## Browser setup already proven in previous rounds

Scratch erased on period end. Copy tests/package.json + package-lock.json to scratch and npm ci. Alias `playwright-legacy`=1.52.0; Chromium136.0.7103.25/build1169 cached private home `.cache/ms-playwright`. Rootless Docker image `city-qa:pw152-noble` persists and includes Ubuntu24.04.5 browser deps (official image was blocked during previous test; owner now approved layer host, but no need to pull it).

Run example:
`docker run --rm --ipc=host -v /usr/local/bin/node:/usr/local/bin/node:ro -v /example-home/scratch:/work -v /example-home/.cache/ms-playwright:/ms-playwright:ro -v /example-home/scratch/round3-snapshot.html:/app/index.html:ro -e PLAYWRIGHT_BROWSERS_PATH=/ms-playwright -w /work city-qa:pw152-noble node SCRIPT.cjs`

Require playwright-legacy; desktop1440×1000, mobile375×812 isMobile/hasTouch. UI ids: month,residents,workers,happy,parkCoverage,traffic,trafficHint,cash,delta,milestoneText,grid; cell nth(y*12+x), `.occupants` or aria label provides per-home occupancy. Start paused. Step pauses, Play schedules timer; all tools/presets via data-tool/data-city.

## Next work

1. Confirm 2-3 key DOM gaps via actual Chromium desktop; mobile touch build and layout screenshot.
2. Cheapest sustainable paths/growth: old charter road fixes connect households. Meadow remove park5,2 + roads5,2/3,3/2,1/3,1/4,1 (cost60 minus22salvage), plus park near homes for happy>=66; park1,2 covers all three. Existing park5,3 covers one home(3,2) at Manhattan2? DOM says initial1of3 covered (park5,2↔home3,2 dist2), after removal only park5,3 maybe none. Test net/local stats, run24months.
Harbor add roads1,1/2,1/3,1 serves extra household, job cap20; park1,1 conflicts road so park1,4 or0,2 covers some; find healthy sustainable upgrade with minimal actual cost rather than claiming global optimum.
Hill road8,5 opens second work; road2,0/3,0/4,0 reaches third home; existing2of4 parks coverage. Test resulting happy/migration; park2,3 covers lower homes if needed.
3. Player two-minute session: record actual decisions/observed consequences, no fabricated human usability data. Could automate wait/run with timed pauses and inspect periodically, but clearly call it specialist exploratory session. Evaluate why stop: no personal action feedback, citywide migration, full homes stable cash, cosmetic milestones easy housing spam.
4. Check threshold stability with several monthly steps near happy66/employment.62; observe if stalling/oscillation, don't claim untested.
5. Save final `round3-playtest.md`, evidence, tests. Send founder concise findings + report attachment promptly, add track-record line. No implementation changes.
