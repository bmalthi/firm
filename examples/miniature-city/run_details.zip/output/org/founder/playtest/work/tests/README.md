# Independent QA harnesses

Implementation source was never modified. `tested-ecf50f8a.html` is a read-only-by-convention fixture snapshot, not the delivered app.

To repeat in a scratch directory, copy this directory there, run `npm ci`, then:

- `node current-dom.cjs tested-ecf50f8a.html`
- `node random-oracle.cjs tested-ecf50f8a.html`

Older regression scripts need their historical snapshot filenames and document issues fixed in later builds. Raw current output is in `current-results.txt` and `random-results.txt`.

jsdom is not a browser rendering engine; timers are controlled mocks. No visual verification is implied.
