// Run with node; all working/intermediate files stay in scratch/cost-paths. Snapshot is read-only.
require('fs').mkdirSync('/example-home/scratch/cost-paths',{recursive:true});

{
const fs=require('fs'),{JSDOM}=require('/example-home/scratch/node_modules/jsdom');
const file='/example-home/drive/org/founder/playtest/work/tests/round3/round3-snapshot.html';
const html=fs.readFileSync(file,'utf8'),js=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const presets=Function('return '+js.match(/const presets=(.*?);let map=/)[1])();
const statSource=js.slice(js.indexOf('function stats()'),js.indexOf('function render()'));
const calc=Function('map','occupants',`const W=12,H=10,at=(x,y)=>y*W+x;${js.slice(js.indexOf('function neighbors('),js.indexOf('function stats()'))}${statSource};return stats()`);
const base=key=>{let m=Array(120).fill('');for(let [t,coords] of [['home',presets[key].homes],['work',presets[key].works],['park',presets[key].parks],['road',presets[key].roads]])for(let [x,y]of coords)m[y*12+x]=t;return m};
const stats=m=>calc(m,m.map(t=>t==='home'?6:0));
const pass=s=>s.happiness>=66&&s.employed/s.res>=.62&&s.net>=0;
const coord=i=>[i%12,Math.floor(i/12)];
function combos(a,n,fn,start=0,out=[]){if(!n)return fn(out);for(let k=start;k<=a.length-n;k++)combos(a,n-1,fn,k+1,[...out,a[k]])}
let report={hash:require('crypto').createHash('sha256').update(html).digest('hex'),method:'Exact snapshot stats() extracted unchanged for analytical screening; finalists replayed using unmodified full HTML in JSDOM, only UI click events.',search:{},results:{}};
for(const key of Object.keys(presets)){
let orig=base(key),existingP=orig.flatMap((t,i)=>t==='park'?[i]:[]);
// Road candidate region: near the homes plus links to the existing trunk; enumerate subsets <= 5.
let roads=orig.flatMap((t,i)=>{let[x,y]=coord(i);return !t&& (key==='meadow'?x>=1&&x<=6&&y>=1&&y<=4:key==='harbor'?x<=3&&y<=4:x>=1&&x<=4&&y<=3||x===8&&y===5)?[i]:[]});
// Include converting either existing park into a road when it bridges the trunk.
if(key==='meadow')roads.push(...existingP);
let parks=orig.flatMap((t,i)=>!t&&presets[key].homes.some(([x,y])=>Math.abs(x-i%12)+Math.abs(y-Math.floor(i/12))<=2)?[i]:[]);
let best=[];let buckets={};let removal=[];let counts={screened:0,qualified:0,roads:roads.map(coord),parks:parks.map(coord)};
function check(rs,ps){let m=orig.slice(),actions=[],cost=0;for(let i of removal){m[i]='';actions.push(['clear',...coord(i)]);cost-=22;}for(let i of rs){if(m[i]){actions.push(['clear',...coord(i)]);cost-=22;}m[i]='road';actions.push(['road',...coord(i)]);cost+=12;}for(let i of ps){if(m[i])return;m[i]='park';actions.push(['park',...coord(i)]);cost+=45;}let category=removal.length||rs.some(i=>orig[i])?'park-salvage':'no-salvage';let bucket=buckets[category]||[];if(bucket.length>=8&&cost>bucket[7].cost)return;counts.screened++;let s=stats(m);if(pass(s)){counts.qualified++;bucket.push({cost,actions,s:{res:s.res,employed:s.employed,happy:s.happiness,net:s.net},map:m});bucket.sort((a,b)=>a.cost-b.cost||b.s.happy-a.s.happy);buckets[category]=bucket.slice(0,8);}}
for(let mask=0;mask<(1<<existingP.length);mask++){removal=existingP.filter((_,i)=>mask>>i&1);for(let n=0;n<=5;n++)combos(roads,n,rs=>{if(rs.some(i=>removal.includes(i)))return;check(rs,[]);for(let p of parks)check(rs,[p]);if(key==='harbor'&&n<=3)combos(parks,2,ps=>check(rs,ps));});}
report.search[key]=counts;best=Object.values(buckets).flat();report.results[key]=buckets;console.log(key,counts.screened,best.slice(0,3).map(({cost,actions,s})=>({cost,actions,s})));
}
fs.writeFileSync('/example-home/scratch/cost-paths/expanded.json',JSON.stringify(report,null,2));

}

{
const fs=require('fs'),{JSDOM}=require('/example-home/scratch/node_modules/jsdom');
const root='/example-home/drive/org/founder/playtest/work';
const html=fs.readFileSync(root+'/tests/round3/round3-snapshot.html','utf8'),js=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const r=JSON.parse(fs.readFileSync('/example-home/scratch/cost-paths/expanded.json'));
const calc=Function('map','occupants',`const W=12,H=10,at=(x,y)=>y*W+x;${js.slice(js.indexOf('function neighbors('),js.indexOf('function render()'))};return stats()`);
const pass=s=>s.happiness>=66&&s.employed/s.res>=.62&&s.net>=0;
function evaluate(key,actions,label){const d=new JSDOM(html,{runScripts:'dangerously'}),w=d.window,doc=w.document;const click=s=>{let e=typeof s==='string'?doc.querySelector(s):s;if(!e)throw Error(s);e.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));};click(`[data-city="${key}"]`);const read=()=>({month:+doc.querySelector('#month').textContent,res:+doc.querySelector('#residents').textContent,employed:+doc.querySelector('#workers').textContent.match(/^\d+/)[0],happy:+doc.querySelector('#happy').textContent,net:+doc.querySelector('#delta').textContent.match(/[-+]?\$(-?\d+)/)[0].replace('$',''),funds:+doc.querySelector('#cash').textContent.replace(/[$,]/g,''),coverage:doc.querySelector('#parkCoverage').textContent,traffic:+doc.querySelector('#traffic').textContent});let initial=read();let spent=0,salvage=0;for(let [t,x,y]of actions){let cell=doc.querySelector('#grid').children[y*12+x];if(t==='clear'){let old=cell.classList; if(old.contains('home')||old.contains('work'))throw Error('Forbidden demolition');if(!old.contains('park')&&!old.contains('road'))throw Error('Empty clear');salvage+=old.contains('park')?22:6;}else{if(!cell.classList.contains('cell')||cell.classList.length!==1)throw Error('Build occupied '+JSON.stringify([t,x,y]));click(`[data-tool="${t}"]`);spent+=t==='road'?12:45;}click(cell);}let after=read(),trace=[after],at24,at100;for(let n=1;n<=100;n++){click('#step');let s=read();trace.push(s);if(n===24)at24=s;if(n===100)at100=s;}let result={key,label,actions,spent,salvage,cost:spent-salvage,initial,after,at24,at100,firstThresholdFailure:trace.find(s=>s.happy<66||s.employed/s.res<.62||s.net<0)||null,minFunds:Math.min(...trace.map(s=>s.funds)),firstFullMonth:trace.find(s=>s.res===(key==='meadow'?24:32))?.month,verified:at100.res>initial.res&&at100.res>=at24.res&&trace.every(s=>s.funds>0&&s.net>=0)&&at100.happy>=66&&at100.employed/at100.res>=.62};w.close();console.log(JSON.stringify(result));return result;}
let out={...r,verification:[],roadSalvageScreened:0};for(let[key,buckets]of Object.entries(r.results)){
for(let cat of ['no-salvage','park-salvage'])for(let b of buckets[cat].slice(0,2))out.verification.push(evaluate(key,b.actions,cat));
// Explicitly salvage at most three preexisting redundant roads, never homes/workplaces.
let variants=[];for(let b of Object.values(buckets).flat()){let roads=b.map.flatMap((t,i)=>t==='road'&&!b.actions.some(a=>a[0]==='road'&&a[2]*12+a[1]===i)?[i]:[]);let subsets=[];for(let a=0;a<roads.length;a++){subsets.push([roads[a]]);for(let z=a+1;z<roads.length;z++){subsets.push([roads[a],roads[z]]);for(let q=z+1;q<roads.length;q++)subsets.push([roads[a],roads[z],roads[q]]);}}for(let ids of subsets){let m=b.map.slice();for(let i of ids)m[i]='';out.roadSalvageScreened++;let s=calc(m,m.map(t=>t==='home'?6:0));if(pass(s))variants.push({...b,cost:b.cost-6*ids.length,actions:[...b.actions,...ids.map(i=>['clear',i%12,Math.floor(i/12)])]});}}
variants.sort((a,b)=>a.cost-b.cost);let seen=new Set();for(let v of variants){let sig=JSON.stringify(v.actions);if(seen.has(sig))continue;seen.add(sig);out.verification.push(evaluate(key,v.actions,'park/road salvage (max 3 existing roads)'));if(seen.size===3)break;}
}
// Necessary demolition only (one bridge park), the supplied notes, and threshold ablations.
out.verification.push(evaluate('meadow',[['clear',5,2],['road',5,2],['road',3,3],['park',1,2]],'necessary demolition only'));
for(const [key,actions] of [
['meadow',[['clear',5,2],['road',5,2],['road',3,3],['road',2,1],['road',3,1],['road',4,1],['park',1,2]]],
['harbor',[['road',1,1],['road',2,1],['road',3,1],['park',0,2]]],
['hill',[['road',8,5],['road',2,0],['road',3,0],['road',4,0],['park',2,3]]]])out.verification.push(evaluate(key,actions,'supplied starting candidate'));
for(const key of ['meadow','harbor','hill']){let best=r.results[key]['no-salvage'][0];let actions=best.actions.filter(a=>key==='hill'?!(a[0]==='road'&&a[1]===2&&a[2]===0):a[0]!=='park');out.verification.push(evaluate(key,actions,'threshold ablation'))}
fs.writeFileSync('/example-home/scratch/cost-paths/verified.json',JSON.stringify(out,null,2));

}

{
const fs=require('fs'),crypto=require('crypto'),root='/example-home/drive/org/founder/playtest/work';
const r=JSON.parse(fs.readFileSync('/example-home/scratch/cost-paths/verified.json'));
if(crypto.createHash('sha256').update(fs.readFileSync(root+'/tests/round3/round3-snapshot.html')).digest('hex')!==r.hash)throw Error('Snapshot changed');
let lines=['COST PATHS — exact snapshot SHA256 '+r.hash,'All coordinates 0-based (x,y). No implementation edits, home/work demolition, new homes/work, grants or bulk clearing.','Costs are net action expenditure = construction minus salvage; gross separately recorded.','Method: snapshot stats() evaluated unchanged for screening, then original complete HTML executed unchanged under JSDOM. Every tested placement/clear, preset reset and month advancement uses dispatched bubbling MouseEvent clicks: [data-city], [data-tool], #grid.children[y*12+x], #step.','Search: at most five new roads in explicit per-preset candidate regions (see JSON); zero/one new nearby park, or two in Harbor for <=3 roads; all subsets of original parks removable. Kept eight cheapest initial qualifiers per salvage category. Then examined removal of <=3 preexisting roads on those retained maps. No global optimum claim: road regions, road/park count limits, initial-threshold filter, cost pruning and top-eight retention exclude other possible repairs.','Screens: '+Object.entries(r.search).map(([k,s])=>k+' '+s.screened).join(', ')+'; additional road-salvage screens '+r.roadSalvageScreened+'.','Full UI tests: '+r.verification.length+' independent 100-month trajectories ('+r.verification.length*100+' step clicks), snapshots at 0/24/100; includes 3 negative threshold ablations and 3 supplied-note candidates.','Hill no-salvage $48 includes isolated road (2,0): actual code counts any adjacent road as served even without a job connection. This is a simulation quirk, not proof of full network connectivity. Cheapest salvage Hill avoids that isolated-road trick.','Growth gate in source: every even month, happy>=66 and employed/res>=.62 and treasury after that month income>=0; net>=0 is this task’s additional sustainability test. Migration is one resident total per two months, not per home. Full homes stop migration. Positive/stable means residents reach fixed housing cap and treasury then continues increasing, not unbounded population growth.','','CHEAPEST VERIFIED FOUND (explicit salvage category)'];
const compact=s=>`R=${s.res}, E=${s.employed} (${(s.employed/s.res).toFixed(4)}), H=${s.happy}, net=${s.net}, funds=${s.funds}`;
for(let key of ['meadow','harbor','hill']){let v=r.verification.filter(v=>v.key===key&&v.verified).sort((a,b)=>a.cost-b.cost)[0];lines.push(`${key}: gross $${v.spent}, salvage $${v.salvage}, net cost $${v.cost}. Actions in order: ${v.actions.map(([t,x,y])=>`${t}(${x},${y})`).join('; ')}`,`  Original: ${compact(v.initial)}`,`  Repaired month0: ${compact(v.after)}`,`  Month24: ${compact(v.at24)}`,`  Month100: ${compact(v.at100)}`,`  Full at month${v.firstFullMonth}; thresholds met every month0..100; minimum month-end funds $${v.minFunds}; no treasury aid.`);}
lines.push('','SEPARATE LESS-SALVAGE / NO-SALVAGE OPTIONS');
for(let key of ['meadow','harbor','hill'])for(let label of ['necessary demolition only','no-salvage','park-salvage']){let v=r.verification.find(v=>v.key===key&&v.label===label);if(v)lines.push(`${key} ${label}: cost $${v.cost}, actions ${JSON.stringify(v.actions)}; repaired ${compact(v.after)}; 24 ${compact(v.at24)}; 100 ${compact(v.at100)}.`)}
lines.push('','THRESHOLD CONTROLS');for(let v of r.verification.filter(v=>v.label==='threshold ablation'))lines.push(`${v.key}: actions ${JSON.stringify(v.actions)}; repaired ${compact(v.after)}; 100 ${compact(v.at100)}. No growth (happiness below66).`);
lines.push('','FULL MACHINE-READABLE EVIDENCE (search candidate coords, exact action order, all actual UI test results):',JSON.stringify(r,null,2));
fs.writeFileSync(root+'/round3-artifacts/cost-paths.txt',lines.join('\n')+'\n');

}
