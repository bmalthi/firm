# QA playbooks
- `snapshot-browser-qa.md`: independent, read-only HTML simulation QA using DOM trajectories plus real Chromium desktop/touch checks; use when a candidate changes during review or browser dependencies are unavailable on the host.
