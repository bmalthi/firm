# Final Round 3 independent regression

**Candidate:** `shared/city/index.html` SHA256 `c41260bc2b2fbd61993c9b6198f9ff15aaff140a4fba1de5966eacae352020f4`.

**Conclusion:** reported reassignment and household-starvation defects are fixed in the exercised cases. Core desktop/touch interactions pass. **No new severe issue found in this targeted scope.** One minor stale-inspection display remains. No implementation files changed.

## Independently confirmed in real Chromium136

- **Residual reassignment:** original two-home/two-work reproduction now reaches **16 residents/16 employed, both homes8/8**, happiness79, +$31/month, $3,432 at month100. Previously stalled14. Exact reproduction: Clear; homes(1,1),(1,3); roads(0,1),(0,2),(0,3),(2,1); works(0,0),(3,1); park(1,2). Coordinates0-based.
- **Fair job allocation:** three equal-access homes/10 jobs rotate **4/3/3 →3/4/3 →3/3/4**. Checked12 consecutive monthly allocations: sum10, spread≤1. All18 residents remain through100 months, net+$11; previously a household emptied.
- **Prior regressions:** empty repaired home repopulates to8; isolated home6→2 over8 months with total24 preserved through internal relocation; unused road branch/far unassigned workplace do not dilute traffic; overlapping/remote parks do not stack happiness.
- **Inspection:** desktop focus presents persistent details; repeated Inspect-mode taps do not clear buildings or spend cash. Mobile375×812 touch inspection works across home/work tiles; selecting a build tool exits Inspect and building resumes. Reachable vacancy/full-job explanations are present.
- **Growth guidance:** verified empty-map, disconnected-home, eligible-arrival, insufficient-happiness, used-job-capacity and full-housing messages. Empty parkless but job-connected home can take its first resident at happiness66, then correctly reports insufficient happiness until a park is added.
- **Controls:** all3 presets, paused start, actual3 timer speeds, Pause/Step, keyboard Enter/build/clear/focus, Reset and far-right mobile construction pass. No page errors or external HTTP requests observed.

## Independent flow/probe cross-check

48 layouts (40 seeded random +8 explicit split-network/empty/full cases),192 runs at ticks0/1/7/31. Independent road-flood/bipartite max-flow oracle matched total employment and **all3,004 individual occupancy+1 vacancy probes**; residual/node conservation and capacity bounds passed. Includes zero-occupant and8→9 capacity probes; actual arrival cap is separately enforced by the app. Extracted unchanged simulation computation with return-only instrumentation—not browser/UI testing or a proof over every possible layout. See `round3-artifacts/c412-oracle.txt`.

## All-preset repair stability rechecked

Same practical repairs as the78cd report, replayed through actual DOM UI events on this exact hash,100 months. Not a new global cheapest-cost search.

| Preset | Net repair cost | Month100 residents / employed | Happiness | Monthly net | Treasury |
|---|---:|---|---:|---:|---:|
| Meadow | $61 | 20 /20 |73|+$33|$3,721|
| Harbor | $154 |30 /30|73|+$48|$5,020|
| Hill | $165 |30 /30|67|+$52|$5,409|

Population/metrics match month24; no observed oscillation or recovery aid. Exact action lists: `tests/round3/c412-preset-paths.cjs`, raw `round3-artifacts/c412-preset-paths-results.txt`.

## Remaining minor issue and limitations

**Low — selected inspection text becomes stale after moving focus to Step/Play.** Mobile: build home(11,9), road(10,9), work(9,9), park(11,8); enable Inspect and tap home. It displays6/8. Tap Step twice: badge/metrics become7, but inspection still says **6/8,6 employed**. Retapping home refreshes7/8. Screenshot: `round3-artifacts/c412/mobile-inspect-after-step.png`. No simulation corruption or destructive Inspect action found.

Desktop controls improved: at1440×1000, Play is now within initial viewport (y878–913), tools beginy588. Mobile has no body overflow (375px); map scroll512/client321. Vertical tool/map/metric travel remains, but inspection is now usable directly below the map.

Milestone farming remains cosmetic: seven isolated homes→Step gives Best42 with0 jobs; Clear retains Best42. No cash reward. This is a known motivation/design limitation, not a new severe exploit. The120-second specialist session was performed on78cd, **not repeated on c412**; its observations are preserved in `round3-78cdca75-playtest.md`. No physical-device, comprehensive accessibility, global fairness/route optimality or exhaustive exploit-resistance certification.

## Evidence

- Exact snapshot: `tests/round3/round3-final-c41260bc.html`.
- Chromium harness/log: `tests/round3/round3-final-browser.cjs`, `round3-artifacts/round3-final-browser-results.txt`.
- Oracle: `tests/round3/c412-oracle.cjs`; preset DOM trajectories as above.
- Screenshots: `round3-artifacts/c412/` (desktop initial, mobile stale/refreshed inspection).
- Earlier reports preserved: `round3-prefixed-playtest.md` (33124800), `round3-78cdca75-playtest.md`.

Source hash remained unchanged at final check. No claims about later builds.
