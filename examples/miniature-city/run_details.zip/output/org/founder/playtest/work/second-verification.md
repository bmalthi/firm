# Second-build retest

Build SHA256 `458347ea1c5a40f744499041219ccf9b9ca33b7f238be7e59d57ba75f73aff5c` (15,846 bytes).

- Focus loss fixed: focused map cell retains row/column after step (jsdom).
- Roadless employment no longer counted in code.
- **High, still reproducible: disconnected residents get connected jobs.** Pause, Clear. Home at (0,0), home at (11,9); road at (1,0); workplaces at (2,0) and (1,1), all zero-based. Actual: 16 employed, +$13/month. Expected: at most8 employed from the only road-connected home. The BFS pools all home-adjacent road components and then uses total residents, including disconnected homes, against reachable jobs.
- Actual commuter movement remains absent in this build.

Reproduction harness: `tests/second-dom.cjs`; requires jsdom and a local `second-snapshot.html` matching the hash. Implementation untouched.
