# Round 3 independent playtest — latest retest

**Tested:** `shared/city/index.html` SHA256 `78cdca75bf6dd2f7a6ffaaf996429fbb711c7e180da4e7d6818da69472093ee7`. No implementation edits. Previous33124800 report is preserved separately in `round3-prefixed-playtest.md`; its cheap-repair results do not certify this revision.

**Verdict:** previous recovery/local-migration/unused-route blockers pass targeted Chromium regression. The sandbox works and traffic now creates real pressure. One remaining **medium job-reassignment trap** makes growth depend on allocation order. Milestones remain cheaply farmable; ongoing growth is understandable in outline but plateaus need better explanations.

## Fixed issues — actual Chromium136 checks

- Empty home(0,0) reaches0 after12 months. Add road(1,0), work(2,0), park(0,1): **6 arrivals in12 more months,8 residents after4 more**. Recovery works without rebuilding.
- Three healthy homes plus an isolated fourth: after8 months isolated home **6→2**, total population stays24 via4 internal relocations; employed18→22. DOM24-month check confirms6 relocations, isolated0, healthy homes8 each, no net population creation/loss.
- One home/near work: traffic26%/1 active tile. Dead branch and unassigned far work now **leave traffic26%/1 active tile**; upkeep rises. No cheap route dilution reproduced.
- Overlapping/remote parks do not stack happiness; upkeep increases.
- Hill isolated road(2,0) no longer improves job access, home title or happiness.

Coordinates throughout are **0-based (x,y)**.

## Remaining reproducible findings

### Medium — spare capacity requiring commuter reassignment does not admit arrivals

Meadow → Clear. Homes(1,1),(1,3); roads(0,1),(0,2),(0,3),(2,1); works(0,0),(3,1); park(1,2).

At month100: **14 residents/14 employed/20 jobs, happiness81, +$25/month, $2,874**. First home is8/8; second remains6/8 despite its title saying connected to jobs, near a park, fully employed, local happiness81.

A16-employed assignment is feasible: first home can use right-hand work, second can use left-hand work. However, first-home flow fills part of the left workplace; `homeOpenJobs` checks only direct residual workplace slots, not capacity obtainable by rerouting that flexible household. The second home cannot grow.

**Control:** same homes/works/park, but roads(0,1),(2,1),(2,2),(2,3): both homes reach8, **16 employed at month100**, happiness79, +$31/month. Confirmed in unchanged full HTML under DOM and Chromium. Harness/log: `round3-openjobs-browser*`.

### Allocation-order limitation — population loss is not a conservation bug

Homes(0,0),(0,2),(0,4); roads(1,0..4); work(2,2); parks(0,1),(0,3). All three homes have job access and parks, but receive **6/4/0 jobs**. Third household empties: **18→12 residents by month24**, stable through100, despite positive+$11/month and initial city happiness69. DOM-confirmed. Local migration now conserves residents when transferring, but row-major job priority—not balanced neighborhood opportunity—decides which home loses people.

### Low/design — milestones still reward unsustainable placement

Clear → seven isolated homes(0..6,0) → Step: **Best42/next48,0 jobs,happiness23**. Clear retains Best42. Latest-hash DOM confirmed. No cash award: not an infinite-money exploit, but weak motivation for thoughtful growth.

## Practical sustainable growth in all three presets

**Cheapest verified all-home-connected growth paths found in this limited retest, not proven minima.** Preserve existing homes/jobs; explicit redundant-park salvage. Complete each while paused. Original homes remain populated in these trajectories; no aid needed. All were replayed through100 DOM UI months. Population grows until jobs constrain further arrivals; finances then continue improving.

| Preset | Net repair cost | Month24: residents / employed / happiness / monthly net / funds | Month100 funds |
|---|---:|---|---:|
| Meadow | $61 | 20 / 20 / 73 / +$33 / $1,213 | $3,721 |
| Harbor | $154 | 30 / 30 / 73 / +$48 / $1,372 | $5,020 |
| Hill | $165 | 30 / 30 / 67 / +$52 / $1,457 | $5,409 |

Actions:
- **Meadow:** clear park(5,2), replace with road; roads(3,3),(2,1),(3,1),(4,1); park(1,2); salvage park(5,3).
- **Harbor:** roads(1,1),(2,1),(3,1),(1,4),(2,4),(3,4),(7,1),(8,1),(9,1); parks(0,2),(2,5); salvage parks(5,5),(6,5). Top-right road extension unlocks the otherwise inaccessible third workplace.
- **Hill:** roads(2,0),(3,0),(4,0),(2,3),(3,3),(8,5); park(1,2); salvage park(6,2); workplace(5,4).

Month24/100 population and metrics unchanged in these final paths: no observed threshold oscillation. Cheaper positive-budget repairs often merely stagnate or lose residents. Example: remove Meadow’s lower-home access and it settles16 residents despite profit; Hill without added jobs holds24 rather than grows. Do not equate a profitable treasury with healthy population growth.

## Full120-second specialist session

Actual scripted exploratory interaction in Chromium desktop; **not** a naïve-user study. Decisions/checkpoints and screenshots saved, no simulated human-retention claims.

- **10s:** blocking park requires demolition click then a second road click. Two-road repair gives12 employed/happy40/+ $12.
- **22s:** park(1,2), Fast: city happy64, net+$11; local conditions allow relocation despite the city aggregate being below66.
- **40s/month39:**16 residents,16 employed,$1,290. Two serviced homes fill; isolated household empties. This is meaningful local feedback but easy to miss without inspecting homes.
- **48s:** top bypass connects the empty third home. **65s:**20 residents/20 jobs, vacant housing remains, net+$32.
- **73s:** home(1,1) instantly adds6; **90s:** population has fallen26→24 under job shortage, despite growing treasury.
- **99s:** workplace(7,1) unlocks growth. **120s/month159:**29 residents/29 employed/30 jobs, happiness65, traffic79%, net+$53, treasury$5,706; next milestone32.

**Would I continue?** Briefly, to solve the traffic plateau; that is better than the pre-fix idle equilibrium. But the next milestone does not itself motivate me: placement buys residents instantly, rewards are generic, and Town notes repeat congestion warnings rather than explain a home’s blocked next arrival. The underfill trap above undermines experimentation further. Suggested priority: explicit per-home “why no arrival?” feedback and an honestly described allocation/traffic model, not more reward widgets.

## Interaction/legibility and scope

Latest Chromium136/Playwright1.52 at1440×1000 desktop and375×812 emulated touch: all3 presets, paused start, actual3 timer speeds, Pause/Step, build/clear/salvage/reset, keyboard Enter/focus, far-right mobile touch placement and connected employment passed; no page errors/external HTTP requests observed. Not a physical-handset or comprehensive accessibility audit. Run/pause/reduced-motion animation checks passed on pre-fix; that CSS is unchanged, but latest regression did not repeat the animation assertions.

Home `title` now supplies useful occupancy/employment/access/park/happiness diagnostics. This is not a persistent touch-friendly inspection panel, nor does it state remaining reachable capacity/growth eligibility. Desktop simulation controls remain below the initial1000px viewport. Mobile body width375, map client321/scroll512; horizontal map scrolling works, but repeated vertical tool→map→metrics travel remains the main interaction friction.

Evidence: `tests/round3/round3-fixed-78cdca75.html`; fixed-browser/session/openjobs/final-paths harnesses and `fixed-audit.cjs`. Raw logs/screenshots in `round3-artifacts/`, including `fixed-session-end.png`, `fixed-job-reroute-trap.png`, `fixed-mobile.png`. DOM audit exposes a read-only stats getter in memory; key issues/fixes also use unmodified complete HTML in Chromium. Greedy routing’s global optimality and exhaustive exploit resistance are **not verified**. No claim about any later hash.
