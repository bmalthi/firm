# Initial verification — Little City

Build: `shared/city/index.html`, SHA256 `e41cd6061a418dc3544568e3d35562ab03c11bfa2668375e33d429e7e03c19fd` (15,109 bytes).

## Findings

1. **High: no actual commute connectivity or commuter movement.** Clear map, place home at row1/column1 and workplace at row10/column12 with no roads: 8 employed, 35% traffic, +$7/month. A single disconnected road beside home improves happiness from52 to67 and reduces traffic to29 without any job connection. Code uses total jobs for employment, total road count for traffic, and immediate home–road adjacency only for happiness. No routefinding or resident animation exists.
2. **Medium: keyboard focus lost on each simulation tick/build.** Focus a grid tile, invoke a monthly render: active element becomes BODY because render replaces every cell. Code also performs this replacement every950ms during normal running. Reproduced in DOM harness, not yet a real browser.

## Checks actually executed

A jsdom harness exercised 120 map cells, each tool, demolition, all three presets, reset, clear, pause/play/step, speed timer restart, and monthly treasury arithmetic. All passed. No JS errors observed. Controlled timers were mocked; checks do not establish visual appearance or real scheduling accuracy.

Preset values (residents / employed / happiness / traffic / net): Meadowview24/20/68/14/+15; Harbor32/30/73/12/+22; Hilltop32/20/71/14/+10.

## Limitations

No preinstalled browser. Playwright package installed; Chromium download blocked by host allowlist (`cdn.playwright.dev`). Owner access request pending. No claim of browser rendering, responsive, or animation verification.

Harness and raw output: `tests/initial-dom.cjs`, `tests/initial-results.txt`. Run with Node and jsdom installed, passing HTML snapshot path as argument. Implementation files were not altered.
