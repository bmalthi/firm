# Fourth-build retest

Build SHA256 `9da0dc4fb2cea90be3ec158619276f7809257dd977a14c42294e15efc83fdec0` (16,156 bytes).

**High: dead-end road removes valid employment.** Pause and Clear; home(1,1), road(2,1), workplace(3,1), zero-based:8 employed. Add road(1,0):0 employed. Remove it:8 employed. The original home–road–work route remains unchanged. Buildings are allocated to the first scanned road component even if no job/home exists in it. Reproduced with `tests/fourth-dom.cjs` using jsdom; no implementation changes.
