# City simulator independent verification plan

Scope: delivered `shared/city/index.html`; no implementation edits.

- Inspect rules and state transitions, preset definitions, and UI event wiring.
- Load the self-contained HTML in a browser if available; record runtime errors and external requests.
- Exercise build selections, placement constraints, demolition, funds, keyboard/accessibility basics, and responsive layout.
- Verify all three presets, pause, one-step progression, and speed selection.
- Construct connected and disconnected home–road–work scenarios; compare jobs/commutes, congestion, happiness, and finances to the app's documented rules.
- Record exact build checksum and reproducible issues; separate tested results from code-only checks and limitations.
