'use strict';
const fs=require('fs'),vm=require('vm'),crypto=require('crypto'),assert=require('assert');
const source=require('path').join(__dirname,'round3-final-c41260bc.html');
const html=fs.readFileSync(source,'utf8'),sha=crypto.createHash('sha256').update(html).digest('hex');
assert.equal(sha,'c41260bc2b2fbd61993c9b6198f9ff15aaff140a4fba1de5966eacae352020f4');
const start=html.indexOf('function stats(){'),end=html.indexOf('\nfunction explainTile',start);
const original=html.slice(start,end);
assert(start>=0&&end>start);
// Sole instrumentation: expose local flow state in the returned object, without changing computations.
const instrumented=original.replace('return{homes,','return{audit:{graph,source,sink,homeStart,compStart,workStart,homeSourceEdges,homeCompEdges,workCapacityEdges,workCompEdges,components},homes,');
assert.notEqual(instrumented,original);
const context=vm.createContext({});
vm.runInContext(`const W=12,H=10;let map,occupants,tick;const at=(x,y)=>y*W+x;function neighbors(i){const x=i%W,y=Math.floor(i/W),a=[];if(x)a.push(i-1);if(x<11)a.push(i+1);if(y)a.push(i-12);if(y<9)a.push(i+12);return a;} ${instrumented}; globalThis.run=(m,o,t)=>{map=m;occupants=o;tick=t;return stats()}`,context);
const adjacent=i=>{const a=[],x=i%12,y=i/12|0;if(x)a.push(i-1);if(x<11)a.push(i+1);if(y)a.push(i-12);if(y<9)a.push(i+12);return a;};
// Independent model: flood roads from each home; create a home->work bipartite network.
// Neither app component labels nor app residual edges are used by this oracle.
function oracle(m,o){
 const hs=[],ws=[];m.forEach((v,i)=>{if(v==='home')hs.push(i);if(v==='work')ws.push(i)});
 const n=hs.length+ws.length+2,s=n-2,t=n-1,c=Array.from({length:n},()=>Array(n).fill(0));
 hs.forEach((h,j)=>{c[s][j]=o[h];const seen=new Set(),q=adjacent(h).filter(i=>m[i]==='road');q.forEach(i=>seen.add(i));for(let k=0;k<q.length;k++)for(const z of adjacent(q[k]))if(m[z]==='road'&&!seen.has(z)){seen.add(z);q.push(z)}ws.forEach((w,k)=>{if(adjacent(w).some(i=>seen.has(i)))c[j][hs.length+k]=10000})});
 ws.forEach((w,k)=>c[hs.length+k][t]=10);
 let flow=0;for(;;){const p=Array(n).fill(-1),q=[s];p[s]=s;for(let k=0;k<q.length&&p[t]<0;k++)for(let v=0;v<n;v++)if(c[q[k]][v]>0&&p[v]<0){p[v]=q[k];q.push(v)}if(p[t]<0)return flow;let d=Infinity;for(let v=t;v!==s;v=p[v])d=Math.min(d,c[p[v]][v]);for(let v=t;v!==s;v=p[v]){c[p[v]][v]-=d;c[v][p[v]]+=d}flow+=d;}
}
let seed=0xc41260bc;function rnd(){seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return (seed>>>0)/4294967296}
const cases=[];function explicit(name,homes,works,roads){const m=Array(120).fill(''),o=Array(120).fill(0);roads.forEach(([x,y])=>m[y*12+x]='road');works.forEach(([x,y])=>{assert(!m[y*12+x]);m[y*12+x]='work'});homes.forEach(([x,y,n])=>{assert(!m[y*12+x]);m[y*12+x]='home';o[y*12+x]=n});cases.push({name,m,o})}
const rows=[2,4].flatMap(y=>Array.from({length:9},(_,j)=>[j+1,y]));
explicit('split-home-rerouting',[[2,3,8],[4,1,8],[6,1,8]],[[8,1],[8,5]],rows);
explicit('split-work-capacity',[[2,1,8],[4,1,8],[6,5,8]],[[8,3]],rows);
explicit('split-home-and-work',[[2,3,8],[4,1,8],[6,5,8]],[[8,3],[9,1],[9,5]],rows);
explicit('split-zero-and-full',[[2,3,0],[4,1,8],[6,5,8]],[[8,1],[8,5]],rows);
explicit('split-saturated',[[2,3,8],[4,1,8],[6,5,8]],[[8,3]],rows);
explicit('full-eight-vacancy',[[2,1,8]],[[8,1]],rows);
explicit('isolated-home',[[0,0,8],[2,3,0]],[[8,1]],rows);
explicit('empty-map',[],[],[]);
for(let k=0;k<40;k++){const m=[],o=[];const roadProb=[.12,.28,.45,.62][k%4];for(let i=0;i<120;i++){const r=rnd();m[i]=r<roadProb?'road':r<roadProb+.16?'home':r<roadProb+.25?'work':r<roadProb+.29?'park':'';o[i]=m[i]==='home'?Math.floor(rnd()*9):0}cases.push({name:`seed-c41260bc-layout-${k}`,m,o})}
let runs=0,probes=0,fullProbes=0,zeroProbes=0;const failures=[];
for(const test of cases)for(const tick of [0,1,7,31]){runs++;try{
 const s=context.run(test.m.slice(),test.o.slice(),tick),base=oracle(test.m,test.o);assert.equal(s.employed,base,'total employed vs oracle');
 const a=s.audit,balance=Array(a.graph.length).fill(0);for(let u=0;u<a.graph.length;u++)for(const e of a.graph[u]){assert(Number.isInteger(e.cap)&&e.cap>=0,'residual capacity bounds');const rev=a.graph[e.to][e.rev];assert.equal(rev.to,u);assert.equal(e.cap+rev.cap,e.initial+rev.initial,'residual pair conservation');if(e.initial>0){const f=e.initial-e.cap;assert(f>=0&&f<=e.initial,'flow capacity');balance[u]-=f;balance[e.to]+=f;}}
 balance.forEach((b,v)=>assert.equal(b,v===a.source?-s.employed:v===a.sink?s.employed:0,'node flow conservation'));
 assert.equal(s.homeEmployed.reduce((a,b)=>a+b,0),s.employed);assert(s.employed<=s.res&&s.employed<=s.jobs);
 s.homeIds.forEach((id,h)=>{assert(s.homeEmployed[h]>=0&&s.homeEmployed[h]<=test.o[id]);const raised=test.o.slice();raised[id]++;const next=oracle(test.m,raised);assert(next===base||next===base+1);probes++;if(test.o[id]===8)fullProbes++;if(!test.o[id])zeroProbes++;assert.equal(s.homeOpenJobs[h],next>base,`homeOpenJobs tile ${id}, base ${base}, raised ${next}`)});
 const again=context.run(test.m.slice(),test.o.slice(),tick);assert.equal(JSON.stringify(again.homeOpenJobs),JSON.stringify(s.homeOpenJobs),'probe repeatability');
 }catch(e){failures.push({name:test.name,tick,error:e.stack,map:test.m,occupancy:test.o});}}
const report=[`Snapshot SHA256 ${sha}`,`Method: unchanged extracted stats function; return-only read-only flow instrumentation in VM; independent road-flood bipartite Edmonds-Karp oracle. No DOM/UI testing.`,`Checked ${cases.length} layouts (40 seeded random, 8 explicit), ${runs} stats runs at ticks 0,1,7,31; ${probes} occupancy+1 home probes (${fullProbes} at occupancy 8, ${zeroProbes} at occupancy 0).`,`Checks: employed maximum, each homeOpenJobs iff oracle total increases, integer/capacity bounds, residual-pair and all-node conservation, home totals, repeated-call stability. Capacity probes permit occupancy 9; arrival gate not tested.`,`Explicit cases: ${cases.slice(0,8).map(x=>x.name).join(', ')}.`,`Result: ${failures.length} discrepancies. ${failures.length?'Exact reproductions follow.':'No severe correctness defect found within this bounded sample. No global fairness or optimality claim beyond checked instances.'}`,JSON.stringify(failures,null,2)].join('\n');
const reportPath='/example-home/drive/org/founder/playtest/work/round3-artifacts/c412-oracle.txt';fs.writeFileSync(reportPath,report+'\n');console.log(report);if(failures.length)process.exitCode=1;
