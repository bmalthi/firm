const {JSDOM}=require('jsdom'),fs=require('fs'),assert=require('assert');
const file=process.argv[2]||'initial-snapshot.html';const logs=[],timers=new Map();let seq=0;
const dom=new JSDOM(fs.readFileSync(file,'utf8'),{runScripts:'dangerously',beforeParse(w){w.setInterval=(f,ms)=>{timers.set(++seq,{f,ms});return seq};w.clearInterval=id=>timers.delete(id);w.addEventListener('error',e=>logs.push(e.message));}});
const d=dom.window.document,q=s=>d.querySelector(s),click=s=>q(s).click(),cell=(x,y)=>q('#grid').children[y*12+x].click();
function pulse(){return Object.fromEntries(['cityName','residents','workers','happy','traffic','cash','delta'].map(k=>[k,q('#'+k).textContent]));}
function report(name){console.log(name,JSON.stringify(pulse()));}
assert.equal(q('#grid').children.length,120);report('Initial');
click('#pause');assert.equal(timers.size,0);assert.equal(q('#status span').textContent,'Paused');
for(const key of ['meadow','harbor','hill']){click(`[data-city="${key}"]`);report(key);let cash=Number(q('#cash').textContent.replace(/[^0-9.-]/g,'')),net=Number(q('#delta').textContent.split(' ')[0].replace(/[^0-9.-]/g,''));click('#step');assert.equal(Number(q('#cash').textContent.replace(/[^0-9.-]/g,'')),cash+net);assert.equal(timers.size,0);}
click('#play');assert.equal(timers.size,1);q('#speed').value='450';q('#speed').dispatchEvent(new dom.window.Event('change'));assert.equal([...timers.values()][0].ms,450);click('#step');assert.equal(timers.size,0);
click('#clear');assert.equal(q('#residents').textContent,'0');click('[data-tool="home"]');cell(0,0);assert.equal(q('#residents').textContent,'8');click('[data-tool="work"]');cell(11,9);report('Disconnected home/work no roads');assert.equal(q('#workers').textContent,'8 employed · 10 jobs');
click('#step');report('Disconnected after step');click('[data-tool="road"]');cell(0,1);report('Isolated road adjacent to home');
cell(0,0);assert.equal(q('#residents').textContent,'0');click('#reset');assert.equal(q('#cityName').textContent,'Hilltop');assert.equal(q('#residents').textContent,'32');
console.log('PASS: grid, tools, demolition, presets, reset, clear, pause/play/step, speed timer, finances. Errors:',JSON.stringify(logs));dom.window.close();
