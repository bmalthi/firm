const {JSDOM}=require('jsdom'),fs=require('fs'),assert=require('assert'),crypto=require('crypto');
const file=process.argv[2]||'fifth-snapshot.html',html=fs.readFileSync(file,'utf8'),timers=new Map(),errors=[];let serial=0;
const dom=new JSDOM(html,{runScripts:'dangerously',beforeParse(w){w.setInterval=(f,ms)=>{timers.set(++serial,{f,ms});return serial};w.clearInterval=id=>timers.delete(id);w.addEventListener('error',e=>errors.push(e.message));}});
const d=dom.window.document,q=s=>d.querySelector(s),click=s=>q(s).click(),cell=(x,y)=>q('#grid').children[y*12+x].click(),num=s=>Number(q(s).textContent.replace(/[^0-9.-]/g,''));
const employed=()=>parseInt(q('#workers').textContent),pulse=()=>Object.fromEntries(['cityName','residents','workers','happy','traffic','cash','delta'].map(k=>[k,q('#'+k).textContent]));
function layout(items){click('#clear');for(const [t,coords]of Object.entries(items)){click(`[data-tool="${t}"]`);for(const [x,y]of coords)cell(x,y);}}
function expect(name,items,n){layout(items);assert.equal(employed(),n,name);console.log('PASS',name,n);}
console.log('SHA256',crypto.createHash('sha256').update(html).digest('hex'));assert.equal(q('#grid').children.length,120);click('#pause');assert.equal(timers.size,0);
for(const key of ['meadow','harbor','hill']){click(`[data-city="${key}"]`);console.log('PRESET',key,JSON.stringify(pulse()));const cash=num('#cash'),net=Number(q('#delta').textContent.split(' ')[0].replace(/[^0-9.-]/g,''));click('#step');assert.equal(num('#cash'),cash+net);assert.equal(timers.size,0);}
for(const [v,ms]of [['1800',1800],['950',950],['450',450]]){q('#speed').value=v;q('#speed').dispatchEvent(new dom.window.Event('change'));assert.equal(timers.size,0);click('#play');assert.equal(timers.size,1);assert.equal([...timers.values()][0].ms,ms);click('#play');assert.equal(timers.size,1);click('#pause');assert.equal(timers.size,0);}
click('#play');const cash=num('#cash'),net=Number(q('#delta').textContent.split(' ')[0].replace(/[^0-9.-]/g,''));[...timers.values()][0].f();assert.equal(num('#cash'),cash+net);click('#step');assert.equal(timers.size,0);
q('#grid').children[5].focus();click('#step');assert.equal(d.activeElement.getAttribute('aria-label'),q('#grid').children[5].getAttribute('aria-label'));
expect('no-road isolation',{home:[[0,0]],work:[[11,9]]},0);
expect('connected home/work',{home:[[0,0]],road:[[1,0]],work:[[2,0]]},8);
expect('isolated extra home not employed',{home:[[0,0],[11,9]],road:[[1,0]],work:[[2,0],[1,1]]},8);
expect('home touching two job components capped at8',{home:[[1,1]],road:[[0,1],[2,1]],work:[[0,0],[2,0]]},8);
expect('work touching two home components capped at10',{home:[[0,0],[2,0]],road:[[0,1],[2,1]],work:[[1,1]]},10);
expect('dead-end road must not consume home',{home:[[1,1]],road:[[2,1],[1,0]],work:[[3,1]]},8);
expect('dead-end road must not consume workplace',{work:[[1,1]],road:[[2,1],[1,0]],home:[[3,1]]},8);
expect('disconnected job-rich and home-rich components',{home:[[0,0],[0,2],[11,9]],road:[[1,0],[1,1],[1,2],[10,9]],work:[[2,0],[9,9],[10,8]]},18);
expect('diagonal does not connect',{home:[[0,0]],road:[[1,1]],work:[[2,1]]},0);
expect('broken road path',{home:[[0,0]],road:[[1,0],[3,0]],work:[[4,0]]},0);
expect('capacity split across work networks',{home:[[1,1],[1,3]],road:[[0,1],[0,2],[0,3],[2,1]],work:[[0,4],[3,1]]},16);
click('[data-tool="park"]');cell(11,9);const happy=num('#happy');cell(11,9);assert(num('#happy')<=happy);click('#reset');assert.equal(q('#cityName').textContent,'Hilltop');assert.equal(num('#residents'),32);assert.equal(num('#cash'),1200);
console.log('PASS controls, timer callbacks, focus, tools/demolition, presets/reset/clear, park effect, monthly money');assert.deepEqual(errors,[]);console.log('ERRORS',JSON.stringify(errors));dom.window.close();
