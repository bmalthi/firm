# Charter QA — final revised build

**PASS in tested scope. No blocking defect remains from this review.**

Exact app: `shared/city/index.html`, SHA256 `4781d89ab2708a467a729e3e9b26f5283d3969c9d5c79b03caca2a0380862cbc`. No implementation edits.

## Checks actually performed

Real Chromium136.0.7103.25 / Playwright1.52.0, rootless Ubuntu24.04.5 container; desktop1440×1000 and mobile375×812 touch emulation. Also controlled jsdom lifecycle/finance tests.

- Starts **Paused, $500, Month0**; no automatic progression after1.1seconds. Prior automatic early-loss onboarding problem is fixed.
- Home$50, workplace$70, park$45, road$12 deducted exactly; demolition gives no refund. Unaffordable placement leaves funds/map unchanged and explains refusal. Unemployed homes produce no tax; monthly arithmetic matches displayed formula.
- Negative treasury loses; deadline loses at Month12 if goal unmet. Success on Month12 is allowed. Reset/preset starts a fresh charter and restores funds/clock/terminal flags.
- All three presets won in browser with **exactly20 employed**, one month, using road improvements only (table below). Goal text correctly shows `/20`, bar100%, and $150 grant awarded once.
- Victory pauses/stops time. Play/Step/Clear after win/loss cannot resume, duplicate grants or wipe the completed city. Prior terminal-state bugs are fixed.
- Actual Slow/Normal/Fast timers, Pause, Step, keyboard Enter placement/demolition, and mobile touch placement pass. Mobile8/20 progress displays40%; body width375px equals viewport. Screenshots inspected; no page JS errors in charter smoke test.

| Preset | Road spend | Employment | Monthly net after fixes | Treasury after Month1 win |
|---|---:|---:|---:|---:|
| Meadowview |$60|20|+$24|$614|
| Harbor |$36|20|+$11|$625|
| Hilltop |$48|20|+$14|$616|

Repro road coordinates, **zero-based(x,y)**:
- Meadow: clear park(5,2), then roads(5,2),(3,3),(2,1),(3,1),(4,1).
- Harbor: roads(1,1),(2,1),(3,1).
- Hilltop: roads(8,5),(2,0),(3,0),(4,0).
Choose preset, build while paused, then Step/Play.

## Balance / rule notes (not blockers)

- Current charter is a forgiving road-connectivity puzzle: each preset can win on Month1 for$36–60 without constructing homes, workplaces or parks. Happiness and congestion do not affect victory. This is much easier than a long-term city-finance challenge.
- Cash exactly$0 is allowed; loss occurs only when a month drives it **below$0**.
- Victory grant precedes solvency check: tested$8 balance with−$19 monthly net still wins at$139 after grant. Clarify this ordering if “running out of cash ends the charter” is meant to take precedence.
- Commute visuals remain tile pulses, not traveling agents. Mobile is emulated Chromium, not physical devices/Safari/Firefox. Timing checks verify progression/stop, not precise jitter.

Evidence: `charter-artifacts/` (raw logs and final desktop/mobile screenshots). Repro scripts and exact fixture: `tests/charter/`; use dependencies/setup documented in `tests/browser-setup.md`.
