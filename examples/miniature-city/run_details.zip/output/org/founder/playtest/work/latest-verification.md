# Latest visual/economy smoke verification

**Build:** `shared/city/index.html`, SHA256 `4cba1b1569557a788ea86a6537c034d52cacb034a88f04ed9cc501c8a2480a51`.

**Executed:** all 11 deterministic commute regressions, 30 random per-resident/job matching-oracle maps, core placement/demolition/reset/clear/preset controls, controlled pause/play/step/speed callbacks, focus retention and monthly money arithmetic pass in jsdom. No JS errors.

New checks pass: no commuters means0% traffic; only roads in used commute components receive `.commute`; isolated road components do not; displayed budget formula matches source and tested arithmetic; parks add $2 monthly. Pause/Play/Step correctly toggle `body.paused` and the corresponding CSS rule uses `animation-play-state:paused`. Reduced-motion CSS sets animation:none. These are DOM/source checks, **not observed animation rendering**.

| Preset | Residents | Employed/jobs | Happy | Traffic | Monthly net |
|---|---:|---:|---:|---:|---:|
| Meadowview |24|0/20|40%|0%|-$1|
| Harbor |32|16/30|56%|6%|+$26|
| Hilltop |32|10/20|58%|5%|+$22|

**Known limitations:** animated markers are per-tile pulses across an entire used component, not individual residents traveling along computed routes. Congestion is aggregate rather than route/bottleneck-specific. Default Meadowview initially has no commuting connection. Building placement is free, parks have global effects, negative balances are allowed.

**Browser status:** Downloaded Chromium136.0.7103.25 / Playwright1.52.0 build1169 via approved `cdn.playwright.dev/builds/chromium/1169/chromium-linux-arm64.zip`. Install required `PLAYWRIGHT_HOST_PLATFORM_OVERRIDE=ubuntu24.04-arm64` because host is Ubuntu26.04 arm64. Actual `chromium.launch` failed on missing system libraries (ATK/AT-SPI/Xcomposite/Xdamage/Xfixes/Xrandr/GBM/ALSA). No real-browser checks performed. Per founder's instruction, stopped setup and reported. Ubuntu24.04 rootless Docker image pulled successfully; container dependency route remains a possible manager-approved next step. Official Playwright image at mcr.microsoft.com is policy-blocked, request q4 pending. Current Chromium156 download also awaits storage.googleapis.com approval q2.

Artifacts: `tests/tested-4cba1b15.html`, `tests/current-dom.cjs`, `tests/random-oracle.cjs`, `tests/visuals-state.cjs`; copy to scratch and npm ci before running. No implementation edits.
