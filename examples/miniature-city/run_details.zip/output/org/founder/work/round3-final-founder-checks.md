# Round 3 final founder checks

**Artifact:** `shared/city/index.html`, SHA256 `acebd5ad7f3b352d7b0853086692bb4bcf4d94633f324c658383c4a09d7df360`.

Independent Playtest Specialist report on immediately previous behaviorally complete hash `c41260bc…` is `org/founder/playtest/work/round3-c41260bc-verification.md`. It confirms residual job reassignment, rotating 4/3/3 job allocation, local recovery/migration, route traffic, park coverage, all three presets, and desktop/touch interactions in Chromium136. Its only reported issue was stale tile-inspection text after Step/Play; the final candidate adds a rendering-only refresh. It also reports a full120-second specialist session on earlier hash `78cdca75`, not the final hash. Do not represent that as naïve-user research or as performed on `acebd5ad`.

Final founder-run checks against `acebd5ad`:
- Extracted inline JavaScript and `node --check` passed.
- Chromium136 / Playwright1.52 Ubuntu Noble rootless container: preset road/park/workplace repair paths with actual click/Step UI over100 months passed: Meadow20 residents/20 employed/happiness73/+$33 per month/$3,721; Harbor30/30/73/+$48/$5,020; Hill30/30/67/+$52/$5,409. No JS errors.
- Chromium empty-home recovery/local-migration regression passed; healthy connected home recovered to8 while isolated home fell6→2/internal transfer, no JS errors.
- Dead branch + unassigned far workplace did not dilute congestion; overlapping parks gave no extra coverage/happiness; demolition lost half cost.
- Two-home/two-work residual reassignment case reached16 employed;3 equally connected homes with10 jobs shared4/3/3; one touch Inspect session refreshed tile text after two Steps from6/8 to7/8.
- Seven isolated homes for40 months remained Thriving Record0 with0 jobs/happiness23; Clear did not inflate the record. No cash milestone awards.
- Step/Play/Pause, timer freeze, pause, Reset, mobile far-right build, map inspection, no HTTP requests / page errors exercised across final and preceding c412 hash.

The final tiny refresh and milestone-gating diff from independently tested c41260bc is local author code; a targeted independent confirmation of exact `acebd5ad` was requested and should be recorded if received. This document does not claim a final-hash independent QA pass before that response.

## Final exact-hash independent follow-up

Mira's targeted independent Chromium136 check on the exact final `acebd5ad…` confirms the touch Inspect refresh6→7→8 after Step/Play, non-destructive Inspect, Reset clearing inspection, zero Thriving Record for seven isolated homes, and employment/happiness-gated records (including normal income only, no award). No JS errors/external requests in that narrow scope. Report: `org/founder/playtest/work/round3-acebd5ad-verification.md`. This is a targeted patch check, not a rerun of all c412 suites. No changes after that reported hash.
