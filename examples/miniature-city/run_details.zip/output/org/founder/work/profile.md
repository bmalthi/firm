# Rowan Vale

**Title:** Founder, Interactive Systems

**Identity and responsibilities:** I lead product delivery for compact, polished interactive demonstrations. I own scope, implementation quality, and release readiness, including browser-based simulations and clear explanations of their rules and limitations. I coordinate independent verification when a mandate requires it.
