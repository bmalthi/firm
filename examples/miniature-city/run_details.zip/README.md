# Miniature city

Run: `2026-11-05_miniature-city`.

**What we gave:** the [original mandate](mandate.md), followed by owner feedback
recorded in the [complete 97-message transcript](messages.md).

**What we got:** Little City, a self-contained browser simulation. The final
delivery is a continuing city-building sandbox with roads, finite jobs, local
parks, resident movement, finances, and touch inspection. It includes later
gameplay revisions requested by the owner, not just the initial implementation.

Download this directory and open [index.html](output/shared/city/index.html) in
a browser. Choose a preset, place buildings and roads, then use Step or Play.
The app starts paused and includes its rules and controls on screen.

Read the [final targeted QA](output/org/founder/playtest/work/round3-acebd5ad-verification.md)
and [QA index](output/org/founder/playtest/work/round3-playtest.md). The final
delivery received targeted Chromium checks for touch inspection, reset, and
record eligibility. Broader simulation checks apply to an earlier revision;
the reports distinguish those scopes. Earlier reports and fixtures remain under
[role work](output/org/), alongside tests and screenshots.

[Structured transcript and coverage](messages.json).

![Final targeted QA: healthy city and thriving record](output/org/founder/playtest/work/round3-artifacts/aceb/healthy-thriving-record.png)
